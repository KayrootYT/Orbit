# Open-source source references and license review

This file records upstream projects referenced by the Orbit Chromium migration documentation. It does not mean their code has been copied into this repository.

| Project | Role | Source | License review |
|---|---|---|---|
| Chromium | Current Android WebView lineage and custom-engine target | https://chromium.googlesource.com/chromium/src/ | Review Chromium LICENSE and third_party notices for the pinned revision |
| Cromite | Example independent Chromium-based browser | https://github.com/uazo/cromite | Review its repository license and all upstream notices before reusing code |
| Firefox Android | Alternative Gecko-based Android browser reference | https://github.com/mozilla-mobile/firefox-android | Review Mozilla Public License and included notices before reusing code |

Do not copy files from these projects without preserving applicable license headers/notices. Open source does not mean license-free. Google Chrome branding and proprietary Google services are not automatically available from the Chromium source tree.
