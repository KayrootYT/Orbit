# Orbit — Privacy and Engine Roadmap

## Current starter status
The current app is a UI/navigation prototype built on Android System WebView. The shield icon is currently a status toggle only. It does not block ads or trackers yet.

## Filter engine milestones
- Choose a supported rule format and document compatibility (e.g. a limited, tested subset of EasyList-style network rules).
- Parse rules off the UI thread and compile them into efficient host/path lookup structures.
- Enforce network blocking at the engine integration layer where possible.
- Add per-origin policies: default, strict, allowlist; persist in Room.
- Provide transparent blocked-request counts only when the underlying engine can measure them accurately.
- Include filter list source, update timestamp, license and failure handling.
- Test false positives, redirects, subresources, service workers and WebSocket behavior.

## Engine decision
Android System WebView uses the device's installed WebView provider. It offers a low-overhead way to prototype, but does not expose every internal Chromium hook. A custom Chromium fork requires Chromium's native build toolchain, source sync, build infrastructure, signing, and a sustained security patch process.

## Security requirements
- Keep HTTPS certificate errors visible; never silently bypass TLS failures.
- Restrict file/content URL access and external schemes.
- Treat downloaded files as untrusted; use safe file naming and Android's scoped storage.
- Store passwords only through a vetted credential/autofill integration; do not implement custom plaintext password storage.
- Separate private browsing data from regular browsing data and verify cleanup on process death.
- Avoid sending browsing history or URLs to analytics.
- Pin down dependency versions and maintain an update policy.
- Run tests on supported Android versions and review all third-party licenses before distribution.
