# Orbit Android Browser — Starter Project

Orbit is a native Android browser starter with an original Kotlin + Jetpack Compose UI and Android System WebView (Chromium-backed).

## Important engine note
This starter uses Android System WebView, which is Chromium-based but managed and updated by the device. It is **not** a custom Chromium engine build. A custom Chromium Content-shell/Chrome fork is a separate, much larger native build and maintenance project.

## Included
- Native Android app scaffold (Kotlin + Jetpack Compose)
- Browser home screen and address/search bar
- WebView page rendering
- Back, forward, reload, and home controls
- Light/dark system theme support
- Basic URL validation and safe navigation handling
- Privacy/engine roadmap documentation

## Not implemented yet
- Real ad/tracker filter engine
- Per-site Shields persistence and UI
- Custom Chromium build
- Private session isolation
- Downloads manager, bookmarks, history database
- Safe Browsing integration and production security audit

Do not describe the current starter as Brave-equivalent or production-ready.

## Build
Open this directory in Android Studio (recent stable version), allow Gradle sync, then build the `app` debug APK.
Suggested package: `com.orbit.browser`.

## Next milestones
1. Add navigation state, tab model and persistent bookmarks/history.
2. Add a tested filter-list parser and request-blocking engine.
3. Implement per-origin privacy policies and cookie controls.
4. Add private browsing using a separate, explicitly managed data profile where the chosen engine supports it.
5. Decide whether to migrate from system WebView to a maintained Chromium fork.
6. Add automated tests, dependency/license review, signing and CI.


## Settings update (October 2026)
The native settings screen now includes entries for privacy/Shields, Privacy Report preference, tabs, media autoplay, appearance (Light/Dark/AMOLED), New Tab Page, homepage enablement, accessibility text zoom, languages, selectable address-bar search engine (Google, DuckDuckGo, Bing, Brave Search), notifications preference, Android Downloads, Sync placeholder, home-screen widget status, default browser settings, and Orbit Origin/engine information.

Limitations are shown honestly in the UI: this starter does not yet include real tab groups, account-backed sync, a launcher widget, per-app language switching, or a full Chromium fork. Privacy Report is a local preference rather than a polished report dashboard. Shields remain a basic host-filtering implementation and are not equivalent to Brave Shields.


## Orbit launcher icon and Add-ons

The Android launcher now uses the Orbit adaptive icon (dark navy background with a cyan orbital mark).

Open **Settings → Add-ons & Plugins**, or tap the extension icon in the top bar, to browse Orbit-native add-ons. The initial catalog includes Reader Mode, Force Dark Pages (where supported by the installed Android System WebView), Page Translator, Quick Share, Cookie Cleaner, and Find in Page. Add-on installation state is stored locally on the device.

**Compatibility note:** Orbit currently uses Android System WebView. The catalog is for built-in Orbit add-ons and does not install arbitrary Firefox WebExtensions/XPI files. True Firefox-style extension compatibility requires an extension runtime and browser-engine integration beyond ordinary WebView support.


## UI redesign (October 2026)
The whole interface was redesigned in a modern mobile-browser style:
- Solid dark toolbars with a pill address bar (site/Shields icon, Shields and Add-ons buttons) and a 5-button bottom bar (Home, Bookmarks, Search, Tabs counter, Menu).
- New Tab Page with the original "Orbit Dunes" wallpaper (drawn in Compose), a Privacy Stats card (lifetime blocked requests, estimated data/time saved) and a top-sites card built from bookmarks/history.
- Floating three-dot menu: New tab, Private tab, History, Downloads, Bookmarks, Recent tabs, Find in page, Translate, Reading mode, Desktop site, Shred site data, Shields, Add-ons, Settings, plus Forward/Share/Downloads/Reload buttons.
- Tab switcher grid (Tabs / Private), Shields bottom sheet, find-in-page bar, address suggestions, grouped Settings, Add-ons and custom host rules pages.
- Light / Dark / AMOLED themes (persisted) and edge-to-edge system bars.

Honest limits: Private tabs only skip history and the disk cache (cookies/storage are still shared by Android System WebView); tab groups, sync and the widget are still placeholders; "Est." stats are rough estimates (about 45 KB and 60 ms per blocked request).
