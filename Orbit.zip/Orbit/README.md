# Orbit Android Browser — Starter Project

Orbit is a native Android browser starter with an original Kotlin + Jetpack Compose UI and Android System WebView (Chromium-backed).

## Important engine note
This starter uses Android System WebView, which is Chromium-based but managed and updated by the device. It is **not** a custom Chromium engine build. A custom Chromium Content-shell/Chrome fork is a separate, much larger native build and maintenance project.

## Included
- Native Android app scaffold (Kotlin + Jetpack Compose)
- Browser home screen and address/search bar
- WebView page rendering
- Back, forward, reload, and home controls
- Light/dark system theme support
- Basic URL validation and safe navigation handling
- Privacy/engine roadmap documentation

## Not implemented yet
- Real ad/tracker filter engine
- Per-site Shields persistence and UI
- Custom Chromium build
- Private session isolation
- Downloads manager, bookmarks, history database
- Safe Browsing integration and production security audit

Do not describe the current starter as Brave-equivalent or production-ready.

## Build
Open this directory in Android Studio (recent stable version), allow Gradle sync, then build the `app` debug APK.
Suggested package: `com.orbit.browser`.

## Next milestones
1. Add navigation state, tab model and persistent bookmarks/history.
2. Add a tested filter-list parser and request-blocking engine.
3. Implement per-origin privacy policies and cookie controls.
4. Add private browsing using a separate, explicitly managed data profile where the chosen engine supports it.
5. Decide whether to migrate from system WebView to a maintained Chromium fork.
6. Add automated tests, dependency/license review, signing and CI.
