# Orbit Android Browser — Chromium integration update

Orbit remains a **native Android application** written in Kotlin + Jetpack Compose.

## Engine status — read before building

- **Current app engine:** Android System WebView, which is Chromium-based and supplied/updated by the Android device.
- **Custom Chromium build kit:** `chromium-build/` fetches upstream Chromium and builds the `chrome_public_apk` baseline.
- **Not yet completed:** the separately built Chromium APK is **not embedded into Orbit's Compose UI**. Chromium is a large native codebase; its Chrome APK is not a drop-in Gradle dependency or an embeddable `WebView` replacement. Do not describe this ZIP as having a fully integrated custom Chromium engine.

The existing WebView-backed Orbit app remains buildable as an ordinary Android project. The separate custom Chromium workflow requires a provisioned Linux x86-64 self-hosted runner with substantial disk/RAM.

## What's included

- Native Kotlin + Jetpack Compose browser UI.
- Current Chromium-backed System WebView page renderer.
- Tabs, navigation, bookmarks/history/settings and built-in Orbit UI add-ons (see app code and UI for exact current coverage).
- `chromium-build/build_chromium_android.sh` for fetching and building upstream Chromium's Android public APK baseline.
- `.github/workflows/android.yml` for the regular Orbit debug APK.
- `.github/workflows/chromium-android.yml` for the separate Chromium baseline build on a self-hosted runner.
- `docs/PRIVACY_AND_ENGINE_ROADMAP.md` and `chromium-build/ORBIT_CHROMIUM_INTEGRATION.md` describing the migration boundary and next steps.

## Build the current Orbit APK

Open this directory in Android Studio and build `app` / `assembleDebug`, or use the standard Android workflow.

## Build the Chromium baseline separately

Use Linux x86-64 with 16 GB RAM minimum (32 GB preferred) and 100+ GB free SSD space:

```bash
chmod +x chromium-build/build_chromium_android.sh
./chromium-build/build_chromium_android.sh
```

The output is a Chromium baseline artifact, not an Orbit-branded release. The build script records the upstream revision and an artifact summary.

## What is required for true custom-engine integration

A real migration requires choosing an embeddable Chromium integration strategy, pinning a Chromium revision, building the required Android native libraries/APKs, bridging navigation/rendering/lifecycle into Orbit's UI, then testing cookies, private sessions, downloads, permissions, media, file pickers, crashes, security updates and ABI compatibility. This cannot be safely achieved by adding one Maven dependency or copying a few source files.

## Open-source references

- Chromium source: https://chromium.googlesource.com/chromium/src/
- Chromium Android build instructions: https://chromium.googlesource.com/chromium/src/+/main/docs/android_build_instructions.md
- Cromite (independent Chromium-based browser project): https://github.com/uazo/cromite
- Firefox Android (Gecko-based alternative): https://github.com/mozilla-mobile/firefox-android

Before redistributing code from another browser project, review its license and notices. Chromium is open source, but Chrome branding and some Google-specific components/services are not automatically included.
