package com.orbit.browser

import androidx.compose.ui.graphics.Color

internal val OrbitBlue = Color(0xFF54D8FF)
internal val OrbitOrange = Color(0xFFFF6A2B)
internal val OrbitPeri = Color(0xFF8E9BFF)
internal val OrbitPrivate = Color(0xFFB794FF)

internal enum class OrbitTheme { LIGHT, DARK, AMOLED }

/** Every colour the UI uses comes from here so the three themes stay consistent. */
internal data class OrbitColors(
    val dark: Boolean,
    val bg: Color,        // page background
    val bar: Color,       // top / bottom toolbars
    val pill: Color,      // address bar, chips, circular buttons
    val surface: Color,   // cards on settings-style pages
    val menu: Color,      // popup menu + bottom sheets
    val text: Color,
    val sub: Color,
    val divider: Color,
    val accent: Color,
    val onAccent: Color
)

internal fun orbitColors(theme: OrbitTheme): OrbitColors = when (theme) {
    OrbitTheme.LIGHT -> OrbitColors(
        dark = false,
        bg = Color(0xFFF1F3F9), bar = Color(0xFFFFFFFF), pill = Color(0xFFE8EBF4),
        surface = Color(0xFFFFFFFF), menu = Color(0xFFFFFFFF),
        text = Color(0xFF14161F), sub = Color(0xFF5E6376), divider = Color(0x1F000000),
        accent = Color(0xFF007FAD), onAccent = Color.White
    )
    OrbitTheme.DARK -> OrbitColors(
        dark = true,
        bg = Color(0xFF12141B), bar = Color(0xFF171923), pill = Color(0xFF2B2D3B),
        surface = Color(0xFF22242F), menu = Color(0xFF393B49),
        text = Color(0xFFF1F2F8), sub = Color(0xFFA9ACBF), divider = Color(0x26FFFFFF),
        accent = OrbitBlue, onAccent = Color(0xFF04202B)
    )
    OrbitTheme.AMOLED -> OrbitColors(
        dark = true,
        bg = Color.Black, bar = Color.Black, pill = Color(0xFF1B1C22),
        surface = Color(0xFF101116), menu = Color(0xFF202128),
        text = Color(0xFFF1F2F8), sub = Color(0xFF9EA1B3), divider = Color(0x26FFFFFF),
        accent = OrbitBlue, onAccent = Color(0xFF04202B)
    )
}
