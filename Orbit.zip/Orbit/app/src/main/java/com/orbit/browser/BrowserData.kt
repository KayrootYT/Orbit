package com.orbit.browser

import android.content.Context
import android.webkit.CookieManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI

data class BrowserTab(
    val id: Long,
    var url: String = "",
    var title: String = "New tab",
    var loading: Boolean = false
)

data class Bookmark(val title: String, val url: String)
data class HistoryEntry(val title: String, val url: String, val visitedAt: Long)

class BrowserData(context: Context) {
    private val prefs = context.getSharedPreferences("orbit_browser_data", Context.MODE_PRIVATE)

    fun bookmarks(): List<Bookmark> = readArray("bookmarks").mapNotNull {
        runCatching { Bookmark(it.getString("title"), it.getString("url")) }.getOrNull()
    }

    fun addBookmark(title: String, url: String) {
        if (url.isBlank() || url == "about:blank") return
        val all = bookmarks().filterNot { it.url == url }.toMutableList()
        all.add(0, Bookmark(title.ifBlank { url }, url))
        writeArray("bookmarks", JSONArray().also { arr -> all.forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url)) } })
    }

    fun history(): List<HistoryEntry> = readArray("history").mapNotNull {
        runCatching { HistoryEntry(it.getString("title"), it.getString("url"), it.getLong("visitedAt")) }.getOrNull()
    }

    fun addHistory(title: String, url: String) {
        if (url.isBlank() || url == "about:blank" || !url.startsWith("http")) return
        val all = history().filterNot { it.url == url }.toMutableList()
        all.add(0, HistoryEntry(title.ifBlank { url }, url, System.currentTimeMillis()))
        writeArray("history", JSONArray().also { arr -> all.take(500).forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url).put("visitedAt", it.visitedAt)) } })
    }

    fun clearHistory() { prefs.edit().remove("history").apply() }

    fun getBool(key: String, default: Boolean): Boolean = prefs.getBoolean(key, default)
    fun setBool(key: String, value: Boolean) { prefs.edit().putBoolean(key, value).apply() }
    fun getString(key: String, default: String): String = prefs.getString(key, default) ?: default
    fun setString(key: String, value: String) { prefs.edit().putString(key, value).apply() }

    fun shieldEnabled(host: String): Boolean = prefs.getBoolean("shield:$host", true)
    fun setShieldEnabled(host: String, enabled: Boolean) { prefs.edit().putBoolean("shield:$host", enabled).apply() }

    fun customBlockedHosts(): Set<String> = prefs.getStringSet("custom_blocked", emptySet())?.toSet() ?: emptySet()
    fun setCustomBlockedHosts(hosts: Set<String>) { prefs.edit().putStringSet("custom_blocked", hosts.toSet()).apply() }

    fun customAllowedHosts(): Set<String> = prefs.getStringSet("custom_allowed", emptySet())?.toSet() ?: emptySet()
    fun setCustomAllowedHosts(hosts: Set<String>) { prefs.edit().putStringSet("custom_allowed", hosts.toSet()).apply() }

    private fun readArray(key: String): List<JSONObject> {
        return runCatching {
            val arr = JSONArray(prefs.getString(key, "[]"))
            (0 until arr.length()).map { arr.getJSONObject(it) }
        }.getOrDefault(emptyList())
    }

    private fun writeArray(key: String, array: JSONArray) {
        prefs.edit().putString(key, array.toString()).apply()
    }
}

object OrbitUrl {
    fun normalize(input: String, engine: String = "Google"): String {
        val raw = input.trim()
        if (raw.isEmpty()) return "about:blank"
        if (raw.startsWith("https://", true) || raw.startsWith("http://", true)) return raw
        if (raw.contains('.') && !raw.contains(' ') && !raw.startsWith("about:")) return "https://$raw"
        val q = java.net.URLEncoder.encode(raw, "UTF-8")
        val base = when (engine) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q="
            "Bing" -> "https://www.bing.com/search?q="
            "Brave Search" -> "https://search.brave.com/search?q="
            else -> "https://www.google.com/search?q="
        }
        return base + q
    }

    fun host(url: String): String = runCatching { URI(url).host?.lowercase().orEmpty() }.getOrDefault("")
}
