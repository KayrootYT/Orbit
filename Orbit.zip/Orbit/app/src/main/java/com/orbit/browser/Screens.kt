package com.orbit.browser

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── New Tab Page ─────────────────────────

private val Glass = Color(0xCC0B1623)

private fun formatData(blocked: Long): Pair<String, String> {
    val kb = blocked * 45L
    return if (kb >= 1024L) "%.1f".format(kb / 1024.0) to "MB" else kb.toString() to "KB"
}

private fun formatTime(blocked: Long): Pair<String, String> {
    val seconds = blocked * 60L / 1000L
    return when {
        seconds >= 3600L -> (seconds / 3600L).toString() to "h"
        seconds >= 60L -> (seconds / 60L).toString() to "m"
        else -> seconds.toString() to "s"
    }
}

@Composable
private fun StatColumn(value: String, unit: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = color, fontSize = 38.sp, fontWeight = FontWeight.Medium)
            if (unit.isNotEmpty()) {
                Text(unit, color = color, fontSize = 18.sp, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(label, color = Color.White.copy(alpha = .78f), fontSize = 13.sp, textAlign = TextAlign.Center, lineHeight = 17.sp)
    }
}

@Composable
private fun SiteTile(label: String?, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        if (label == null) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0xFF2A2E3A)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, "Add shortcut", tint = Color.White, modifier = Modifier.size(28.dp))
            }
        } else {
            SiteAvatar(label, 56.dp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label ?: "Add new", color = Color.White, fontSize = 12.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}

@Composable
internal fun NewTabPage(
    privateMode: Boolean,
    showStats: Boolean,
    statsExpanded: Boolean,
    totalBlocked: Long,
    sites: List<Bookmark>,
    onToggleStats: () -> Unit,
    onOpen: (String) -> Unit,
    onAddSite: () -> Unit,
    onShields: () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        OrbitWallpaper(Modifier.fillMaxSize(), privateMode)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (privateMode) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Glass).padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VisibilityOff, null, tint = OrbitPrivate, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Private tab", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Orbit won't save history for pages opened here, and this tab skips the disk cache. " +
                            "Cookies and site storage are still handled by Android System WebView in this starter build, " +
                            "so this is not full isolation yet.",
                        color = Color.White.copy(alpha = .78f), fontSize = 14.sp, lineHeight = 20.sp
                    )
                }
            } else if (showStats) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Glass)
                        .clickable(onClick = onShields).padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Privacy Stats", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        IconButton(onClick = onToggleStats, modifier = Modifier.size(34.dp)) {
                            Icon(
                                if (statsExpanded) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                "Show or hide stats", tint = Color.White.copy(alpha = .85f)
                            )
                        }
                    }
                    if (statsExpanded) {
                        Spacer(Modifier.height(14.dp))
                        val (dataValue, dataUnit) = formatData(totalBlocked)
                        val (timeValue, timeUnit) = formatTime(totalBlocked)
                        Row(Modifier.fillMaxWidth()) {
                            StatColumn(totalBlocked.toString(), "", "Trackers & Ads\nBlocked", OrbitOrange, Modifier.weight(1f))
                            StatColumn(dataValue, dataUnit, "Est. Data\nSaved", OrbitPeri, Modifier.weight(1f))
                            StatColumn(timeValue, timeUnit, "Est. Time\nSaved", Color.White, Modifier.weight(1f))
                        }
                    }
                }
            }

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Glass).padding(vertical = 18.dp, horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val tiles = buildList<Bookmark?> {
                    addAll(sites.take(7))
                    add(null)
                }
                tiles.chunked(4).forEach { rowItems ->
                    Row(Modifier.fillMaxWidth()) {
                        rowItems.forEach { site ->
                            if (site == null) {
                                SiteTile(null, Modifier.weight(1f), onAddSite)
                            } else {
                                SiteTile(site.title.ifBlank { OrbitUrl.host(site.url) }, Modifier.weight(1f)) { onOpen(site.url) }
                            }
                        }
                        repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(56.dp))
        }
        Box(
            Modifier.align(Alignment.BottomStart).padding(16.dp).clip(RoundedCornerShape(12.dp))
                .background(Color(0x77000000)).padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text("Orbit Dunes · original artwork", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
        }
    }
}

// ───────────────────────── address suggestions ─────────────────────────

@Composable
internal fun SuggestionList(c: OrbitColors, query: String, entries: List<Bookmark>, onPick: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(c.bg)) {
        item {
            Row(
                Modifier.fillMaxWidth().clickable { onPick(query) }.padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = c.accent)
                Spacer(Modifier.width(16.dp))
                Text("Search for \"$query\"", color = c.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        items(entries, key = { it.url }) { entry ->
            Row(
                Modifier.fillMaxWidth().clickable { onPick(entry.url) }.padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SiteAvatar(OrbitUrl.host(entry.url).ifBlank { entry.title }, 36.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(entry.title, color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(entry.url, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

// ───────────────────────── Tabs ─────────────────────────

@Composable
private fun ModeChip(label: String, count: Int, selected: Boolean, c: OrbitColors, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) tint.copy(alpha = .22f) else c.pill)
            .then(if (selected) Modifier.border(1.5.dp, tint, RoundedCornerShape(20.dp)) else Modifier)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = if (selected) tint else c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(8.dp))
        Text("$count", color = if (selected) tint else c.sub, fontSize = 14.sp)
    }
}

@Composable
private fun TabCard(tab: TabState, selected: Boolean, c: OrbitColors, onSelect: () -> Unit, onClose: () -> Unit) {
    val host = OrbitUrl.host(tab.url)
    val blank = tab.url == "about:blank"
    val label = if (blank) "New tab" else host.ifBlank { tab.title }
    val hue = (label.lowercase().hashCode() and 0x7fffffff) % 360
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.clip(shape).background(c.surface)
            .then(if (selected) Modifier.border(2.dp, if (tab.isPrivate) OrbitPrivate else c.accent, shape) else Modifier)
            .clickable(onClick = onSelect)
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            SiteAvatar(label, 22.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                if (blank) "New tab" else tab.title, color = c.text, fontSize = 13.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.Close, "Close tab", tint = c.sub, modifier = Modifier.size(18.dp))
            }
        }
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.9f).background(
                Brush.linearGradient(
                    listOf(
                        Color.hsv(hue.toFloat(), .5f, if (c.dark) .42f else .75f),
                        Color.hsv(((hue + 40) % 360).toFloat(), .55f, if (c.dark) .22f else .55f)
                    )
                )
            ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    if (tab.isPrivate) Icons.Default.VisibilityOff else Icons.Default.Tab, null,
                    tint = Color.White.copy(alpha = .9f), modifier = Modifier.size(34.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text(label, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 10.dp))
            }
        }
    }
}

@Composable
internal fun TabsPage(
    c: OrbitColors,
    tabs: List<TabState>,
    selectedId: Long,
    showPrivate: Boolean,
    onMode: (Boolean) -> Unit,
    onSelect: (TabState) -> Unit,
    onClose: (TabState) -> Unit,
    onNew: () -> Unit,
    onCloseAll: () -> Unit,
    onDone: () -> Unit
) {
    val list = tabs.filter { it.isPrivate == showPrivate }
    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(
            Modifier.fillMaxWidth().background(c.bar).statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            ModeChip("Tabs", tabs.count { !it.isPrivate }, !showPrivate, c, c.accent) { onMode(false) }
            Spacer(Modifier.width(10.dp))
            ModeChip("Private", tabs.count { it.isPrivate }, showPrivate, c, OrbitPrivate) { onMode(true) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (list.isEmpty()) {
                Text(
                    if (showPrivate) "No private tabs open" else "No tabs open", color = c.sub,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { tab ->
                    TabCard(tab, tab.id == selectedId, c, { onSelect(tab) }, { onClose(tab) })
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(c.bar).navigationBarsPadding().height(66.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(88.dp)) {
                IconButton(onClick = onCloseAll) { Icon(Icons.Default.DeleteSweep, "Close all tabs", tint = c.text) }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(50.dp).clip(CircleShape).background(if (showPrivate) OrbitPrivate else c.accent).clickable(onClick = onNew),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Add, "New tab", tint = c.onAccent, modifier = Modifier.size(28.dp)) }
            }
            Box(Modifier.width(88.dp), contentAlignment = Alignment.CenterEnd) {
                TextButton(onClick = onDone) { Text("Done", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}

// ───────────────────────── Bookmarks / History ─────────────────────────

@Composable
private fun EntryRow(c: OrbitColors, title: String, url: String, meta: String?, onOpen: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SiteAvatar(OrbitUrl.host(url).ifBlank { title }, 42.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(url, color = c.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (meta != null) Text(meta, color = c.sub.copy(alpha = .8f), fontSize = 11.sp)
        }
        IconButton(onClick = onRemove) { Icon(Icons.Default.Close, "Remove", tint = c.sub) }
    }
}

@Composable
private fun EmptyState(c: OrbitColors, icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = c.sub.copy(alpha = .6f), modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(text, color = c.sub, fontSize = 15.sp)
    }
}

@Composable
internal fun BookmarksPage(
    c: OrbitColors, items: List<Bookmark>,
    onBack: () -> Unit, onOpen: (String) -> Unit, onRemove: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().background(c.bg)) {
        PageHeader("Bookmarks", c, onBack)
        if (items.isEmpty()) {
            EmptyState(c, Icons.Default.Bookmarks, "No bookmarks yet")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.url }) { item ->
                    EntryRow(c, item.title, item.url, null, { onOpen(item.url) }, { onRemove(item.url) })
                }
            }
        }
    }
}

@Composable
internal fun HistoryPage(
    c: OrbitColors, items: List<HistoryEntry>,
    onBack: () -> Unit, onOpen: (String) -> Unit, onRemove: (String) -> Unit, onClear: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(c.bg)) {
        PageHeader("History", c, onBack) {
            if (items.isNotEmpty()) TextButton(onClick = onClear) { Text("Clear", color = c.accent) }
        }
        if (items.isEmpty()) {
            EmptyState(c, Icons.Default.History, "No browsing history")
        } else {
            val now = System.currentTimeMillis()
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.url }) { item ->
                    val whenText = DateUtils.getRelativeTimeSpanString(item.visitedAt, now, DateUtils.MINUTE_IN_MILLIS).toString()
                    EntryRow(c, item.title, item.url, whenText, { onOpen(item.url) }, { onRemove(item.url) })
                }
            }
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
internal fun SettingsPage(
    c: OrbitColors,
    tabCount: Int,
    searchEngine: String,
    themeLabel: String,
    homepageUrl: String,
    privacyReport: Boolean,
    mediaAutoplay: Boolean,
    homepageEnabled: Boolean,
    accessibilityZoom: Boolean,
    notifications: Boolean,
    sync: Boolean,
    onBack: () -> Unit,
    onShields: () -> Unit,
    onTabs: () -> Unit,
    onAddons: () -> Unit,
    onPrivacyReport: (Boolean) -> Unit,
    onMediaAutoplay: (Boolean) -> Unit,
    onHomepage: (Boolean) -> Unit,
    onAccessibilityZoom: (Boolean) -> Unit,
    onNotifications: (Boolean) -> Unit,
    onSync: (Boolean) -> Unit,
    onSearchEngine: () -> Unit,
    onAppearance: () -> Unit,
    onDownloads: () -> Unit,
    onDefaultBrowser: () -> Unit,
    onInfo: (String, String) -> Unit
) {
    Column(Modifier.fillMaxSize().background(c.bg)) {
        PageHeader("Settings", c, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
            SectionLabel("Privacy & security", c)
            SectionCard(c) {
                ListRow(c, "Shields & privacy", "Per-site tracker blocking and custom host rules", Icons.Default.Shield, onClick = onShields)
                RowDivider(c)
                SwitchRow(c, "Privacy Report", "Show local blocked-request stats on the New Tab Page", privacyReport, onPrivacyReport, Icons.Default.Security)
                RowDivider(c)
                ListRow(
                    c, "Site settings", "Review site permissions and cookies", Icons.Default.Tune,
                    onClick = { onInfo("Site settings", "Orbit currently uses Android WebView site permission handling. Clear site data from Android app settings for a full reset.") }
                )
            }

            SectionLabel("Display", c)
            SectionCard(c) {
                ListRow(c, "Tabs", "$tabCount open · tab groups are not implemented yet", Icons.Default.Tab, onClick = onTabs)
                RowDivider(c)
                ListRow(c, "Appearance", themeLabel, Icons.Default.Palette, onClick = onAppearance)
                RowDivider(c)
                ListRow(
                    c, "New Tab Page", "Wallpaper, Privacy Stats and top sites", Icons.Default.AddBox,
                    onClick = { onInfo("New Tab Page", "The start page is the built-in Orbit Dunes screen with Privacy Stats and shortcuts to your bookmarks and recent sites.") }
                )
                RowDivider(c)
                SwitchRow(c, "Homepage", homepageUrl, homepageEnabled, onHomepage, Icons.Default.Home)
                RowDivider(c)
                SwitchRow(c, "Accessibility zoom", "Enable larger page text where supported", accessibilityZoom, onAccessibilityZoom, Icons.Default.Accessibility)
                RowDivider(c)
                SwitchRow(c, "Allow media autoplay", "Applies to tabs opened from now on", mediaAutoplay, onMediaAutoplay, Icons.Default.Movie)
                RowDivider(c)
                ListRow(
                    c, "Languages", "App language follows Android system language", Icons.Default.Language,
                    onClick = { onInfo("Languages", "Orbit currently follows the device language. Per-app language selection is not implemented.") }
                )
            }

            SectionLabel("Browser", c)
            SectionCard(c) {
                ListRow(c, "Search engine", searchEngine, Icons.Default.Search, onClick = onSearchEngine)
                RowDivider(c)
                SwitchRow(c, "Notifications", "Download notifications are managed by Android", notifications, onNotifications, Icons.Default.Notifications)
                RowDivider(c)
                ListRow(c, "Downloads", "Files downloaded by Orbit", Icons.Default.Download, onClick = onDownloads)
                RowDivider(c)
                ListRow(c, "Add-ons & plugins", "Browse, install and manage Orbit add-ons", Icons.Default.Extension, onClick = onAddons)
                RowDivider(c)
                SwitchRow(c, "Sync", "Placeholder — no account service is connected", sync, onSync, Icons.Default.Sync)
                RowDivider(c)
                ListRow(
                    c, "Home screen widget", "Not included in this starter build", Icons.Default.Widgets,
                    onClick = { onInfo("Home screen widget", "A launcher widget requires an Android AppWidget provider and is not implemented yet.") }
                )
                RowDivider(c)
                ListRow(c, "Default browser", "Choose Orbit in Android system settings", Icons.Default.OpenInBrowser, onClick = onDefaultBrowser)
            }

            SectionLabel("About", c)
            SectionCard(c) {
                ListRow(
                    c, "Orbit Origin", "About this browser and current engine", Icons.Default.Info,
                    onClick = { onInfo("Orbit Origin", "Orbit is a native Kotlin + Jetpack Compose app using Android System WebView (Chromium-based), not a bundled custom Chromium build.") }
                )
            }
        }
    }
}

// ───────────────────────── Add-ons ─────────────────────────

@Composable
internal fun AddonsPage(
    c: OrbitColors,
    installed: Set<String>,
    forceDarkOn: Boolean,
    onBack: () -> Unit,
    onInstall: (String) -> Unit,
    onRemove: (String) -> Unit,
    onRun: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = OrbitAddons.filter { it.name.contains(query, ignoreCase = true) || it.desc.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize().background(c.bg)) {
        PageHeader("Add-ons", c, onBack)
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PillField(c, query, { query = it }, "Search add-ons", icon = Icons.Default.Search) }
            item {
                Text(
                    "These are Orbit-native add-ons, not Firefox WebExtensions. The current WebView engine cannot install arbitrary extension packages.",
                    color = c.sub, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
            item {
                Text(
                    "${installed.size} installed · ${OrbitAddons.size} available", color = c.sub.copy(alpha = .8f),
                    fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
            items(shown, key = { it.key }) { addon ->
                val isInstalled = addon.key in installed
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(c.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(c.pill), contentAlignment = Alignment.Center) {
                            Icon(addon.icon, null, tint = c.accent)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(addon.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text(
                                if (isInstalled) "Installed" else "Available",
                                color = if (isInstalled) Color(0xFF64DDAA) else c.sub, fontSize = 12.sp
                            )
                        }
                    }
                    Text(addon.desc, color = c.sub, fontSize = 13.sp, lineHeight = 18.sp)
                    if (isInstalled) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onRun(addon.key) }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                            ) { Text(if (addon.key == "force_dark" && forceDarkOn) "Turn off" else if (addon.key == "force_dark") "Run" else "Open") }
                            OutlinedButton(onClick = { onRemove(addon.key) }) { Text("Remove", color = c.text) }
                        }
                    } else {
                        Button(
                            onClick = { onInstall(addon.key) }, modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                        ) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Install add-on")
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Custom host rules ─────────────────────────

@Composable
internal fun FiltersPage(
    c: OrbitColors,
    blocked: Set<String>,
    allowed: Set<String>,
    onBack: () -> Unit,
    onBlock: (String) -> Unit,
    onAllow: (String) -> Unit,
    onRemoveBlocked: (String) -> Unit,
    onRemoveAllowed: (String) -> Unit
) {
    var host by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(c.bg)) {
        PageHeader("Custom host rules", c, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Text(
                "Enter a hostname such as ads.example.com. This is not a full EasyList parser.",
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
            )
            PillField(c, host, { host = it }, "Hostname", Modifier.padding(horizontal = 12.dp), Icons.Default.Shield, KeyboardType.Uri, ImeAction.Done)
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onBlock(host); host = "" },
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) { Text("Block host") }
                OutlinedButton(onClick = { onAllow(host); host = "" }) { Text("Allow host", color = c.text) }
            }
            SectionLabel("Blocked", c)
            SectionCard(c) {
                if (blocked.isEmpty()) ListRow(c, "None") else blocked.sorted().forEachIndexed { i, h ->
                    if (i > 0) RowDivider(c, 16.dp)
                    ListRow(c, h, trailing = { IconButton(onClick = { onRemoveBlocked(h) }) { Icon(Icons.Default.Close, "Remove", tint = c.sub) } })
                }
            }
            SectionLabel("Allowed", c)
            SectionCard(c) {
                if (allowed.isEmpty()) ListRow(c, "None") else allowed.sorted().forEachIndexed { i, h ->
                    if (i > 0) RowDivider(c, 16.dp)
                    ListRow(c, h, trailing = { IconButton(onClick = { onRemoveAllowed(h) }) { Icon(Icons.Default.Close, "Remove", tint = c.sub) } })
                }
            }
        }
    }
}

// ───────────────────────── Shields bottom sheet ─────────────────────────

@Composable
private fun StatTile(c: OrbitColors, value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(c.pill).padding(14.dp)) {
        Text(value, color = color, fontSize = 28.sp, fontWeight = FontWeight.Medium)
        Text(label, color = c.sub, fontSize = 12.sp)
    }
}

@Composable
internal fun ShieldsSheet(
    c: OrbitColors,
    host: String,
    enabled: Boolean,
    blockedHere: Int,
    blockedTotal: Long,
    onToggle: (Boolean) -> Unit,
    onAdvanced: () -> Unit,
    onClose: () -> Unit
) {
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose)
    ) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(c.menu)
                .pointerInput(Unit) { detectTapGestures { } }
                .navigationBarsPadding().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).width(38.dp).height(4.dp)
                    .clip(RoundedCornerShape(2.dp)).background(c.divider)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(c.pill), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Shield, null, tint = if (enabled) c.accent else c.sub, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(host.ifBlank { "No site open" }, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (host.isBlank()) "Open a website to manage its Shields" else if (enabled) "Shields are UP" else "Shields are DOWN",
                        color = if (enabled && host.isNotBlank()) c.accent else c.sub, fontSize = 13.sp
                    )
                }
                Switch(
                    checked = host.isNotBlank() && enabled, enabled = host.isNotBlank(), onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = c.onAccent, checkedTrackColor = c.accent,
                        uncheckedThumbColor = c.sub, uncheckedTrackColor = c.bar, uncheckedBorderColor = c.sub
                    )
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(c, blockedHere.toString(), "Blocked on this page", OrbitOrange, Modifier.weight(1f))
                StatTile(c, blockedTotal.toString(), "Blocked all time", OrbitPeri, Modifier.weight(1f))
            }
            OutlinedButton(onClick = onAdvanced, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(50)) {
                Text("Custom host rules", color = c.text)
            }
            Text(
                "Protection is a basic host-based filter, not a complete Brave-equivalent engine.",
                color = c.sub, fontSize = 12.sp
            )
        }
    }
}

// ───────────────────────── three-dot menu ─────────────────────────

internal enum class MenuAction {
    NEW_TAB, PRIVATE_TAB, TAB_GROUP, HISTORY, DOWNLOADS, BOOKMARKS, RECENT_TABS, ADD_BOOKMARK,
    FIND, TRANSLATE, READER, DESKTOP, SHRED, SHIELDS, ADDONS, SETTINGS, FORWARD, SHARE, RELOAD
}

@Composable
internal fun BrowserMenu(
    c: OrbitColors,
    desktopSite: Boolean,
    canForward: Boolean,
    loading: Boolean,
    onDismiss: () -> Unit,
    onAction: (MenuAction) -> Unit
) {
    Box(
        Modifier.fillMaxSize().background(Color(0x66000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
    ) {
        Column(
            Modifier.align(Alignment.BottomEnd).windowInsetsPadding(WindowInsets.systemBars).padding(10.dp)
                .fillMaxWidth(0.82f).widthIn(max = 330.dp)
                .clip(RoundedCornerShape(28.dp)).background(c.menu)
                .pointerInput(Unit) { detectTapGestures { } }
        ) {
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                MenuRow(Icons.Default.Add, "New tab", c) { onAction(MenuAction.NEW_TAB) }
                MenuRow(Icons.Default.VisibilityOff, "New Private tab", c) { onAction(MenuAction.PRIVATE_TAB) }
                MenuRow(Icons.Default.Dashboard, "Add tab to new group", c) { onAction(MenuAction.TAB_GROUP) }
                MenuDivider(c)
                MenuRow(Icons.Default.History, "History", c) { onAction(MenuAction.HISTORY) }
                MenuRow(Icons.Default.Download, "Downloads", c) { onAction(MenuAction.DOWNLOADS) }
                MenuRow(Icons.Default.Bookmarks, "Bookmarks", c) { onAction(MenuAction.BOOKMARKS) }
                MenuRow(Icons.Default.Tab, "Recent tabs", c) { onAction(MenuAction.RECENT_TABS) }
                MenuDivider(c)
                MenuRow(Icons.Default.BookmarkAdd, "Bookmark this page", c) { onAction(MenuAction.ADD_BOOKMARK) }
                MenuRow(Icons.Default.FindInPage, "Find in page", c) { onAction(MenuAction.FIND) }
                MenuRow(Icons.Default.Translate, "Translate…", c) { onAction(MenuAction.TRANSLATE) }
                MenuRow(Icons.Default.MenuBook, "Show Reading mode", c) { onAction(MenuAction.READER) }
                MenuRow(
                    Icons.Default.DesktopWindows, "Desktop site", c,
                    trailing = {
                        Checkbox(
                            checked = desktopSite, onCheckedChange = null,
                            colors = CheckboxDefaults.colors(checkedColor = c.accent, uncheckedColor = c.sub, checkmarkColor = c.onAccent)
                        )
                    }
                ) { onAction(MenuAction.DESKTOP) }
                MenuRow(Icons.Default.DeleteSweep, "Shred site data", c) { onAction(MenuAction.SHRED) }
                MenuDivider(c)
                MenuRow(Icons.Default.Shield, "Shields & privacy", c) { onAction(MenuAction.SHIELDS) }
                MenuRow(Icons.Default.Extension, "Add-ons", c) { onAction(MenuAction.ADDONS) }
                MenuRow(Icons.Default.Settings, "Settings", c) { onAction(MenuAction.SETTINGS) }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CircleButton(Icons.AutoMirrored.Filled.ArrowForward, "Forward", c, enabled = canForward) { onAction(MenuAction.FORWARD) }
                CircleButton(Icons.Default.Share, "Share", c) { onAction(MenuAction.SHARE) }
                CircleButton(Icons.Default.Download, "Downloads", c) { onAction(MenuAction.DOWNLOADS) }
                CircleButton(if (loading) Icons.Default.Close else Icons.Default.Refresh, if (loading) "Stop" else "Reload", c) { onAction(MenuAction.RELOAD) }
            }
        }
    }
}
