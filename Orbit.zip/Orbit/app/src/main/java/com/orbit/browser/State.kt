package com.orbit.browser

import android.webkit.WebView
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Translate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector

/** Full-screen pages. Shields, the menu and find-in-page are overlays and live elsewhere. */
internal enum class Panel { NONE, TABS, BOOKMARKS, HISTORY, FILTERS, SETTINGS, ADDONS }

internal class TabState(val id: Long, val view: WebView, val isPrivate: Boolean) {
    var url by mutableStateOf("about:blank")
    var title by mutableStateOf("New tab")
    var loading by mutableStateOf(false)
    var progress by mutableIntStateOf(0)
    var blocked by mutableIntStateOf(0)
    var desktop by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var findIndex by mutableIntStateOf(0)
    var findTotal by mutableIntStateOf(0)
}

internal data class AddonInfo(val key: String, val name: String, val desc: String, val icon: ImageVector)

internal val OrbitAddons = listOf(
    AddonInfo("reader_mode", "Reader Mode", "Apply a distraction-reduced reading style to the current page.", Icons.Default.MenuBook),
    AddonInfo("force_dark", "Force Dark Pages", "Try WebView's dark-page rendering where supported.", Icons.Default.DarkMode),
    AddonInfo("translate", "Page Translator", "Open the current page in Google Translate.", Icons.Default.Translate),
    AddonInfo("share", "Quick Share", "Share the current page using Android's share sheet.", Icons.Default.Share),
    AddonInfo("cookie_cleaner", "Cookie Cleaner", "Clear browser cookies and site storage; this may sign you out of websites.", Icons.Default.DeleteSweep),
    AddonInfo("find_page", "Find in Page", "Search text on the current webpage.", Icons.Default.FindInPage)
)
