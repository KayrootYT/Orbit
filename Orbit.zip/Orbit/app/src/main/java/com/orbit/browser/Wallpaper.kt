package com.orbit.browser

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path

/**
 * Original "Orbit Dunes" wallpaper drawn with Canvas: dusk sky, low sun glow and layered dunes.
 * Used behind the New Tab Page, like the photo backgrounds in modern mobile browsers.
 */
@Composable
internal fun OrbitWallpaper(modifier: Modifier = Modifier, privateMode: Boolean = false) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height

        val sky = if (privateMode) {
            arrayOf(
                0f to Color(0xFF0D0A1F), .38f to Color(0xFF2A1F4D), .56f to Color(0xFF5C3F8A),
                .66f to Color(0xFFB77AC0), 1f to Color(0xFF1B1228)
            )
        } else {
            arrayOf(
                0f to Color(0xFF08121F), .36f to Color(0xFF16324D), .54f to Color(0xFF5D4A7C),
                .65f to Color(0xFFE39A62), 1f to Color(0xFF2A1E2E)
            )
        }
        drawRect(Brush.verticalGradient(colorStops = sky))

        // soft clouds
        drawOval(Color(0x1FFFFFFF), Offset(w * .05f, h * .17f), Size(w * .75f, h * .06f))
        drawOval(Color(0x16FFFFFF), Offset(w * .35f, h * .25f), Size(w * .7f, h * .05f))
        drawOval(Color(0x14FFD2A8), Offset(-w * .1f, h * .33f), Size(w * .8f, h * .045f))

        // low sun glow
        val glowCenter = Offset(w * .2f, h * .62f)
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0x88FFB070), Color(0x33FF8A5B), Color.Transparent),
                center = glowCenter, radius = w * .75f
            ),
            radius = w * .75f, center = glowCenter
        )

        fun dune(baseY: Float, amp: Float, shift: Float, top: Color, bottom: Color) {
            val p = Path().apply {
                moveTo(0f, h)
                lineTo(0f, baseY + shift)
                cubicTo(w * .25f, baseY - amp, w * .45f, baseY + amp * .6f, w * .65f, baseY - amp * .4f)
                cubicTo(w * .8f, baseY - amp * .9f, w * .92f, baseY - amp * .2f, w, baseY - amp * .5f)
                lineTo(w, h)
                close()
            }
            drawPath(p, Brush.verticalGradient(listOf(top, bottom), startY = baseY - amp, endY = h))
        }

        dune(h * .58f, h * .035f, 0f, Color(0xFF4B3A66), Color(0xFF2B2442))
        dune(h * .68f, h * .05f, h * .02f, Color(0xFF3B3458), Color(0xFF1F1B35))
        dune(h * .80f, h * .06f, -h * .02f, Color(0xFF8D5C55), Color(0xFF2B1E2C))
        dune(h * .93f, h * .045f, 0f, Color(0xFF241A2C), Color(0xFF120D18))

        // darken the top so the toolbar and cards stay readable
        drawRect(Brush.verticalGradient(listOf(Color(0x88000000), Color.Transparent), startY = 0f, endY = h * .45f))
    }
}
