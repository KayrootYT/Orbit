package com.orbit.browser

import android.content.Context
import android.webkit.WebResourceRequest
import java.net.URI

/**
 * Lightweight WebView request filter. This is an initial host-based filter, not a complete
 * EasyList/Brave Shields implementation. The list is deliberately small and can be updated.
 */
class OrbitBlocker(private val data: BrowserData) {
    @Volatile var blockedCount: Int = 0
        private set

    private val bundledBlockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com",
        "outbrain.com", "scorecardresearch.com", "adform.net"
    )

    fun resetCounter() { blockedCount = 0 }

    fun shouldBlock(request: WebResourceRequest, mainHost: String, shieldsEnabled: Boolean): Boolean {
        if (!shieldsEnabled || request.isForMainFrame) return false
        val targetHost = request.url.host?.lowercase().orEmpty()
        if (targetHost.isBlank()) return false
        val allowed = data.customAllowedHosts()
        if (allowed.any { targetHost == it || targetHost.endsWith(".$it") }) return false

        val custom = data.customBlockedHosts()
        val matchesCustom = custom.any { targetHost == it || targetHost.endsWith(".$it") }
        val matchesBundled = bundledBlockedHosts.any { targetHost == it || targetHost.endsWith(".$it") }
        val sameSite = mainHost.isNotBlank() && (targetHost == mainHost || targetHost.endsWith(".$mainHost"))
        val thirdPartyAdPath = request.url.encodedPath.lowercase().let {
            it.contains("/ads/") || it.contains("/adserver") || it.contains("/advert")
        }
        val block = matchesCustom || matchesBundled || (!sameSite && thirdPartyAdPath)
        if (block) blockedCount++
        return block
    }

    fun addBlockedHost(hostInput: String) {
        val host = cleanHost(hostInput) ?: return
        data.setCustomBlockedHosts(data.customBlockedHosts() + host)
    }

    fun addAllowedHost(hostInput: String) {
        val host = cleanHost(hostInput) ?: return
        data.setCustomAllowedHosts(data.customAllowedHosts() + host)
    }

    private fun cleanHost(value: String): String? {
        val raw = value.trim().removePrefix("||").removeSuffix("^").lowercase()
        val host = runCatching { URI("https://$raw").host?.lowercase() }.getOrNull()
        if (host.isNullOrBlank() || !host.contains('.') || host.any { it.isWhitespace() }) return null
        return host
    }
}
