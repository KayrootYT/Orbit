package com.orbit.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── page chrome ─────────────────────────

@Composable
internal fun PageHeader(
    title: String,
    c: OrbitColors,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().background(c.bar).statusBarsPadding().height(60.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = c.text)
        }
        Text(
            title, color = c.text, style = MaterialTheme.typography.titleLarge,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(start = 4.dp)
        )
        actions()
    }
}

@Composable
internal fun SectionLabel(text: String, c: OrbitColors) {
    Text(
        text.uppercase(), color = c.accent, style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 26.dp, end = 24.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
internal fun SectionCard(c: OrbitColors, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.padding(horizontal = 12.dp).fillMaxWidth()
            .clip(RoundedCornerShape(22.dp)).background(c.surface),
        content = content
    )
}

@Composable
internal fun RowDivider(c: OrbitColors, startPadding: Dp = 54.dp) {
    HorizontalDivider(Modifier.padding(start = startPadding), thickness = 1.dp, color = c.divider)
}

@Composable
internal fun ListRow(
    c: OrbitColors,
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = c.accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(16.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, color = c.sub, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        } else if (onClick != null) {
            Icon(Icons.Default.ChevronRight, null, tint = c.sub)
        }
    }
}

@Composable
internal fun SwitchRow(
    c: OrbitColors,
    title: String,
    subtitle: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    icon: ImageVector? = null
) {
    ListRow(
        c, title, subtitle, icon,
        onClick = { onChange(!checked) },
        trailing = {
            Switch(
                checked = checked, onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = c.onAccent, checkedTrackColor = c.accent,
                    uncheckedThumbColor = c.sub, uncheckedTrackColor = c.pill, uncheckedBorderColor = c.sub
                )
            )
        }
    )
}

@Composable
internal fun SiteAvatar(label: String, size: Dp = 40.dp) {
    val clean = label.trim().removePrefix("www.")
    val hue = (clean.lowercase().hashCode() and 0x7fffffff) % 360
    Box(
        Modifier.size(size).clip(CircleShape).background(Color.hsv(hue.toFloat(), 0.45f, 0.55f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            clean.firstOrNull()?.uppercase() ?: "•",
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp
        )
    }
}

@Composable
internal fun PillField(
    c: OrbitColors,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Done,
    onAction: () -> Unit = {}
) {
    Row(
        modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp)).background(c.pill),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = c.sub, modifier = Modifier.padding(start = 16.dp).size(22.dp))
        }
        BasicTextField(
            value = value, onValueChange = onValueChange, singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
            keyboardActions = KeyboardActions(onDone = { onAction() }, onGo = { onAction() }, onSearch = { onAction() }),
            modifier = Modifier.weight(1f).padding(horizontal = 14.dp),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = c.sub, fontSize = 16.sp, maxLines = 1)
                    inner()
                }
            }
        )
    }
}

@Composable
internal fun MenuRow(
    icon: ImageVector,
    label: String,
    c: OrbitColors,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).height(50.dp).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = c.text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (trailing != null) trailing()
    }
}

@Composable
internal fun MenuDivider(c: OrbitColors) {
    HorizontalDivider(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), thickness = 1.dp, color = c.divider)
}

@Composable
internal fun CircleButton(icon: ImageVector, desc: String, c: OrbitColors, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(50.dp).clip(CircleShape).background(c.pill)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = c.text, modifier = Modifier.size(24.dp).alpha(if (enabled) 1f else 0.4f))
    }
}

// ───────────────────────── browser toolbars ─────────────────────────

@Composable
internal fun AddressBar(
    c: OrbitColors,
    value: String,
    privateMode: Boolean,
    shieldsOn: Boolean,
    focusRequester: FocusRequester,
    onValueChange: (String) -> Unit,
    onGo: (String) -> Unit,
    onFocusChange: (Boolean) -> Unit,
    onShields: () -> Unit,
    onAddons: () -> Unit
) {
    var field by remember { mutableStateOf(TextFieldValue(value)) }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(value) { if (field.text != value) field = TextFieldValue(value) }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(50.dp)
            .clip(RoundedCornerShape(25.dp)).background(c.pill)
            .then(if (privateMode) Modifier.border(1.5.dp, OrbitPrivate, RoundedCornerShape(25.dp)) else Modifier),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Default.Tune, "Site info", tint = c.text,
            modifier = Modifier.padding(start = 16.dp, end = 12.dp).size(22.dp)
        )
        BasicTextField(
            value = field,
            onValueChange = { field = it; onValueChange(it.text) },
            singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { onGo(field.text) }),
            modifier = Modifier.weight(1f)
                .focusRequester(focusRequester)
                .onFocusChanged {
                    if (it.isFocused && !focused) field = field.copy(selection = TextRange(0, field.text.length))
                    focused = it.isFocused
                    onFocusChange(it.isFocused)
                },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (field.text.isEmpty()) {
                        Text(
                            if (privateMode) "Search privately or type URL" else "Search Orbit or type URL",
                            color = c.sub, fontSize = 16.sp, maxLines = 1
                        )
                    }
                    inner()
                }
            }
        )
        if (focused && field.text.isNotEmpty()) {
            IconButton(onClick = { field = TextFieldValue(""); onValueChange("") }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Default.Close, "Clear", tint = c.sub, modifier = Modifier.size(20.dp))
            }
        }
        IconButton(onClick = onShields, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Shield, "Shields", tint = if (shieldsOn) c.accent else c.sub, modifier = Modifier.size(24.dp))
        }
        IconButton(onClick = onAddons, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Extension, "Add-ons", tint = c.text, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(6.dp))
    }
}

@Composable
internal fun FindBar(
    c: OrbitColors,
    query: String,
    index: Int,
    total: Int,
    onQuery: (String) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(50.dp)
            .clip(RoundedCornerShape(25.dp)).background(c.pill),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.FindInPage, null, tint = c.text, modifier = Modifier.padding(start = 16.dp, end = 12.dp).size(22.dp))
        BasicTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onNext() }),
            modifier = Modifier.weight(1f).focusRequester(focus),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Find in page", color = c.sub, fontSize = 16.sp)
                    inner()
                }
            }
        )
        if (query.isNotBlank()) {
            Text(
                if (total == 0) "0/0" else "${index + 1}/$total",
                color = c.sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
        IconButton(onClick = onPrev, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.KeyboardArrowUp, "Previous", tint = c.text) }
        IconButton(onClick = onNext, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.KeyboardArrowDown, "Next", tint = c.text) }
        IconButton(onClick = onClose, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Close, "Close find", tint = c.text) }
        Spacer(Modifier.width(6.dp))
    }
}

@Composable
internal fun BottomBar(
    c: OrbitColors,
    tabCount: Int,
    privateMode: Boolean,
    onHome: () -> Unit,
    onBookmarks: () -> Unit,
    onSearch: () -> Unit,
    onTabs: () -> Unit,
    onMenu: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(c.bar).navigationBarsPadding().height(58.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onHome, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Home, "Home", tint = c.text) }
        IconButton(onClick = onBookmarks, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Bookmarks, "Bookmarks", tint = c.text) }
        IconButton(onClick = onSearch, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Search, "Search", tint = c.text) }
        IconButton(onClick = onTabs, modifier = Modifier.weight(1f)) {
            val tint = if (privateMode) OrbitPrivate else c.text
            Box(
                Modifier.size(26.dp).border(2.dp, tint, RoundedCornerShape(7.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("$tabCount", color = tint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
        IconButton(onClick = onMenu, modifier = Modifier.weight(1f)) { Icon(Icons.Default.MoreVert, "Menu", tint = c.text) }
    }
}
