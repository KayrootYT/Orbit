package com.orbit.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

private val OrbitBlue = Color(0xFF54D8FF)
private val OrbitNavy = Color(0xFF08111F)
private enum class OrbitTheme { LIGHT, DARK, AMOLED }
private enum class Panel { NONE, SHIELDS, TABS, BOOKMARKS, HISTORY, FILTERS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = BrowserData(applicationContext)
        setContent { OrbitApp(data, this) }
    }
}

private class TabState(val id: Long, val view: WebView) {
    var url by mutableStateOf("about:blank")
    var title by mutableStateOf("New tab")
    var loading by mutableStateOf(false)
    var blocked by mutableIntStateOf(0)
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun OrbitApp(data: BrowserData, activity: ComponentActivity) {
    val context = activity
    var themeName by remember { mutableStateOf(OrbitTheme.DARK) }
    var address by remember { mutableStateOf("") }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var selectedId by remember { mutableLongStateOf(1L) }
    var nextId by remember { mutableLongStateOf(2L) }
    var tabs by remember { mutableStateOf(listOf<TabState>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var customHost by remember { mutableStateOf("") }
    val keyboard = LocalSoftwareKeyboardController.current
    val blocker = remember { OrbitBlocker(data) }

    val isDark = themeName != OrbitTheme.LIGHT
    val bg = when (themeName) {
        OrbitTheme.LIGHT -> Color(0xFFF4F7FB)
        OrbitTheme.DARK -> Color(0xFF08111F)
        OrbitTheme.AMOLED -> Color.Black
    }
    val fg = if (isDark) Color(0xFFF4F8FF) else Color(0xFF111827)
    val card = when (themeName) {
        OrbitTheme.LIGHT -> Color.White
        OrbitTheme.DARK -> Color(0xFF121E30)
        OrbitTheme.AMOLED -> Color(0xFF080808)
    }
    val selected = tabs.firstOrNull { it.id == selectedId }

    fun createTab(initialUrl: String = "about:blank") {
        val id = nextId++
        val view = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_OFF)
            }
        }
        val tab = TabState(id, view)
        view.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: tab.url
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.loading = newProgress < 100
            }
        }
        view.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            runCatching {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    .setDescription("Downloading with Orbit")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme !in listOf("https", "http")) return true
                return false
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): android.webkit.WebResourceResponse? {
                val mainHost = OrbitUrl.host(tab.url)
                val host = request?.url?.host?.lowercase().orEmpty()
                val shieldsOn = data.shieldEnabled(mainHost)
                if (request != null && blocker.shouldBlock(request, mainHost, shieldsOn)) {
                    tab.blocked = blocker.blockedCount
                    return android.webkit.WebResourceResponse("text/plain", "utf-8", 204, "Blocked", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.loading = true
                if (url != null) { tab.url = url; address = url }
                refresh++
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                if (url != null) {
                    tab.url = url
                    address = url
                    data.addHistory(tab.title, url)
                }
                tab.blocked = blocker.blockedCount
                refresh++
            }
        }
        tabs = tabs + tab
        selectedId = id
        if (initialUrl != "about:blank") view.loadUrl(initialUrl)
    }

    fun navigate(raw: String) {
        val target = OrbitUrl.normalize(raw)
        if (target == "about:blank") return
        selected?.view?.loadUrl(target)
        address = target
        panel = Panel.NONE
        keyboard?.hide()
    }

    fun closeTab(id: Long) {
        val tab = tabs.firstOrNull { it.id == id } ?: return
        tab.view.stopLoading()
        tab.view.destroy()
        val remaining = tabs.filterNot { it.id == id }
        tabs = remaining
        if (remaining.isEmpty()) {
            selectedId = -1L
            createTab()
        } else if (selectedId == id) selectedId = remaining.last().id
        refresh++
    }

    LaunchedEffect(Unit) { createTab() }
    DisposableEffect(Unit) {
        onDispose { tabs.forEach { runCatching { it.view.stopLoading(); it.view.destroy() } } }
    }

    MaterialTheme(colorScheme = if (isDark) darkColorScheme(primary = OrbitBlue, background = bg, surface = card, onBackground = fg, onSurface = fg)
        else lightColorScheme(primary = Color(0xFF007FAD), background = bg, surface = card, onBackground = fg, onSurface = fg)) {
        BackHandler(enabled = selected?.view?.canGoBack() == true && panel == Panel.NONE) { selected?.view?.goBack() }
        Column(Modifier.fillMaxSize().background(bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ORBIT", style = MaterialTheme.typography.titleLarge, color = fg)
                    Text("Browse beyond limits", style = MaterialTheme.typography.labelSmall, color = OrbitBlue)
                }
                IconButton(onClick = { panel = Panel.SHIELDS }) {
                    Icon(Icons.Default.Shield, "Site Shields", tint = if (selected?.let { data.shieldEnabled(OrbitUrl.host(it.url)) } != false) OrbitBlue else fg)
                }
                IconButton(onClick = { panel = Panel.TABS }) {
                    Icon(Icons.Default.Tab, "Tabs", tint = fg)
                    Text("${tabs.size}", color = fg, style = MaterialTheme.typography.labelSmall)
                }
                Box {
                    var themeMenu by remember { mutableStateOf(false) }
                    IconButton(onClick = { themeMenu = true }) { Icon(Icons.Default.Palette, "Theme", tint = fg) }
                    DropdownMenu(expanded = themeMenu, onDismissRequest = { themeMenu = false }) {
                        DropdownMenuItem(text = { Text("Light") }, onClick = { themeName = OrbitTheme.LIGHT; themeMenu = false })
                        DropdownMenuItem(text = { Text("Dark") }, onClick = { themeName = OrbitTheme.DARK; themeMenu = false })
                        DropdownMenuItem(text = { Text("AMOLED") }, onClick = { themeName = OrbitTheme.AMOLED; themeMenu = false })
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(card, RoundedCornerShape(18.dp)).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = OrbitBlue)
                TextField(
                    value = address, onValueChange = { address = it }, modifier = Modifier.weight(1f),
                    singleLine = true, placeholder = { Text("Search or enter website") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { navigate(address) }),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
                )
                TextButton(onClick = { navigate(address) }) { Text("GO") }
            }

            if (selected?.loading == true) LinearProgressIndicator(Modifier.fillMaxWidth(), color = OrbitBlue)

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (panel == Panel.NONE) {
                    if (selected == null || selected.url == "about:blank") {
                        Column(Modifier.align(Alignment.Center).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(76.dp).background(Color(0xFF102B40), CircleShape), contentAlignment = Alignment.Center) {
                                Text("O", style = MaterialTheme.typography.displayMedium, color = OrbitBlue)
                            }
                            Spacer(Modifier.height(16.dp))
                            Text("Your space on the web", style = MaterialTheme.typography.titleLarge, color = fg)
                            Text("Private by design. Fast by default.", color = fg.copy(alpha = .65f))
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(onClick = { panel = Panel.BOOKMARKS }) { Text("Bookmarks") }
                                FilledTonalButton(onClick = { panel = Panel.HISTORY }) { Text("History") }
                            }
                        }
                    }
                    selected?.let { tab ->
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { tab.view },
                            update = { if (it.url != tab.url && tab.url != "about:blank") address = tab.url }
                        )
                    }
                } else {
                    when (panel) {
                        Panel.SHIELDS -> {
                            val host = OrbitUrl.host(selected?.url.orEmpty())
                            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Privacy Shields", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                Text(if (host.isBlank()) "Open a website to manage its Shields." else host, color = OrbitBlue)
                                Card(colors = CardDefaults.cardColors(containerColor = card)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("Block known ad/tracker hosts", color = fg)
                                                Text("Applies to supported subresource requests", style = MaterialTheme.typography.bodySmall, color = fg.copy(alpha = .65f))
                                            }
                                            Switch(
                                                checked = host.isNotBlank() && data.shieldEnabled(host),
                                                enabled = host.isNotBlank(),
                                                onCheckedChange = { data.setShieldEnabled(host, it); refresh++ }
                                            )
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        Text("Blocked requests in active tab: ${selected?.blocked ?: 0}", color = fg)
                                    }
                                }
                                Text("Protection is a host-based starter filter, not a complete Brave-equivalent engine.", color = fg.copy(alpha = .6f), style = MaterialTheme.typography.bodySmall)
                                OutlinedButton(onClick = { panel = Panel.FILTERS }) { Text("Manage custom host rules") }
                            }
                        }
                        Panel.TABS -> {
                            Column(Modifier.fillMaxSize().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Tabs (${tabs.size})", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { createTab(); panel = Panel.NONE }) { Icon(Icons.Default.Add, "New tab", tint = fg) }
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                LazyColumn { items(tabs, key = { it.id }) { tab ->
                                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { selectedId = tab.id; address = tab.url; panel = Panel.NONE },
                                        colors = CardDefaults.cardColors(containerColor = card)) {
                                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(tab.title, color = fg, maxLines = 1)
                                                Text(tab.url, color = fg.copy(alpha = .6f), maxLines = 1, style = MaterialTheme.typography.bodySmall)
                                            }
                                            IconButton(onClick = { closeTab(tab.id) }) { Icon(Icons.Default.Close, "Close tab", tint = fg) }
                                        }
                                    }
                                } }
                            }
                        }
                        Panel.BOOKMARKS -> {
                            val bookmarks = remember(refresh) { data.bookmarks() }
                            Column(Modifier.fillMaxSize().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Bookmarks", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                LazyColumn { items(bookmarks) { item ->
                                    ListItem(headlineContent = { Text(item.title) }, supportingContent = { Text(item.url, maxLines = 1) },
                                        modifier = Modifier.clickable { navigate(item.url) },
                                        trailingContent = { Icon(Icons.Default.OpenInBrowser, null) })
                                } }
                            }
                        }
                        Panel.HISTORY -> {
                            val history = remember(refresh) { data.history() }
                            Column(Modifier.fillMaxSize().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("History", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    TextButton(onClick = { data.clearHistory(); refresh++ }) { Text("Clear") }
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                LazyColumn { items(history) { item ->
                                    ListItem(headlineContent = { Text(item.title) }, supportingContent = { Text(item.url, maxLines = 1) },
                                        modifier = Modifier.clickable { navigate(item.url) })
                                } }
                            }
                        }
                        Panel.FILTERS -> {
                            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Custom host rules", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.SHIELDS }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                Text("Enter a hostname such as ads.example.com. This is not a full EasyList parser.", color = fg.copy(alpha = .65f))
                                OutlinedTextField(value = customHost, onValueChange = { customHost = it }, label = { Text("Hostname") }, modifier = Modifier.fillMaxWidth())
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { blocker.addBlockedHost(customHost); customHost = ""; refresh++ }) { Text("Block host") }
                                    OutlinedButton(onClick = { blocker.addAllowedHost(customHost); customHost = ""; refresh++ }) { Text("Allow host") }
                                }
                                Text("Blocked: ${data.customBlockedHosts().joinToString().ifBlank { "None" }}", color = fg)
                                Text("Allowed: ${data.customAllowedHosts().joinToString().ifBlank { "None" }}", color = fg)
                            }
                        }
                        Panel.NONE -> Unit
                    }
                }
            }

            Surface(color = card, shadowElevation = 8.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (selected?.view?.canGoBack() == true) selected.view.goBack() }, enabled = selected?.view?.canGoBack() == true) { Icon(Icons.Default.ArrowBack, "Back", tint = fg) }
                    IconButton(onClick = { if (selected?.view?.canGoForward() == true) selected.view.goForward() }, enabled = selected?.view?.canGoForward() == true) { Icon(Icons.Default.ArrowForward, "Forward", tint = fg) }
                    IconButton(onClick = { panel = Panel.NONE; selected?.view?.loadUrl("about:blank"); selected?.url = "about:blank"; address = "" }) { Icon(Icons.Default.Home, "Home", tint = fg) }
                    IconButton(onClick = { selected?.view?.reload() }) { Icon(Icons.Default.Refresh, "Reload", tint = fg) }
                    IconButton(onClick = {
                        val tab = selected
                        if (tab != null && tab.url.startsWith("http")) data.addBookmark(tab.title, tab.url)
                        refresh++
                    }) { Icon(Icons.Default.BookmarkAdd, "Add bookmark", tint = fg) }
                    IconButton(onClick = { panel = Panel.HISTORY }) { Icon(Icons.Default.History, "History", tint = fg) }
                    IconButton(onClick = { panel = Panel.TABS }) { Icon(Icons.Default.Tab, "Tabs", tint = fg) }
                }
            }
        }
    }
}
