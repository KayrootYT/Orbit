package com.orbit.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val data = BrowserData(applicationContext)
        setContent { OrbitApp(data, this) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun OrbitApp(data: BrowserData, activity: ComponentActivity) {
    val context = activity

    // ── UI state ──
    var themeName by remember {
        mutableStateOf(runCatching { OrbitTheme.valueOf(data.getString("theme", "DARK")) }.getOrDefault(OrbitTheme.DARK))
    }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var menuOpen by remember { mutableStateOf(false) }
    var shieldsOpen by remember { mutableStateOf(false) }
    var findOpen by remember { mutableStateOf(false) }
    var findText by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var tabsShowPrivate by remember { mutableStateOf(false) }
    var statsExpanded by remember { mutableStateOf(data.getBool("stats_expanded", true)) }
    var infoDialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    var searchDialog by remember { mutableStateOf(false) }
    var themeDialog by remember { mutableStateOf(false) }
    var addSiteDialog by remember { mutableStateOf(false) }

    // ── browser state ──
    var selectedId by remember { mutableLongStateOf(1L) }
    var nextId by remember { mutableLongStateOf(2L) }
    var tabs by remember { mutableStateOf(listOf<TabState>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var totalBlocked by remember { mutableLongStateOf(data.totalBlocked()) }

    // ── persisted settings ──
    var homepageEnabled by remember { mutableStateOf(data.getBool("homepage_enabled", true)) }
    var privacyReport by remember { mutableStateOf(data.getBool("privacy_report", true)) }
    var notificationsEnabled by remember { mutableStateOf(data.getBool("notifications", true)) }
    var mediaAutoplay by remember { mutableStateOf(data.getBool("media_autoplay", true)) }
    var accessibilityZoom by remember { mutableStateOf(data.getBool("accessibility_zoom", false)) }
    var syncEnabled by remember { mutableStateOf(data.getBool("sync_enabled", false)) }
    var searchEngine by remember { mutableStateOf(data.getString("search_engine", "Google")) }
    val homepageUrl = data.getString("homepage_url", "https://www.google.com")

    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val addressFocus = remember { FocusRequester() }
    val blocker = remember { OrbitBlocker(data) }
    val defaultUa = remember { WebSettings.getDefaultUserAgent(context) }

    @Suppress("UNUSED_VARIABLE")
    val tick = refresh // forces a recompose after refresh++ so values read straight from `data` stay current

    val c = orbitColors(themeName)
    val selected = tabs.firstOrNull { it.id == selectedId }
    val privateMode = selected?.isPrivate == true

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    fun info(title: String, detail: String) { infoDialog = title to detail }

    // ── tabs ──
    fun createTab(initialUrl: String = "about:blank", isPrivate: Boolean = false) {
        val id = nextId++
        val view = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.mediaPlaybackRequiresUserGesture = !data.getBool("media_autoplay", true)
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            if (data.getBool("accessibility_zoom", false)) settings.textZoom = 125
            if (isPrivate) settings.cacheMode = WebSettings.LOAD_NO_CACHE
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_OFF)
            }
        }
        val tab = TabState(id, view, isPrivate)
        view.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: tab.url
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                tab.loading = newProgress < 100
            }
        }
        view.setFindListener { ordinal, total, _ ->
            tab.findIndex = ordinal
            tab.findTotal = total
        }
        view.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            runCatching {
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(fileName)
                    .setDescription("Downloading with Orbit")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return uri.scheme !in listOf("https", "http")
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val mainHost = OrbitUrl.host(tab.url)
                val shieldsOn = data.shieldEnabled(mainHost)
                if (request != null && blocker.shouldBlock(request, mainHost, shieldsOn)) {
                    view?.post {
                        tab.blocked = tab.blocked + 1
                        totalBlocked = data.totalBlocked()
                    }
                    return WebResourceResponse("text/plain", "utf-8", 204, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.loading = true
                tab.blocked = 0
                if (url != null) tab.url = url
                tab.canBack = view?.canGoBack() == true
                tab.canForward = view?.canGoForward() == true
                refresh++
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                tab.progress = 100
                if (url != null) {
                    tab.url = url
                    if (!tab.isPrivate) data.addHistory(tab.title, url)
                }
                tab.canBack = view?.canGoBack() == true
                tab.canForward = view?.canGoForward() == true
                data.flushBlocked()
                totalBlocked = data.totalBlocked()
                refresh++
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                tab.canBack = view?.canGoBack() == true
                tab.canForward = view?.canGoForward() == true
            }
        }
        tabs = tabs + tab
        selectedId = id
        if (initialUrl != "about:blank") {
            tab.url = initialUrl
            view.loadUrl(initialUrl)
        }
    }

    fun destroyTab(tab: TabState) {
        runCatching { tab.view.stopLoading(); tab.view.destroy() }
    }

    fun closeTab(tab: TabState) {
        destroyTab(tab)
        val remaining = tabs.filterNot { it.id == tab.id }
        tabs = remaining
        if (remaining.isEmpty()) {
            selectedId = -1L
            tabsShowPrivate = false
            createTab()
        } else if (selectedId == tab.id) {
            selectedId = remaining.last().id
        }
    }

    fun closeAllTabs(privateOnes: Boolean) {
        val gone = tabs.filter { it.isPrivate == privateOnes }
        val keep = tabs.filter { it.isPrivate != privateOnes }
        gone.forEach { destroyTab(it) }
        tabs = keep
        if (keep.isEmpty()) {
            selectedId = -1L
            tabsShowPrivate = false
            createTab()
        } else if (keep.none { it.id == selectedId }) {
            selectedId = keep.last().id
        }
    }

    // ── navigation ──
    fun navigate(raw: String) {
        val target = OrbitUrl.normalize(raw, searchEngine)
        if (target == "about:blank") return
        val tab = selected ?: return
        tab.view.loadUrl(target)
        tab.url = target
        panel = Panel.NONE
        menuOpen = false
        shieldsOpen = false
        editing = false
        focusManager.clearFocus()
        keyboard?.hide()
    }

    fun goHome() {
        panel = Panel.NONE
        val tab = selected ?: return
        if (homepageEnabled) {
            navigate(homepageUrl)
        } else {
            tab.view.loadUrl("about:blank")
            tab.url = "about:blank"
            tab.title = "New tab"
        }
    }

    fun setDesktop(tab: TabState, on: Boolean) {
        tab.desktop = on
        tab.view.settings.apply {
            userAgentString = if (on) DESKTOP_UA else defaultUa
            useWideViewPort = on
            loadWithOverviewMode = on
        }
        tab.view.reload()
    }

    fun openFind() {
        findText = ""
        findOpen = true
    }

    fun closeFind() {
        selected?.view?.clearMatches()
        findOpen = false
        findText = ""
    }

    fun openDownloads() {
        runCatching { activity.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            .onFailure { info("Downloads", "Downloads are stored in Android's Downloads folder.") }
    }

    fun bookmarkCurrent() {
        val tab = selected
        if (tab != null && tab.url.startsWith("http")) {
            data.addBookmark(tab.title, tab.url)
            refresh++
            toast("Bookmark added")
        } else {
            toast("Open a web page first")
        }
    }

    fun runAddon(key: String) {
        val tab = selected
        when (key) {
            "reader_mode" -> {
                tab?.view?.evaluateJavascript(
                    "(function(){var s=document.getElementById('orbit-reader-style');if(s){s.remove();return;}s=document.createElement('style');s.id='orbit-reader-style';s.textContent='body{max-width:760px!important;margin:32px auto!important;padding:24px!important;background:#101722!important;color:#edf3ff!important;font:20px/1.8 Georgia,serif!important}img,video,iframe,nav,aside,footer,header,form{max-width:100%;}';document.head.appendChild(s);document.body.style.maxWidth='760px';})();",
                    null
                )
            }
            "force_dark" -> {
                val view = tab?.view ?: return
                if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                    val next = !data.getBool("addon_force_dark_on", false)
                    data.setBool("addon_force_dark_on", next)
                    WebSettingsCompat.setForceDark(view.settings, if (next) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF)
                    refresh++
                } else {
                    info("Force Dark Pages", "This Android System WebView version does not expose force-dark support. Update Android System WebView and try again.")
                }
            }
            "translate" -> {
                val url = tab?.url.orEmpty()
                if (url.startsWith("http")) navigate("https://translate.google.com/translate?sl=auto&tl=en&u=" + Uri.encode(url))
                else info("Page Translator", "Open a webpage first, then run the translator.")
            }
            "share" -> {
                val url = tab?.url.orEmpty()
                if (url.startsWith("http")) {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, url)
                        putExtra(Intent.EXTRA_SUBJECT, tab?.title)
                    }
                    activity.startActivity(Intent.createChooser(send, "Share with"))
                } else {
                    info("Quick Share", "Open a webpage first to share its link.")
                }
            }
            "cookie_cleaner" -> {
                WebStorage.getInstance().deleteAllData()
                CookieManager.getInstance().removeAllCookies { removed ->
                    CookieManager.getInstance().flush()
                    activity.runOnUiThread {
                        info(
                            "Site data cleared",
                            if (removed) "Cookies and site storage were cleared. Some websites may sign you out."
                            else "Site storage was cleared. No cookies were stored."
                        )
                    }
                }
            }
            "find_page" -> openFind()
        }
    }

    fun onMenuAction(action: MenuAction) {
        menuOpen = false
        when (action) {
            MenuAction.NEW_TAB -> { createTab(); panel = Panel.NONE }
            MenuAction.PRIVATE_TAB -> { createTab(isPrivate = true); panel = Panel.NONE }
            MenuAction.TAB_GROUP -> info("Tab groups", "Tab groups are not implemented in this starter build yet.")
            MenuAction.HISTORY -> panel = Panel.HISTORY
            MenuAction.DOWNLOADS -> openDownloads()
            MenuAction.BOOKMARKS -> panel = Panel.BOOKMARKS
            MenuAction.RECENT_TABS -> { tabsShowPrivate = privateMode; panel = Panel.TABS }
            MenuAction.ADD_BOOKMARK -> bookmarkCurrent()
            MenuAction.FIND -> openFind()
            MenuAction.TRANSLATE -> runAddon("translate")
            MenuAction.READER -> runAddon("reader_mode")
            MenuAction.DESKTOP -> selected?.let { setDesktop(it, !it.desktop) }
            MenuAction.SHRED -> runAddon("cookie_cleaner")
            MenuAction.SHIELDS -> shieldsOpen = true
            MenuAction.ADDONS -> panel = Panel.ADDONS
            MenuAction.SETTINGS -> panel = Panel.SETTINGS
            MenuAction.FORWARD -> selected?.view?.goForward()
            MenuAction.SHARE -> runAddon("share")
            MenuAction.RELOAD -> selected?.let { if (it.loading) it.view.stopLoading() else it.view.reload() }
        }
    }

    LaunchedEffect(Unit) { createTab() }
    DisposableEffect(Unit) {
        onDispose {
            data.flushBlocked()
            tabs.forEach { destroyTab(it) }
        }
    }

    // system bar icon colours follow the theme (edge-to-edge is enabled in onCreate)
    val view = LocalView.current
    SideEffect {
        val controller = WindowCompat.getInsetsController(activity.window, view)
        controller.isAppearanceLightStatusBars = !c.dark
        controller.isAppearanceLightNavigationBars = !c.dark
    }

    val scheme = if (c.dark) {
        darkColorScheme(primary = c.accent, onPrimary = c.onAccent, background = c.bg, surface = c.surface, onBackground = c.text, onSurface = c.text)
    } else {
        lightColorScheme(primary = c.accent, onPrimary = c.onAccent, background = c.bg, surface = c.surface, onBackground = c.text, onSurface = c.text)
    }

    MaterialTheme(colorScheme = scheme) {
        BackHandler(
            enabled = menuOpen || shieldsOpen || findOpen || editing || panel != Panel.NONE || selected?.canBack == true
        ) {
            when {
                menuOpen -> menuOpen = false
                shieldsOpen -> shieldsOpen = false
                findOpen -> closeFind()
                editing -> { focusManager.clearFocus(); keyboard?.hide() }
                panel == Panel.FILTERS -> { panel = Panel.NONE; shieldsOpen = true }
                panel != Panel.NONE -> panel = Panel.NONE
                selected?.canBack == true -> selected.view.goBack()
            }
        }

        Box(Modifier.fillMaxSize().background(c.bg)) {
            if (panel == Panel.NONE) {
                Column(Modifier.fillMaxSize().imePadding()) {
                    // ── top bar ──
                    Column(Modifier.fillMaxWidth().background(c.bar).statusBarsPadding()) {
                        if (findOpen) {
                            FindBar(
                                c = c, query = findText, index = selected?.findIndex ?: 0, total = selected?.findTotal ?: 0,
                                onQuery = {
                                    findText = it
                                    if (it.isBlank()) selected?.view?.clearMatches() else selected?.view?.findAllAsync(it)
                                },
                                onPrev = { selected?.view?.findNext(false) },
                                onNext = { selected?.view?.findNext(true) },
                                onClose = { closeFind() }
                            )
                        } else {
                            val shown = if (editing) typed else selected?.url?.takeIf { it != "about:blank" }.orEmpty()
                            AddressBar(
                                c = c, value = shown, privateMode = privateMode,
                                shieldsOn = selected?.let { data.shieldEnabled(OrbitUrl.host(it.url)) } != false,
                                focusRequester = addressFocus,
                                onValueChange = { typed = it },
                                onGo = { navigate(it) },
                                onFocusChange = { focused ->
                                    if (focused && !editing) typed = shown
                                    editing = focused
                                },
                                onShields = { shieldsOpen = true },
                                onAddons = { panel = Panel.ADDONS }
                            )
                        }
                        val progress by animateFloatAsState((selected?.progress ?: 0) / 100f, label = "pageProgress")
                        Box(Modifier.fillMaxWidth().height(2.dp)) {
                            if (selected?.loading == true) {
                                Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().background(c.accent))
                            }
                        }
                    }

                    // ── content ──
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when {
                            editing && typed.isNotBlank() -> {
                                val entries = remember(typed) {
                                    val q = typed.trim()
                                    (data.bookmarks() + data.history().map { Bookmark(it.title, it.url) })
                                        .filter { it.title.contains(q, ignoreCase = true) || it.url.contains(q, ignoreCase = true) }
                                        .distinctBy { it.url }
                                        .take(8)
                                }
                                SuggestionList(c, typed.trim(), entries) { navigate(it) }
                            }
                            selected == null || selected.url == "about:blank" -> {
                                val sites = remember(refresh) { data.topSites() }
                                NewTabPage(
                                    privateMode = privateMode,
                                    showStats = privacyReport,
                                    statsExpanded = statsExpanded,
                                    totalBlocked = totalBlocked,
                                    sites = sites,
                                    onToggleStats = { statsExpanded = !statsExpanded; data.setBool("stats_expanded", statsExpanded) },
                                    onOpen = { navigate(it) },
                                    onAddSite = { addSiteDialog = true },
                                    onShields = { shieldsOpen = true }
                                )
                            }
                            else -> selected?.let { tab ->
                                key(tab.id) {
                                    AndroidView(modifier = Modifier.fillMaxSize(), factory = { tab.view })
                                }
                            }
                        }
                    }

                    // ── bottom bar (hidden while typing, like most mobile browsers) ──
                    if (!editing && !findOpen) {
                        BottomBar(
                            c = c, tabCount = tabs.size, privateMode = privateMode,
                            onHome = { goHome() },
                            onBookmarks = { panel = Panel.BOOKMARKS },
                            onSearch = {
                                runCatching { addressFocus.requestFocus() }
                                keyboard?.show()
                            },
                            onTabs = { tabsShowPrivate = privateMode; panel = Panel.TABS },
                            onMenu = { menuOpen = true }
                        )
                    }
                }
            } else {
                Box(Modifier.fillMaxSize()) {
                    when (panel) {
                        Panel.TABS -> TabsPage(
                            c = c, tabs = tabs, selectedId = selectedId, showPrivate = tabsShowPrivate,
                            onMode = { tabsShowPrivate = it },
                            onSelect = { selectedId = it.id; panel = Panel.NONE },
                            onClose = { closeTab(it) },
                            onNew = { createTab(isPrivate = tabsShowPrivate); panel = Panel.NONE },
                            onCloseAll = { closeAllTabs(tabsShowPrivate) },
                            onDone = { panel = Panel.NONE }
                        )
                        Panel.BOOKMARKS -> BookmarksPage(
                            c = c, items = data.bookmarks(),
                            onBack = { panel = Panel.NONE },
                            onOpen = { navigate(it) },
                            onRemove = { data.removeBookmark(it); refresh++ }
                        )
                        Panel.HISTORY -> HistoryPage(
                            c = c, items = data.history(),
                            onBack = { panel = Panel.NONE },
                            onOpen = { navigate(it) },
                            onRemove = { data.removeHistory(it); refresh++ },
                            onClear = { data.clearHistory(); refresh++ }
                        )
                        Panel.SETTINGS -> SettingsPage(
                            c = c, tabCount = tabs.size, searchEngine = searchEngine,
                            themeLabel = themeName.name.lowercase().replaceFirstChar { it.uppercase() },
                            homepageUrl = homepageUrl,
                            privacyReport = privacyReport, mediaAutoplay = mediaAutoplay, homepageEnabled = homepageEnabled,
                            accessibilityZoom = accessibilityZoom, notifications = notificationsEnabled, sync = syncEnabled,
                            onBack = { panel = Panel.NONE },
                            onShields = { panel = Panel.NONE; shieldsOpen = true },
                            onTabs = { tabsShowPrivate = privateMode; panel = Panel.TABS },
                            onAddons = { panel = Panel.ADDONS },
                            onPrivacyReport = { privacyReport = it; data.setBool("privacy_report", it) },
                            onMediaAutoplay = { mediaAutoplay = it; data.setBool("media_autoplay", it) },
                            onHomepage = { homepageEnabled = it; data.setBool("homepage_enabled", it) },
                            onAccessibilityZoom = {
                                accessibilityZoom = it
                                data.setBool("accessibility_zoom", it)
                                tabs.forEach { t -> t.view.settings.textZoom = if (it) 125 else 100 }
                            },
                            onNotifications = { notificationsEnabled = it; data.setBool("notifications", it) },
                            onSync = { syncEnabled = it; data.setBool("sync_enabled", it) },
                            onSearchEngine = { searchDialog = true },
                            onAppearance = { themeDialog = true },
                            onDownloads = { openDownloads() },
                            onDefaultBrowser = {
                                runCatching { activity.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
                                    .onFailure { info("Default browser", "Open Android Settings → Apps → Default apps → Browser app and choose Orbit.") }
                            },
                            onInfo = { title, detail -> info(title, detail) }
                        )
                        Panel.ADDONS -> {
                            val installed = OrbitAddons.map { it.key }.filter { data.isAddonInstalled(it) }.toSet()
                            AddonsPage(
                                c = c, installed = installed, forceDarkOn = data.getBool("addon_force_dark_on", false),
                                onBack = { panel = Panel.NONE },
                                onInstall = { data.setAddonInstalled(it, true); refresh++ },
                                onRemove = { key ->
                                    data.setAddonInstalled(key, false)
                                    if (key == "force_dark") {
                                        data.setBool("addon_force_dark_on", false)
                                        selected?.view?.let {
                                            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                                                WebSettingsCompat.setForceDark(it.settings, WebSettingsCompat.FORCE_DARK_OFF)
                                            }
                                        }
                                    }
                                    refresh++
                                },
                                onRun = { runAddon(it) }
                            )
                        }
                        Panel.FILTERS -> FiltersPage(
                            c = c, blocked = data.customBlockedHosts(), allowed = data.customAllowedHosts(),
                            onBack = { panel = Panel.NONE; shieldsOpen = true },
                            onBlock = { blocker.addBlockedHost(it); refresh++ },
                            onAllow = { blocker.addAllowedHost(it); refresh++ },
                            onRemoveBlocked = { data.setCustomBlockedHosts(data.customBlockedHosts() - it); refresh++ },
                            onRemoveAllowed = { data.setCustomAllowedHosts(data.customAllowedHosts() - it); refresh++ }
                        )
                        Panel.NONE -> Unit
                    }
                }
            }

            // ── overlays ──
            AnimatedVisibility(
                visible = shieldsOpen && panel == Panel.NONE,
                enter = fadeIn(tween(160)) + slideInVertically(tween(240)) { it / 3 },
                exit = fadeOut(tween(120)) + slideOutVertically(tween(160)) { it / 4 }
            ) {
                val host = OrbitUrl.host(selected?.url.orEmpty())
                ShieldsSheet(
                    c = c, host = host,
                    enabled = host.isNotBlank() && data.shieldEnabled(host),
                    blockedHere = selected?.blocked ?: 0,
                    blockedTotal = totalBlocked,
                    onToggle = { data.setShieldEnabled(host, it); refresh++ },
                    onAdvanced = { shieldsOpen = false; panel = Panel.FILTERS },
                    onClose = { shieldsOpen = false }
                )
            }
            AnimatedVisibility(
                visible = menuOpen,
                enter = fadeIn(tween(120)) + scaleIn(tween(160), initialScale = 0.92f, transformOrigin = TransformOrigin(1f, 1f)),
                exit = fadeOut(tween(90)) + scaleOut(tween(110), targetScale = 0.96f, transformOrigin = TransformOrigin(1f, 1f))
            ) {
                BrowserMenu(
                    c = c, desktopSite = selected?.desktop == true, canForward = selected?.canForward == true,
                    loading = selected?.loading == true,
                    onDismiss = { menuOpen = false },
                    onAction = { onMenuAction(it) }
                )
            }
        }

        // ── dialogs ──
        infoDialog?.let { (title, detail) ->
            AlertDialog(
                onDismissRequest = { infoDialog = null },
                containerColor = c.menu, shape = RoundedCornerShape(24.dp),
                title = { Text(title, color = c.text) },
                text = { Text(detail, color = c.sub) },
                confirmButton = { TextButton(onClick = { infoDialog = null }) { Text("OK", color = c.accent) } }
            )
        }
        if (searchDialog) {
            AlertDialog(
                onDismissRequest = { searchDialog = false },
                containerColor = c.menu, shape = RoundedCornerShape(24.dp),
                title = { Text("Search engine", color = c.text) },
                text = {
                    Column {
                        listOf("Google", "DuckDuckGo", "Bing", "Brave Search").forEach { engine ->
                            val pick = { searchEngine = engine; data.setString("search_engine", engine); searchDialog = false }
                            Row(Modifier.fillMaxWidth().clickable { pick() }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = searchEngine == engine, onClick = { pick() },
                                    colors = RadioButtonDefaults.colors(selectedColor = c.accent, unselectedColor = c.sub)
                                )
                                Text(engine, color = c.text)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { searchDialog = false }) { Text("Close", color = c.accent) } }
            )
        }
        if (themeDialog) {
            AlertDialog(
                onDismissRequest = { themeDialog = false },
                containerColor = c.menu, shape = RoundedCornerShape(24.dp),
                title = { Text("Appearance", color = c.text) },
                text = {
                    Column {
                        OrbitTheme.entries.forEach { t ->
                            val pick = { themeName = t; data.setString("theme", t.name); themeDialog = false }
                            Row(Modifier.fillMaxWidth().clickable { pick() }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = themeName == t, onClick = { pick() },
                                    colors = RadioButtonDefaults.colors(selectedColor = c.accent, unselectedColor = c.sub)
                                )
                                Text(t.name.lowercase().replaceFirstChar { it.uppercase() }, color = c.text)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { themeDialog = false }) { Text("Close", color = c.accent) } }
            )
        }
        if (addSiteDialog) {
            var url by remember { mutableStateOf("") }
            val add = {
                val input = url.trim()
                if (input.startsWith("http") || input.contains('.')) {
                    val target = OrbitUrl.normalize(input)
                    data.addBookmark(OrbitUrl.host(target).removePrefix("www.").ifBlank { target }, target)
                    refresh++
                }
                addSiteDialog = false
            }
            AlertDialog(
                onDismissRequest = { addSiteDialog = false },
                containerColor = c.menu, shape = RoundedCornerShape(24.dp),
                title = { Text("Add shortcut", color = c.text) },
                text = {
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, singleLine = true,
                        label = { Text("Website address") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = c.text, unfocusedTextColor = c.text,
                            focusedBorderColor = c.accent, focusedLabelColor = c.accent, cursorColor = c.accent
                        )
                    )
                },
                confirmButton = { TextButton(onClick = { add() }) { Text("Add", color = c.accent) } },
                dismissButton = { TextButton(onClick = { addSiteDialog = false }) { Text("Cancel", color = c.sub) } }
            )
        }
    }
}
