package com.orbit.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

private val OrbitBlue = Color(0xFF54D8FF)
private val OrbitNavy = Color(0xFF08111F)
private enum class OrbitTheme { LIGHT, DARK, AMOLED }
private enum class Panel { NONE, SHIELDS, TABS, BOOKMARKS, HISTORY, FILTERS, SETTINGS, ADDONS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = BrowserData(applicationContext)
        setContent { OrbitApp(data, this) }
    }
}

private class TabState(val id: Long, val view: WebView) {
    var url by mutableStateOf("about:blank")
    var title by mutableStateOf("New tab")
    var loading by mutableStateOf(false)
    var blocked by mutableIntStateOf(0)
}

@Composable
private fun SettingsRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, fg: Color, card: Color, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = OrbitBlue, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = fg, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, color = fg.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Default.ChevronRight, null, tint = fg.copy(alpha = .55f))
        }
    }
}

@Composable
private fun SettingsSwitchRow(title: String, subtitle: String, checked: Boolean, fg: Color, card: Color, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = fg, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, color = fg.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun OrbitApp(data: BrowserData, activity: ComponentActivity) {
    val context = activity
    var themeName by remember { mutableStateOf(OrbitTheme.DARK) }
    var address by remember { mutableStateOf("") }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var selectedId by remember { mutableLongStateOf(1L) }
    var nextId by remember { mutableLongStateOf(2L) }
    var tabs by remember { mutableStateOf(listOf<TabState>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var customHost by remember { mutableStateOf("") }
    var settingsDialog by remember { mutableStateOf<String?>(null) }
    var settingsDetail by remember { mutableStateOf("") }
    var addonSearch by remember { mutableStateOf("") }
    var findText by remember { mutableStateOf("") }
    var homepageEnabled by remember { mutableStateOf(data.getBool("homepage_enabled", true)) }
    var privacyReport by remember { mutableStateOf(data.getBool("privacy_report", false)) }
    var notificationsEnabled by remember { mutableStateOf(data.getBool("notifications", true)) }
    var mediaAutoplay by remember { mutableStateOf(data.getBool("media_autoplay", true)) }
    var accessibilityZoom by remember { mutableStateOf(data.getBool("accessibility_zoom", false)) }
    var syncEnabled by remember { mutableStateOf(data.getBool("sync_enabled", false)) }
    var searchEngine by remember { mutableStateOf(data.getString("search_engine", "Google")) }
    var homepageUrl by remember { mutableStateOf(data.getString("homepage_url", "https://www.google.com")) }
    val keyboard = LocalSoftwareKeyboardController.current
    val blocker = remember { OrbitBlocker(data) }

    val isDark = themeName != OrbitTheme.LIGHT
    val bg = when (themeName) {
        OrbitTheme.LIGHT -> Color(0xFFF4F7FB)
        OrbitTheme.DARK -> Color(0xFF08111F)
        OrbitTheme.AMOLED -> Color.Black
    }
    val fg = if (isDark) Color(0xFFF4F8FF) else Color(0xFF111827)
    val card = when (themeName) {
        OrbitTheme.LIGHT -> Color.White
        OrbitTheme.DARK -> Color(0xFF121E30)
        OrbitTheme.AMOLED -> Color(0xFF080808)
    }
    val selected = tabs.firstOrNull { it.id == selectedId }

    fun createTab(initialUrl: String = "about:blank") {
        val id = nextId++
        val view = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.mediaPlaybackRequiresUserGesture = !data.getBool("media_autoplay", true)
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_OFF)
            }
        }
        val tab = TabState(id, view)
        view.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: tab.url
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.loading = newProgress < 100
            }
        }
        view.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            runCatching {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    .setDescription("Downloading with Orbit")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme !in listOf("https", "http")) return true
                return false
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): android.webkit.WebResourceResponse? {
                val mainHost = OrbitUrl.host(tab.url)
                val host = request?.url?.host?.lowercase().orEmpty()
                val shieldsOn = data.shieldEnabled(mainHost)
                if (request != null && blocker.shouldBlock(request, mainHost, shieldsOn)) {
                    tab.blocked = blocker.blockedCount
                    return android.webkit.WebResourceResponse("text/plain", "utf-8", 204, "Blocked", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.loading = true
                if (url != null) { tab.url = url; address = url }
                refresh++
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                if (url != null) {
                    tab.url = url
                    address = url
                    data.addHistory(tab.title, url)
                }
                tab.blocked = blocker.blockedCount
                refresh++
            }
        }
        tabs = tabs + tab
        selectedId = id
        if (initialUrl != "about:blank") view.loadUrl(initialUrl)
    }

    fun navigate(raw: String) {
        val target = OrbitUrl.normalize(raw, data.getString("search_engine", "Google"))
        if (target == "about:blank") return
        selected?.view?.loadUrl(target)
        address = target
        panel = Panel.NONE
        keyboard?.hide()
    }

    fun runAddon(key: String) {
        val tab = selected
        when (key) {
            "reader_mode" -> {
                tab?.view?.evaluateJavascript("(function(){var s=document.getElementById('orbit-reader-style');if(s){s.remove();return;}s=document.createElement('style');s.id='orbit-reader-style';s.textContent='body{max-width:760px!important;margin:32px auto!important;padding:24px!important;background:#101722!important;color:#edf3ff!important;font:20px/1.8 Georgia,serif!important}img,video,iframe,nav,aside,footer,header,form{max-width:100%;}';document.head.appendChild(s);document.body.style.maxWidth='760px';})();", null)
            }
            "force_dark" -> {
                val view = tab?.view ?: return
                if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                    val currentlyOn = data.getBool("addon_force_dark_on", false)
                    val next = !currentlyOn
                    data.setBool("addon_force_dark_on", next)
                    WebSettingsCompat.setForceDark(view.settings, if (next) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF)
                    refresh++
                } else {
                    settingsDialog = "Force Dark Pages"
                    settingsDetail = "This Android System WebView version does not expose force-dark support. Update Android System WebView and try again."
                }
            }
            "translate" -> {
                val url = tab?.url.orEmpty()
                if (url.startsWith("http")) navigate("https://translate.google.com/translate?sl=auto&tl=en&u=" + Uri.encode(url))
                else { settingsDialog = "Page Translator"; settingsDetail = "Open a webpage first, then run the translator add-on." }
            }
            "share" -> {
                val url = tab?.url.orEmpty()
                if (url.startsWith("http")) {
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, url); putExtra(android.content.Intent.EXTRA_SUBJECT, tab.title) }
                    activity.startActivity(android.content.Intent.createChooser(send, "Share with"))
                } else { settingsDialog = "Quick Share"; settingsDetail = "Open a webpage first to share its link." }
            }
            "cookie_cleaner" -> {
                CookieManager.getInstance().removeAllCookies { removed ->
                    CookieManager.getInstance().flush()
                    activity.runOnUiThread { settingsDialog = "Cookie Cleaner"; settingsDetail = if (removed) "Browser cookies were cleared. Some websites may sign you out." else "Cookie clearing was requested. Some site data may remain in WebView storage." }
                }
            }
            "find_page" -> { findText = ""; settingsDialog = "Find in page" }
        }
    }

    fun closeTab(id: Long) {
        val tab = tabs.firstOrNull { it.id == id } ?: return
        tab.view.stopLoading()
        tab.view.destroy()
        val remaining = tabs.filterNot { it.id == id }
        tabs = remaining
        if (remaining.isEmpty()) {
            selectedId = -1L
            createTab()
        } else if (selectedId == id) selectedId = remaining.last().id
        refresh++
    }

    LaunchedEffect(Unit) { createTab() }
    DisposableEffect(Unit) {
        onDispose { tabs.forEach { runCatching { it.view.stopLoading(); it.view.destroy() } } }
    }

    MaterialTheme(colorScheme = if (isDark) darkColorScheme(primary = OrbitBlue, background = bg, surface = card, onBackground = fg, onSurface = fg)
        else lightColorScheme(primary = Color(0xFF007FAD), background = bg, surface = card, onBackground = fg, onSurface = fg)) {
        BackHandler(enabled = selected?.view?.canGoBack() == true && panel == Panel.NONE) { selected?.view?.goBack() }
        Column(Modifier.fillMaxSize().background(bg)) {
            val motion = rememberInfiniteTransition(label = "orbitAmbient")
            val logoPulse by motion.animateFloat(initialValue = 0.96f, targetValue = 1.04f,
                animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "logoPulse")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).graphicsLayer { scaleX = logoPulse; scaleY = logoPulse }
                        .shadow(12.dp, CircleShape, ambientColor = OrbitBlue.copy(alpha = .35f), spotColor = OrbitBlue.copy(alpha = .45f))
                        .background(Brush.linearGradient(listOf(Color(0xFF173D62), Color(0xFF101B31))), CircleShape)
                        .border(1.dp, OrbitBlue.copy(alpha = .55f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Public, "Orbit", tint = OrbitBlue, modifier = Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Text("ORBIT", style = MaterialTheme.typography.titleLarge, color = fg)
                        Text("YOUR SPACE. YOUR RULES.", style = MaterialTheme.typography.labelSmall, color = OrbitBlue)
                    }
                }
                IconButton(onClick = { panel = Panel.SHIELDS }) {
                    Icon(Icons.Default.Shield, "Site Shields", tint = if (selected?.let { data.shieldEnabled(OrbitUrl.host(it.url)) } != false) OrbitBlue else fg)
                }
                IconButton(onClick = { panel = Panel.TABS }) {
                    BadgedBox(badge = { if (tabs.isNotEmpty()) Badge { Text("${tabs.size}") } }) {
                        Icon(Icons.Default.Tab, "Tabs", tint = fg)
                    }
                }
                Box {
                    var themeMenu by remember { mutableStateOf(false) }
                    IconButton(onClick = { themeMenu = true }) { Icon(Icons.Default.Palette, "Theme", tint = fg) }
                    DropdownMenu(expanded = themeMenu, onDismissRequest = { themeMenu = false }) {
                        DropdownMenuItem(text = { Text("Light") }, onClick = { themeName = OrbitTheme.LIGHT; themeMenu = false })
                        DropdownMenuItem(text = { Text("Dark") }, onClick = { themeName = OrbitTheme.DARK; themeMenu = false })
                        DropdownMenuItem(text = { Text("AMOLED") }, onClick = { themeName = OrbitTheme.AMOLED; themeMenu = false })
                    }
                }
                IconButton(onClick = { panel = Panel.ADDONS }) { Icon(Icons.Default.Extension, "Add-ons", tint = OrbitBlue) }
                IconButton(onClick = { panel = Panel.SETTINGS }) { Icon(Icons.Default.Settings, "Settings", tint = fg) }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).shadow(10.dp, RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(card, card.copy(red = (card.red + .035f).coerceAtMost(1f))), start = androidx.compose.ui.geometry.Offset.Zero, end = androidx.compose.ui.geometry.Offset(900f, 300f)), RoundedCornerShape(22.dp))
                .border(1.dp, OrbitBlue.copy(alpha = if (isDark) .22f else .14f), RoundedCornerShape(22.dp))
                .padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = OrbitBlue)
                TextField(
                    value = address, onValueChange = { address = it }, modifier = Modifier.weight(1f),
                    singleLine = true, placeholder = { Text("Search or enter website") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { navigate(address) }),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
                )
                TextButton(onClick = { navigate(address) }) { Text("GO") }
            }

            if (selected?.loading == true) LinearProgressIndicator(Modifier.fillMaxWidth(), color = OrbitBlue)

            Box(Modifier.weight(1f).fillMaxWidth().animateContentSize(tween(360, easing = FastOutSlowInEasing))) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = panel == Panel.NONE,
                    enter = fadeIn(tween(260)) + slideInVertically(initialOffsetY = { it / 24 }, animationSpec = tween(320)),
                    exit = fadeOut(tween(140)) + slideOutVertically(targetOffsetY = { it / 30 }, animationSpec = tween(180))
                ) {
                if (panel == Panel.NONE) {
                    if (selected == null || selected.url == "about:blank") {
                        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), horizontalAlignment = Alignment.Start) {
                            Spacer(Modifier.height(16.dp))
                            Text("YOUR SPACE", style = MaterialTheme.typography.labelMedium, color = OrbitBlue)
                            Spacer(Modifier.height(6.dp))
                            Text("Browse beyond\nlimits.", style = MaterialTheme.typography.headlineLarge, color = fg)
                            Spacer(Modifier.height(8.dp))
                            Text("A calmer, more private corner of the internet.", style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = .66f))
                            Spacer(Modifier.height(24.dp))
                            Card(Modifier.fillMaxWidth().animateContentSize().clickable { panel = Panel.SHIELDS },
                                shape = RoundedCornerShape(26.dp), border = BorderStroke(1.dp, OrbitBlue.copy(alpha = .30f)),
                                colors = CardDefaults.cardColors(containerColor = card), elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)) {
                                Row(Modifier.background(Brush.linearGradient(listOf(Color(0xFF102B40).copy(alpha = if (isDark) .88f else .20f), card))).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(58.dp).background(Brush.linearGradient(listOf(Color(0xFF1D5776), Color(0xFF15263E))), CircleShape)
                                        .border(1.dp, OrbitBlue.copy(alpha = .6f), CircleShape), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Shield, null, tint = OrbitBlue, modifier = Modifier.size(30.dp))
                                    }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Privacy at a glance", color = fg, style = MaterialTheme.typography.titleMedium)
                                        Text(if (selected?.url?.startsWith("http") == true) OrbitUrl.host(selected.url) else "Protection ready when you browse", color = fg.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(Icons.Default.ArrowOutward, null, tint = OrbitBlue)
                                }
                            }
                            Spacer(Modifier.height(22.dp))
                            Text("QUICK ACCESS", color = fg.copy(alpha = .6f), style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf(Triple("Bookmarks", Icons.Default.Bookmarks, Panel.BOOKMARKS), Triple("History", Icons.Default.History, Panel.HISTORY), Triple("Privacy", Icons.Default.Security, Panel.SHIELDS)).forEach { item ->
                                    Card(Modifier.weight(1f).height(104.dp).clickable { panel = item.third }.animateContentSize(), shape = RoundedCornerShape(22.dp),
                                        border = BorderStroke(1.dp, OrbitBlue.copy(alpha = .12f)), colors = CardDefaults.cardColors(containerColor = card)) {
                                        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                            Icon(item.second, null, tint = OrbitBlue, modifier = Modifier.size(25.dp))
                                            Text(item.first, color = fg, style = MaterialTheme.typography.labelLarge)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(18.dp))
                            Row(Modifier.fillMaxWidth().clickable { panel = Panel.SETTINGS }.background(card.copy(alpha = .75f), RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, null, tint = OrbitBlue)
                                Spacer(Modifier.width(10.dp))
                                Text("Made for focus. Built around you.", color = fg.copy(alpha = .8f), style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    selected?.let { tab ->
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { tab.view },
                            update = { if (it.url != tab.url && tab.url != "about:blank") address = tab.url }
                        )
                    }
                }
                }
                androidx.compose.animation.AnimatedVisibility(
                    visible = panel != Panel.NONE,
                    enter = fadeIn(tween(220)) + slideInVertically(initialOffsetY = { it / 18 }, animationSpec = tween(300)),
                    exit = fadeOut(tween(120)) + slideOutVertically(targetOffsetY = { it / 24 }, animationSpec = tween(160))
                ) {
                    when (panel) {
                        Panel.SHIELDS -> {
                            val host = OrbitUrl.host(selected?.url.orEmpty())
                            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Privacy Shields", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                Text(if (host.isBlank()) "Open a website to manage its Shields." else host, color = OrbitBlue)
                                Card(colors = CardDefaults.cardColors(containerColor = card)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("Block known ad/tracker hosts", color = fg)
                                                Text("Applies to supported subresource requests", style = MaterialTheme.typography.bodySmall, color = fg.copy(alpha = .65f))
                                            }
                                            Switch(
                                                checked = host.isNotBlank() && data.shieldEnabled(host),
                                                enabled = host.isNotBlank(),
                                                onCheckedChange = { data.setShieldEnabled(host, it); refresh++ }
                                            )
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        Text("Blocked requests in active tab: ${selected?.blocked ?: 0}", color = fg)
                                    }
                                }
                                Text("Protection is a host-based starter filter, not a complete Brave-equivalent engine.", color = fg.copy(alpha = .6f), style = MaterialTheme.typography.bodySmall)
                                OutlinedButton(onClick = { panel = Panel.FILTERS }) { Text("Manage custom host rules") }
                            }
                        }
                        Panel.TABS -> {
                            Column(Modifier.fillMaxSize().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Tabs (${tabs.size})", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { createTab(); panel = Panel.NONE }) { Icon(Icons.Default.Add, "New tab", tint = fg) }
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                LazyColumn { items(tabs, key = { it.id }) { tab ->
                                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { selectedId = tab.id; address = tab.url; panel = Panel.NONE },
                                        colors = CardDefaults.cardColors(containerColor = card)) {
                                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text(tab.title, color = fg, maxLines = 1)
                                                Text(tab.url, color = fg.copy(alpha = .6f), maxLines = 1, style = MaterialTheme.typography.bodySmall)
                                            }
                                            IconButton(onClick = { closeTab(tab.id) }) { Icon(Icons.Default.Close, "Close tab", tint = fg) }
                                        }
                                    }
                                } }
                            }
                        }
                        Panel.BOOKMARKS -> {
                            val bookmarks = remember(refresh) { data.bookmarks() }
                            Column(Modifier.fillMaxSize().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Bookmarks", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                LazyColumn { items(bookmarks) { item ->
                                    ListItem(headlineContent = { Text(item.title) }, supportingContent = { Text(item.url, maxLines = 1) },
                                        modifier = Modifier.clickable { navigate(item.url) },
                                        trailingContent = { Icon(Icons.Default.OpenInBrowser, null) })
                                } }
                            }
                        }
                        Panel.HISTORY -> {
                            val history = remember(refresh) { data.history() }
                            Column(Modifier.fillMaxSize().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("History", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    TextButton(onClick = { data.clearHistory(); refresh++ }) { Text("Clear") }
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                LazyColumn { items(history) { item ->
                                    ListItem(headlineContent = { Text(item.title) }, supportingContent = { Text(item.url, maxLines = 1) },
                                        modifier = Modifier.clickable { navigate(item.url) })
                                } }
                            }
                        }
                        Panel.SETTINGS -> {
                            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Settings", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.NONE }) { Icon(Icons.Default.Close, "Close settings", tint = fg) }
                                }
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    item { Text("PRIVACY & SECURITY", color = OrbitBlue, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp)) }
                                    item { SettingsRow("Brave Shields & privacy", "Per-site tracker blocking and privacy controls", Icons.Default.Shield, fg, card) { panel = Panel.SHIELDS } }
                                    item { SettingsSwitchRow("Privacy Report", "Show local blocked-request summary", privacyReport, fg, card) { privacyReport = it; data.setBool("privacy_report", it) } }
                                    item { SettingsRow("Site settings", "Review site permissions and cookies", Icons.Default.Tune, fg, card) { settingsDialog = "Site settings"; settingsDetail = "Orbit currently uses Android WebView site permission handling. Clear site data from Android app settings for a full reset." } }
                                    item { Text("DISPLAY", color = OrbitBlue, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 10.dp)) }
                                    item { SettingsRow("Tabs and tab groups", "${tabs.size} open tabs · tab groups are not implemented yet", Icons.Default.Tab, fg, card) { panel = Panel.TABS } }
                                    item { SettingsRow("Media", "Playback and autoplay preferences", Icons.Default.Movie, fg, card) { settingsDialog = "Media"; settingsDetail = "Control whether websites may autoplay media. This setting is saved locally." } }
                                    item { SettingsSwitchRow("Allow media autoplay", "Saved browser preference", mediaAutoplay, fg, card) { mediaAutoplay = it; data.setBool("media_autoplay", it) } }
                                    item { SettingsRow("Appearance", "Light, dark and AMOLED themes", Icons.Default.Palette, fg, card) { settingsDialog = "Appearance"; settingsDetail = "Choose the Orbit interface theme." } }
                                    item { SettingsRow("New Tab Page", "Orbit start page and shortcuts", Icons.Default.AddBox, fg, card) { settingsDialog = "New Tab Page"; settingsDetail = "The current start page is the built-in Orbit landing screen." } }
                                    item { SettingsSwitchRow("Homepage", homepageUrl, homepageEnabled, fg, card) { homepageEnabled = it; data.setBool("homepage_enabled", it) } }
                                    item { SettingsSwitchRow("Accessibility zoom", "Enable larger page text where supported", accessibilityZoom, fg, card) { accessibilityZoom = it; data.setBool("accessibility_zoom", it); selected?.view?.settings?.textZoom = if (it) 125 else 100 } }
                                    item { SettingsRow("Languages", "App language follows Android system language", Icons.Default.Language, fg, card) { settingsDialog = "Languages"; settingsDetail = "Orbit currently follows the device language. Per-app language selection is not implemented." } }
                                    item { Text("BROWSER", color = OrbitBlue, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 10.dp)) }
                                    item { SettingsRow("Search engines", searchEngine, Icons.Default.Search, fg, card) { settingsDialog = "Search engines"; settingsDetail = "Select the default search engine for address-bar searches." } }
                                    item { SettingsSwitchRow("Notifications", "Browser download notifications are managed by Android", notificationsEnabled, fg, card) { notificationsEnabled = it; data.setBool("notifications", it) } }
                                    item { SettingsRow("Downloads", "Files downloaded by Orbit", Icons.Default.Download, fg, card) { runCatching { activity.startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }.onFailure { settingsDialog = "Downloads"; settingsDetail = "Downloads are stored in Android's Downloads folder." } } }
                                    item { SettingsRow("Add-ons & Plugins", "Browse, install and manage Orbit add-ons", Icons.Default.Extension, fg, card) { panel = Panel.ADDONS } }
                                    item { SettingsSwitchRow("Sync", "Sync is a placeholder; no account service is connected", syncEnabled, fg, card) { syncEnabled = it; data.setBool("sync_enabled", it) } }
                                    item { SettingsRow("Home screen widget", "Widget is not included in this starter build", Icons.Default.Widgets, fg, card) { settingsDialog = "Home screen widget"; settingsDetail = "A launcher widget requires an Android AppWidget provider and is not implemented yet." } }
                                    item { SettingsRow("Default browser", "Choose Orbit in Android system settings", Icons.Default.OpenInBrowser, fg, card) { runCatching { activity.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }.onFailure { settingsDialog = "Default browser"; settingsDetail = "Open Android Settings → Apps → Default apps → Browser app and choose Orbit." } } }
                                    item { SettingsRow("Orbit Origin", "About this browser and current engine", Icons.Default.Info, fg, card) { settingsDialog = "Orbit Origin"; settingsDetail = "Orbit is a native Kotlin + Jetpack Compose app using Android System WebView (Chromium-based), not a bundled custom Chromium build." } }
                                }
                            }
                            if (settingsDialog != null) {
                                AlertDialog(
                                    onDismissRequest = { settingsDialog = null },
                                    title = { Text(settingsDialog!!) },
                                    text = {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(settingsDetail)
                                            if (settingsDialog == "Search engines") {
                                                listOf("Google", "DuckDuckGo", "Bing", "Brave Search").forEach { engine ->
                                                    Row(Modifier.fillMaxWidth().clickable {
                                                        searchEngine = engine; data.setString("search_engine", engine); settingsDialog = null
                                                    }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                        RadioButton(selected = searchEngine == engine, onClick = { searchEngine = engine; data.setString("search_engine", engine); settingsDialog = null })
                                                        Text(engine)
                                                    }
                                                }
                                            }
                                            if (settingsDialog == "Appearance") {
                                                listOf(OrbitTheme.LIGHT, OrbitTheme.DARK, OrbitTheme.AMOLED).forEach { t ->
                                                    Row(Modifier.fillMaxWidth().clickable { themeName = t; settingsDialog = null }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                        RadioButton(selected = themeName == t, onClick = { themeName = t; settingsDialog = null })
                                                        Text(t.name.lowercase().replaceFirstChar { it.uppercase() })
                                                    }
                                                }
                                            }
                                            if (settingsDialog == "Media") {
                                                Text("Autoplay is ${if (mediaAutoplay) "enabled" else "disabled"}. Use the switch on the settings page to change it.")
                                            }
                                            if (settingsDialog == "Find in page") {
                                                OutlinedTextField(value = findText, onValueChange = { findText = it }, label = { Text("Text to find") }, singleLine = true)
                                            }
                                        }
                                    },
                                    confirmButton = { TextButton(onClick = { if (settingsDialog == "Find in page" && findText.isNotBlank()) selected?.view?.findAllAsync(findText); settingsDialog = null }) { Text(if (settingsDialog == "Find in page") "Find" else "Done") } }
                                )
                            }
                        }
                        Panel.ADDONS -> {
                            val addons = listOf(
                                Triple("reader_mode", "Reader Mode", "Apply a distraction-reduced reading style to the current page.") ,
                                Triple("force_dark", "Force Dark Pages", "Try WebView's dark-page rendering where supported."),
                                Triple("translate", "Page Translator", "Open the current page in Google Translate."),
                                Triple("share", "Quick Share", "Share the current page using Android's share sheet."),
                                Triple("cookie_cleaner", "Cookie Cleaner", "Clear browser cookies; this may sign you out of websites."),
                                Triple("find_page", "Find in Page", "Search text on the current webpage.")
                            ).filter { it.second.contains(addonSearch, ignoreCase = true) || it.third.contains(addonSearch, ignoreCase = true) }
                            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("Orbit Add-ons", style = MaterialTheme.typography.headlineMedium, color = fg)
                                        Text("Install small browser tools", color = fg.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = { panel = Panel.SETTINGS }) { Icon(Icons.Default.Close, "Close add-ons", tint = fg) }
                                }
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = addonSearch, onValueChange = { addonSearch = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search add-ons") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                                Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(16.dp), modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)) {
                                    Text("These are Orbit-native add-ons, not Firefox WebExtensions. The current WebView engine cannot install arbitrary Firefox extension packages.", Modifier.padding(12.dp), color = fg.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
                                }
                                Text("${addons.count { data.getBool("addon_installed_${it.first}", false) }} installed · ${addons.size} available", color = fg.copy(alpha = .55f), style = MaterialTheme.typography.labelSmall)
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(addons, key = { it.first }) { addon ->
                                        val installed = data.getBool("addon_installed_${addon.first}", false)
                                        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Color(0xFF183A59), Color(0xFF182039))), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                                                        Icon(when(addon.first) { "reader_mode" -> Icons.Default.MenuBook; "force_dark" -> Icons.Default.DarkMode; "translate" -> Icons.Default.Translate; "share" -> Icons.Default.Share; "cookie_cleaner" -> Icons.Default.DeleteSweep; else -> Icons.Default.FindInPage }, null, tint = OrbitBlue)
                                                    }
                                                    Spacer(Modifier.width(12.dp))
                                                    Column(Modifier.weight(1f)) {
                                                        Text(addon.second, color = fg, style = MaterialTheme.typography.titleMedium)
                                                        Text(if (installed) "Installed" else "Available", color = if (installed) Color(0xFF64DDAA) else fg.copy(alpha = .6f), style = MaterialTheme.typography.labelSmall)
                                                    }
                                                }
                                                Text(addon.third, color = fg.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    if (installed) {
                                                        Button(onClick = { runAddon(addon.first) }, modifier = Modifier.weight(1f)) { Text(if (addon.first == "force_dark") if (data.getBool("addon_force_dark_on", false)) "Turn off" else "Run" else "Open") }
                                                        OutlinedButton(onClick = { data.setBool("addon_installed_${addon.first}", false); if (addon.first == "force_dark") { data.setBool("addon_force_dark_on", false); selected?.view?.let { if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) WebSettingsCompat.setForceDark(it.settings, WebSettingsCompat.FORCE_DARK_OFF) } }; refresh++ }) { Text("Remove") }
                                                    } else {
                                                        Button(onClick = { data.setBool("addon_installed_${addon.first}", true); refresh++ }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Install add-on") }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Panel.FILTERS -> {
                            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Custom host rules", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), color = fg)
                                    IconButton(onClick = { panel = Panel.SHIELDS }) { Icon(Icons.Default.Close, "Close", tint = fg) }
                                }
                                Text("Enter a hostname such as ads.example.com. This is not a full EasyList parser.", color = fg.copy(alpha = .65f))
                                OutlinedTextField(value = customHost, onValueChange = { customHost = it }, label = { Text("Hostname") }, modifier = Modifier.fillMaxWidth())
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { blocker.addBlockedHost(customHost); customHost = ""; refresh++ }) { Text("Block host") }
                                    OutlinedButton(onClick = { blocker.addAllowedHost(customHost); customHost = ""; refresh++ }) { Text("Allow host") }
                                }
                                Text("Blocked: ${data.customBlockedHosts().joinToString().ifBlank { "None" }}", color = fg)
                                Text("Allowed: ${data.customAllowedHosts().joinToString().ifBlank { "None" }}", color = fg)
                            }
                        }
                        Panel.NONE -> Unit
                    }
                }
            }

            Surface(color = card.copy(alpha = .97f), shadowElevation = 18.dp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp).border(1.dp, OrbitBlue.copy(alpha = .16f), RoundedCornerShape(24.dp)), shape = RoundedCornerShape(24.dp)) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (selected?.view?.canGoBack() == true) selected.view.goBack() }, enabled = selected?.view?.canGoBack() == true) { Icon(Icons.Default.ArrowBack, "Back", tint = fg) }
                    IconButton(onClick = { if (selected?.view?.canGoForward() == true) selected.view.goForward() }, enabled = selected?.view?.canGoForward() == true) { Icon(Icons.Default.ArrowForward, "Forward", tint = fg) }
                    IconButton(onClick = {
                        panel = Panel.NONE
                        val home = if (data.getBool("homepage_enabled", true)) data.getString("homepage_url", "https://www.google.com") else "about:blank"
                        if (home == "about:blank") { selected?.view?.loadUrl(home); selected?.url = home; address = "" } else navigate(home)
                    }) { Icon(Icons.Default.Home, "Home", tint = fg) }
                    IconButton(onClick = { selected?.view?.reload() }) { Icon(Icons.Default.Refresh, "Reload", tint = fg) }
                    IconButton(onClick = {
                        val tab = selected
                        if (tab != null && tab.url.startsWith("http")) data.addBookmark(tab.title, tab.url)
                        refresh++
                    }) { Icon(Icons.Default.BookmarkAdd, "Add bookmark", tint = fg) }
                    IconButton(onClick = { panel = Panel.HISTORY }) { Icon(Icons.Default.History, "History", tint = fg) }
                    IconButton(onClick = { panel = Panel.TABS }) { Icon(Icons.Default.Tab, "Tabs", tint = fg) }
                }
            }
        }
    }
}
