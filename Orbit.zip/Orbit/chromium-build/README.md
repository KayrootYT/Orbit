# Orbit Custom Chromium Build Kit

This folder is a **build harness** for checking out and compiling the official open-source Chromium Android browser target as a starting point for Orbit's custom fork.

## Important status distinction

- This kit does not contain Chromium's source tree (it is enormous and must be fetched separately).
- It does not yet integrate Chromium's engine into Orbit's existing Kotlin/Compose UI.
- `chrome_public_apk` is a Chromium baseline build target; do not call the resulting APK a fully branded Orbit browser until branding/package integration is implemented and tested.
- The workflow is configured for a **self-hosted Linux runner** because a full Chromium build can exceed standard hosted-runner storage/time limits.

## Recommended build host

Use Ubuntu Linux x86-64 with:
- at least 16 GB RAM (32 GB preferred)
- 100+ GB free SSD storage (more is safer)
- Git and Python 3
- stable internet connection
- Android SDK dependencies installed by Chromium's build setup

Official instructions: https://chromium.googlesource.com/chromium/src/+/main/docs/android_build_instructions.md

## First build

From a clean Linux machine:

```bash
chmod +x chromium-build/build_chromium_android.sh
./chromium-build/build_chromium_android.sh
```

The script creates `~/orbit-chromium/src`, fetches the Android Chromium checkout without history, installs Android/Linux build dependencies, runs hooks, generates an ARM64 build and builds `chrome_public_apk`.

Build output is expected under:
`~/orbit-chromium/src/out/Orbit/`

## Build output

The script searches the build output for APK/AAB artifacts and writes a summary to `out/Orbit/orbit-build-summary.txt`.

The upstream Chromium APK is only a baseline engine/build artifact. Branding, application package identity, Orbit UI integration, privacy-engine integration, release signing, device installation and smoke tests remain separate work.

## GitHub Actions

`.github/workflows/chromium-android.yml` targets a self-hosted Linux runner labelled `self-hosted`, `linux`, `x64`, `chromium-builder`. Register a machine with those labels and enough disk/RAM before running it. It uploads build artifacts when the runner has enough available storage.

Never put signing keys or credentials in the repository. Use GitHub Actions secrets only when a later release-signing job is added.
