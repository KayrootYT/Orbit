#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="${ORBIT_CHROMIUM_ROOT:-$HOME/orbit-chromium}"
SRC="$ROOT/src"
OUT="out/Orbit"

if [[ "$(uname -s)" != "Linux" || "$(uname -m)" != "x86_64" ]]; then
  echo "ERROR: Chromium Android build requires a Linux x86-64 build host." >&2
  exit 2
fi

mkdir -p "$ROOT"
cd "$ROOT"

if [[ ! -d "$SRC/.git" ]]; then
  if ! command -v fetch >/dev/null 2>&1; then
    if [[ ! -d "$ROOT/depot_tools" ]]; then
      git clone https://chromium.googlesource.com/chromium/tools/depot_tools.git "$ROOT/depot_tools"
    fi
    export PATH="$ROOT/depot_tools:$PATH"
  fi
  export PATH="$ROOT/depot_tools:$PATH"
  fetch --nohooks --no-history android
fi

export PATH="$ROOT/depot_tools:$PATH"
cd "$SRC"

echo "== Chromium revision =="
git rev-parse HEAD | tee "$ROOT/chromium-revision.txt"

echo "== Installing build dependencies =="
./build/install-build-deps.sh

echo "== Running Chromium hooks =="
gclient runhooks

echo "== Generating ARM64 Android build =="
gn gen "$OUT" --args='target_os="android" target_cpu="arm64" is_debug=false is_component_build=false symbol_level=1'

echo "== Building Chromium public APK target =="
autoninja -C "$OUT" chrome_public_apk

echo "== Locating build outputs =="
SUMMARY="$SRC/$OUT/orbit-build-summary.txt"
{
  echo "Orbit Chromium baseline build summary"
  echo "Chromium revision: $(git rev-parse HEAD)"
  echo "Build target: chrome_public_apk"
  echo "Architecture: arm64"
  echo "Build date UTC: $(date -u +%FT%TZ)"
  echo
  find "$SRC/$OUT" -type f \( -name '*.apk' -o -name '*.aab' \) -printf '%p (%s bytes)\n' | sort
} | tee "$SUMMARY"

if ! find "$SRC/$OUT" -type f \( -name '*.apk' -o -name '*.aab' \) -print -quit | grep -q .; then
  echo "ERROR: build command completed but no APK/AAB artifact was found." >&2
  exit 3
fi

echo "Baseline build completed. This is not yet the branded Orbit release APK."
