# Orbit custom Chromium integration boundary

## What this repository does today

The Orbit Android app's renderer is created with `android.webkit.WebView`. Android System WebView is based on Chromium, but it is managed independently by the device/provider. The app's Kotlin code relies directly on `WebView`, `WebSettings`, `WebViewClient`, and `WebChromeClient`.

The script `build_chromium_android.sh` checks out upstream Chromium and builds `chrome_public_apk`. That target is a standalone Chromium/Chrome baseline; it does **not** produce an embeddable engine library for the existing Orbit app and does not automatically inherit Orbit's Compose UI, package ID, settings, or branding.

## Why this is not a one-line dependency

Chromium's Android browser stack is a large native C++ project. A production integration needs a supported embedding layer or a maintained fork exposing the necessary browser/content APIs. Simply replacing the WebView dependency with a Maven coordinate or copying Chromium's source directory would not provide a compatible Android `View` and lifecycle API.

## Safe migration sequence

1. Pin the exact upstream Chromium revision and document the license/notices.
2. Decide whether to maintain a custom Chromium fork, adopt a maintained embedding solution, or continue using system WebView.
3. Build the required Android ARM64 artifacts on a provisioned Linux runner; retain build logs and revision metadata.
4. Implement an engine adapter for load/back/forward/reload/progress/title/JavaScript dialogs/permissions/file chooser/downloads/media.
5. Migrate Orbit's `TabState` away from direct `WebView` types to the adapter before swapping renderer implementations.
6. Design separate storage profiles for regular and private sessions. Verify cookies, local storage, cache, service workers and cleanup.
7. Add instrumentation tests for HTTPS errors, redirects, downloads, file/content URI restrictions, permissions, media, crash recovery and private-session cleanup.
8. Establish a Chromium security-update cadence and repeatable release-signing process.

## Current honest status

- [x] Native Android app and Compose UI
- [x] Chromium-based Android System WebView rendering
- [x] Separate script/workflow to build upstream Chromium's public APK baseline
- [ ] Custom Chromium engine embedded inside Orbit's current UI
- [ ] Isolated private browsing storage backed by a custom engine
- [ ] Production security review and update pipeline

Do not call the current app a fully integrated custom Chromium fork until the unchecked integration and validation work is completed.
