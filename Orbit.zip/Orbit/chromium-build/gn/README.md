# GN configuration

The build script uses these baseline arguments:

```gn
target_os = "android"
target_cpu = "arm64"
is_debug = false
is_component_build = false
symbol_level = 1
```

This builds upstream Chromium's `chrome_public_apk` target. Do not change package identity or Chromium branding blindly through GN args; Orbit rebranding requires a deliberate source-level patch set and a separate validation pass.

Keep patches under version control and rebase them whenever the Chromium revision is updated.
