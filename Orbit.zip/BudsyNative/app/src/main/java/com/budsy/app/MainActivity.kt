@file:OptIn(ExperimentalLayoutApi::class)

package com.budsy.app

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.budsy.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BudsyApp() }
    }
}

private fun LazyListScope.animItem(i: Int, content: @Composable () -> Unit) =
    item { Box(Modifier.fillMaxWidth().enterAnim(i)) { content() } }

@Composable
fun BudsyApp() {
    val context = LocalContext.current
    val s = remember { BudsyState(context) }
    DisposableEffect(s) { onDispose { s.ble.close() } }
    LaunchedEffect(s.themeMode) { s.persist() }

    val p = remember(s.themeMode) { paletteOf(s.themeMode) }

    // Status/navigation bar icon colours follow the theme.
    LaunchedEffect(p.dark) {
        val t = android.graphics.Color.TRANSPARENT
        val style = if (p.dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
        (context as? ComponentActivity)?.enableEdgeToEdge(style, style)
    }

    val tilt = remember { mutableStateOf(Offset.Zero) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.all { it }) { s.refreshPaired(); s.ble.startScan(s.showAll) }
        else s.notice = "Bluetooth permission denied. Allow “Nearby devices” for Budsy in app settings."
    }
    val onScan: () -> Unit = {
        if (s.ble.hasRequiredPermissions()) { s.refreshPaired(); s.ble.startScan(s.showAll) }
        else permissionLauncher.launch(
            if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        )
    }

    CompositionLocalProvider(
        LocalPalette provides p, LocalIconStyle provides s.iconStyle, LocalChipLook provides s.chipLook,
        LocalMotion provides s.motion, LocalTilt provides tilt
    ) {
        val scheme = if (p.dark) darkColorScheme(primary = p.accent, background = p.bgBottom, surface = p.bgBottom, onSurface = p.text)
        else lightColorScheme(primary = p.accent, background = p.bgBottom, surface = p.bgBottom, onSurface = p.text)
        MaterialTheme(colorScheme = scheme) {
            val haptic = LocalHapticFeedback.current
            Box(Modifier.fillMaxSize().background(p.bgBottom)) {
                AnimatedBackground(s.bgStyle)
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Header(s)
                    AnimatedContent(
                        targetState = s.page,
                        modifier = Modifier.weight(1f),
                        transitionSpec = {
                            (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.92f)) togetherWith
                                (fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 1.04f))
                        },
                        label = "page"
                    ) { pg ->
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 140.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            when (pg) {
                                Page.DEVICE -> devicePage(s, onScan)
                                Page.CONTROLS -> controlsPage(s)
                                Page.EQ -> eqPage(s)
                                Page.FIND -> findPage(s)
                                Page.THEME -> themePage(s)
                                Page.ABOUT -> aboutPage(s)
                                Page.TUTORIAL -> tutorialPage(s)
                            }
                        }
                    }
                }
                val navPages = listOf(Page.DEVICE, Page.CONTROLS, Page.EQ, Page.THEME, Page.ABOUT)
                val sel = when (s.page) { Page.FIND -> 0; Page.TUTORIAL -> 4; else -> navPages.indexOf(s.page) }
                FloatingNav(
                    navPages.map { it.icon to it.label }, sel,
                    onSelect = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); s.page = navPages[it] },
                    modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp)
                )
                Dialogs(s)
            }
        }
    }
}

@Composable
private fun Header(s: BudsyState) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Budsy", style = TextStyle(brush = Brush.horizontalGradient(listOf(p.accent, p.accent2)), fontSize = 32.sp, fontWeight = FontWeight.ExtraBold))
            Text(if (s.connected) "BLE control link ready" else "Not connected", color = p.muted, fontSize = 12.sp)
        }
        Box(Modifier.clickable { s.page = Page.THEME }) { IconChip(BIcon.PALETTE, 44.dp) }
    }
}

// ───────────────────────── Pages ─────────────────────────

private fun LazyListScope.devicePage(s: BudsyState, onScan: () -> Unit) {
    animItem(0) {
        val p = LocalPalette.current
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            EarbudsHero(s.connected)
            Text(MODEL, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(if (s.connected) "BLE control link ready · audio route not verified" else "Not connected · drag the buds to rotate", color = p.muted, fontSize = 13.sp)
        }
    }
    animItem(1) {
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                BatteryRing("Left", null); BatteryRing("Right", null); BatteryRing("Case", null)
            }
        }
    }
    animItem(2) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Noise cancellation" to BIcon.NOISE_OFF, "Off" to BIcon.DND, "Transparency" to BIcon.HEARING).forEach { (m, ic) ->
                val sel = s.mode == m
                val p = LocalPalette.current
                GlassCard(Modifier.weight(1f), corner = 22.dp, onClick = { s.mode = m; s.notice = "$m selected locally; earbuds command not sent (unverified)" }) {
                    Column(
                        Modifier.fillMaxWidth()
                            .background(if (sel) Brush.linearGradient(listOf(p.accent, p.accent2)) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                            .padding(vertical = 16.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        BudsyIcon(ic, Modifier.size(26.dp), if (sel) p.onAccent else p.text)
                        Spacer(Modifier.height(4.dp))
                        Text(m, fontSize = 11.sp, textAlign = TextAlign.Center, color = if (sel) p.onAccent else p.muted)
                    }
                }
            }
        }
    }
    animItem(3) {
        Section("Device management") {
            SettingRow("Dual connection", if (s.dualConnection) "On · device command pending" else "Off", BIcon.DEVICES, trailing = { BSwitch(s.dualConnection) { s.dualConnection = it } })
            SettingRow("Game mode", if (s.gameMode) "On · device command pending" else "Off", BIcon.GAME, trailing = { BSwitch(s.gameMode) { s.gameMode = it } })
        }
    }
    animItem(4) { Section("Audio effects") { SettingRow("Sound Master EQ", s.preset, BIcon.EQ, onClick = { s.page = Page.EQ }) } }
    animItem(5) {
        Section("Other features") {
            SettingRow("Find my earbuds", "Play a tone to locate", BIcon.FIND, onClick = { s.page = Page.FIND })
            SettingRow("Appearance", "Light, dark and AMOLED", BIcon.PALETTE, onClick = { s.page = Page.THEME })
            SettingRow("Firmware update", "Version and safe update workflow", BIcon.BOLT, onClick = { s.firmwareDialog = true })
            SettingRow("Guide", "Help and protocol status", BIcon.INFO, onClick = { s.page = Page.TUTORIAL })
        }
    }
    animItem(6) {
        val p = LocalPalette.current
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton(if (s.connected) "Disconnect" else "Scan for earbuds", { if (s.connected) s.ble.disconnect() else onScan() },
                Modifier.fillMaxWidth(), BIcon.BLUETOOTH)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Show all BLE devices (debug)", Modifier.weight(1f), color = p.muted, fontSize = 13.sp)
                BSwitch(s.showAll) { s.showAll = it }
            }
            Text(s.notice, color = p.muted, fontSize = 12.sp)
        }
    }
    if (s.paired.isNotEmpty()) animItem(7) {
        Section("Paired devices · tap to connect") {
            s.paired.forEach { SettingRow(it.name, it.device.address, BIcon.HEADPHONES, onClick = { s.ble.connect(it.device) }) }
        }
    }
    if (s.scanResults.isNotEmpty()) animItem(8) {
        Section("Nearby BLE devices · tap to connect") {
            s.scanResults.forEach { SettingRow(it.name, "${it.device.address} · RSSI ${it.rssi} dBm", BIcon.BLUETOOTH, onClick = { s.ble.connect(it.device) }) }
        }
    }
    animItem(9) { Text("Battery levels are shown only after a verified battery response is implemented.", color = LocalPalette.current.muted, fontSize = 12.sp) }
}

private val GESTURES = listOf("Single-tap", "Double-tap", "Triple-tap", "Touch and hold", "Long touch and hold")

private fun LazyListScope.controlsPage(s: BudsyState) {
    animItem(0) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Left", "Right").forEach { side -> SelectChip(side, s.side == side, { s.side = side }) }
        }
    }
    animItem(1) {
        Section("When not on a call") {
            GESTURES.forEach { g -> SettingRow("$g ${s.side.lowercase()} earbud", s.gesture(false, g), BIcon.TOUCH, onClick = { s.editingGesture = g to false }) }
        }
    }
    animItem(2) {
        Section("When on a call") {
            SettingRow("Double-tap ${s.side} earbud", s.gesture(true, "Double-tap"), BIcon.TOUCH, onClick = { s.editingGesture = "Double-tap" to true })
            SettingRow("Long touch and hold ${s.side} earbud", s.gesture(true, "Long touch and hold"), BIcon.TOUCH, onClick = { s.editingGesture = "Long touch and hold" to true })
        }
    }
    animItem(3) { Text("Selections are saved per earbud in the app. Writing them to the earbuds needs verified command mapping.", color = LocalPalette.current.muted, fontSize = 12.sp) }
}

private fun LazyListScope.eqPage(s: BudsyState) {
    animItem(0) {
        Section("Presets") {
            RECOMMENDED.keys.forEach { n -> SettingRow(n, null, null, { s.selectPreset(n) }, { RadioDot(s.preset == n) }) }
        }
    }
    animItem(1) {
        Section("BassWave™", tilt = false) {
            SettingRow("BassWave", "Dynamic bass enhancement", BIcon.BOLT, trailing = { BSwitch(s.bassWave) { s.bassWave = it } })
            if (s.bassWave) {
                Text("Intensity · ${(s.bassLevel * 100).toInt()}%", color = LocalPalette.current.muted)
                BSlider(s.bassLevel, { s.bassLevel = it })
            }
        }
    }
    animItem(2) {
        Section("Custom presets") {
            s.customPresets.keys.forEach { n ->
                SettingRow(n, if (s.preset == n) "Selected" else "Tap to select", BIcon.TUNE, onClick = { s.selectPreset(n) }, trailing = {
                    Box(Modifier.clickable { s.presetEditor = n; s.editorName = n }) { BudsyIcon(BIcon.SETTINGS, tint = LocalPalette.current.muted) }
                })
            }
            Spacer(Modifier.height(6.dp))
            PillButton("Save current EQ as preset", { s.presetEditor = ""; s.editorName = "" }, Modifier.fillMaxWidth(), BIcon.ADD, filled = false)
            Spacer(Modifier.height(8.dp))
        }
    }
    animItem(3) {
        Section("Manual frequency-band EQ", tilt = false) {
            Text("−6 to +6 dB. Stored locally; hardware apply awaits verified EqInfo mapping.", color = LocalPalette.current.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            s.bands.forEachIndexed { i, v ->
                Column(Modifier.padding(vertical = 4.dp)) {
                    Row { Text(BAND_NAMES[i], Modifier.weight(1f), color = LocalPalette.current.text); Text("${v.toInt()} dB", color = LocalPalette.current.muted) }
                    BSlider(v, { nv -> s.bands = s.bands.toMutableList().also { it[i] = nv } }, -6f..6f, 11)
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

private fun LazyListScope.findPage(s: BudsyState) {
    animItem(0) {
        val p = LocalPalette.current
        val inf = rememberInfiniteTransition(label = "radar")
        val t = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "radarT")
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(180.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (k in 0..2) {
                            val f = (t.value + k / 3f) % 1f
                            drawCircle(p.accent.copy(alpha = (1f - f) * (if (s.findOn) 0.6f else 0.25f)), size.width * 0.5f * f, style = Stroke(3f))
                        }
                    }
                    IconChip(BIcon.FIND, 72.dp)
                }
                Text("Find my earbuds", color = p.text, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                Text("⚠ Take the earbuds OUT of your ears first — the tone can be loud.", color = p.muted, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(10.dp))
                Text(s.findStatus, color = p.muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                PillButton("Play sound", { s.sendFind(true) }, Modifier.fillMaxWidth(), BIcon.FIND, enabled = s.connected)
                Spacer(Modifier.height(10.dp))
                PillButton("Stop sound", { s.sendFind(false) }, Modifier.fillMaxWidth(), filled = false, enabled = s.connected)
            }
        }
    }
}

private fun LazyListScope.themePage(s: BudsyState) {
    animItem(0) {
        Section("Appearance", tilt = false) {
            Text("Use a simple Android-style appearance.", color = LocalPalette.current.muted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            ThemeMode.entries.forEach { mode ->
                SettingRow(
                    mode.label,
                    when (mode) {
                        ThemeMode.LIGHT -> "Light surfaces"
                        ThemeMode.DARK -> "Dark surfaces"
                        ThemeMode.AMOLED -> "Pure black backgrounds for OLED displays"
                    },
                    BIcon.PALETTE,
                    trailing = { if (s.themeMode == mode) Icon(Icons.Filled.CheckCircle, null, tint = LocalPalette.current.accent) },
                    onClick = { s.themeMode = mode }
                )
            }
        }
    }
}

private fun LazyListScope.aboutPage(s: BudsyState) {
    animItem(0) {
        Section("Device information") {
            SettingRow("Target model", "Nord Buds 3 / Nord Buds 3 Pro", BIcon.HEADPHONES)
            SettingRow("Connection", if (s.connected) "HeyMelody control link ready" else "Not connected", BIcon.BLUETOOTH)
            SettingRow("Firmware version", "Not read yet", BIcon.INFO)
            SettingRow("Dual connection", if (s.dualConnection) "On · device write pending" else "Off", BIcon.DEVICES, trailing = { BSwitch(s.dualConnection) { s.dualConnection = it } })
            SettingRow("Game mode", if (s.gameMode) "On · device write pending" else "Off", BIcon.GAME, trailing = { BSwitch(s.gameMode) { s.gameMode = it } })
            SettingRow("Firmware update", "Safe workflow only", BIcon.BOLT, onClick = { s.firmwareDialog = true })
            SettingRow("Custom EQ presets", s.customPresets.size.toString(), BIcon.TUNE)
            SettingRow("Controls guide", "Open guide", BIcon.INFO, onClick = { s.page = Page.TUTORIAL })
        }
    }
    animItem(1) {
        Section("Connection status") {
            Text(
                if (s.connected) "BLE GATT control channel is ready. This does not prove Bluetooth audio is routed to the earbuds or that every command is acknowledged." else "No active BLE control link. Audio connection and control connection are checked separately.",
                color = LocalPalette.current.muted, fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Text(s.notice, color = LocalPalette.current.muted, fontSize = 12.sp)
        }
    }
    animItem(2) {
        Section("Advanced GATT diagnostics") {
            Text("Raw service/characteristic inventory (for protocol debugging only)", color = LocalPalette.current.muted, fontSize = 12.sp)
            Text(s.gatt, color = LocalPalette.current.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        }
    }
    animItem(3) {
        Text("Verified from supplied source: scan filters, EQ payload structure, Find-mode command. ANC, Game mode, dual connection, battery and OTA commands remain unverified.", color = LocalPalette.current.muted, fontSize = 13.sp)
    }
}

private fun LazyListScope.tutorialPage(s: BudsyState) {
    val steps = listOf(
        "1. Connect" to "Put the buds in pairing mode (lid open). Tap Scan. Already-paired buds appear under “Paired devices”. If nothing shows, enable “Show all BLE devices”.",
        "2. Touch controls" to "Pick Left or Right, tap a gesture and choose an action. Saved per earbud in the app.",
        "3. Sound EQ" to "Pick a preset or move the 7 band sliders, then save a custom preset.",
        "4. Find my earbuds" to "Sends the verified find-mode packet. Remove the buds from your ears first.",
        "5. Appearance" to "Choose Light, Dark or AMOLED black in Appearance.",
        "6. Firmware safety" to "Never flash firmware without a confirmed model-specific image and recovery method.",
    )
    animItem(0) { Text("Guide", color = LocalPalette.current.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold) }
    steps.forEachIndexed { i, (t, d) -> animItem(i + 1) { Section(t) { Text(d, color = LocalPalette.current.muted, modifier = Modifier.padding(vertical = 10.dp)) } } }
    animItem(steps.size + 1) { PillButton("Done", { s.page = Page.DEVICE }, Modifier.fillMaxWidth()) }
}

// ───────────────────────── Dialogs ─────────────────────────

@Composable
private fun Dialogs(s: BudsyState) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(28.dp)

    s.editingGesture?.let { (g, call) ->
        val current = s.gesture(call, g)
        AlertDialog(
            onDismissRequest = { s.editingGesture = null }, shape = shape, containerColor = p.bgBottom,
            titleContentColor = p.text, textContentColor = p.text,
            title = { Text("$g · ${s.side} earbud${if (call) " (call)" else ""}") },
            text = {
                Column {
                    gestureOptions(g, call).forEach { c ->
                        Row(Modifier.fillMaxWidth().clickable { s.setGesture(call, g, c); s.editingGesture = null }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(c, Modifier.weight(1f), color = p.text); RadioDot(current == c)
                        }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton({ s.editingGesture = null }) { Text("Cancel", color = p.accent) } }
        )
    }

    s.presetEditor?.let { orig ->
        AlertDialog(
            onDismissRequest = { s.presetEditor = null }, shape = shape, containerColor = p.bgBottom,
            titleContentColor = p.text, textContentColor = p.text,
            title = { Text(if (orig.isEmpty()) "Save custom preset" else "Edit custom preset") },
            text = {
                Column {
                    OutlinedTextField(
                        value = s.editorName, onValueChange = { s.editorName = it }, label = { Text("Preset name") }, singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = p.text, unfocusedTextColor = p.text, focusedBorderColor = p.accent, unfocusedBorderColor = p.muted,
                            cursorColor = p.accent, focusedLabelColor = p.accent, unfocusedLabelColor = p.muted
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Saves the current bands: " + s.bands.joinToString { "${it.toInt()}" } + " dB", fontSize = 12.sp, color = p.muted)
                }
            },
            confirmButton = {
                TextButton({
                    val name = s.editorName.trim()
                    if (name.isNotEmpty()) {
                        val m = s.customPresets.toMutableMap()
                        if (orig.isNotEmpty() && orig != name) m.remove(orig)
                        m[name] = s.bands
                        s.customPresets = m; s.preset = name
                    }
                    s.presetEditor = null
                }) { Text("Save", color = p.accent) }
            },
            dismissButton = {
                Row {
                    if (orig.isNotEmpty()) TextButton({
                        s.customPresets = s.customPresets - orig
                        if (s.preset == orig) s.selectPreset("Balanced (Default)")
                        s.presetEditor = null
                    }) { Text("Delete", color = p.muted) }
                    TextButton({ s.presetEditor = null }) { Text("Cancel", color = p.accent) }
                }
            }
        )
    }

    if (s.firmwareDialog) AlertDialog(
        onDismissRequest = { s.firmwareDialog = false }, shape = shape, containerColor = p.bgBottom,
        titleContentColor = p.text, textContentColor = p.muted,
        title = { Text("Firmware update safety") },
        text = { Text("Firmware version reading and OTA transfer are not verified. Budsy will not download or flash firmware until the exact model, trusted image, packet sequence and recovery procedure are confirmed.") },
        confirmButton = { TextButton({ s.firmwareDialog = false }) { Text("OK", color = p.accent) } }
    )
}
