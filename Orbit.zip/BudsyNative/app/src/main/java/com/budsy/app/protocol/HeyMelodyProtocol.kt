package com.budsy.app.protocol

import android.bluetooth.le.ScanFilter
import android.os.ParcelUuid
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

/** Only constants and fields directly verified in the supplied JADX sources. */
object HeyMelodyProtocol {
    // 0x9801 is the advertising service UUID used for discovery, not the GATT service.
    val advertisementServiceUuid: UUID = UUID.fromString("00009801-0000-1000-8000-00805f9b34fb")
    // HeyMelody GattDevice default service UUID from the supplied JADX source (p349y8.i).
    val gattServiceUuid: UUID = UUID.fromString("0000079A-D102-11E1-9B23-00025B00A5A5")
    const val MANUFACTURER_ID_ONE = 1839 // 0x072F
    const val MANUFACTURER_ID_TWO = 1946 // 0x079A
    const val MANUFACTURER_ID_THREE = 41992 // 0xA408; also used by HeyMelody discovery filters
    const val SET_EQ_COMMAND = 1048 // 0x0418
    const val SET_EQ_PRESET_COMMAND = 1030 // 0x0406
    const val FIND_MODE_COMMAND = 1024 // 0x0400
    const val SET_BASS_ENGINE_COMMAND = 1051 // 0x041B
    const val GET_BASS_ENGINE_RESPONSE = 1288 // 0x0508; response ID observed in parser
    const val GET_MULTI_CONNECTION_RESPONSE = 1287 // 0x0507; response ID observed in parser
    // UUIDs observed in the HeyMelody GattDevice/GattConnection sources.
    // Actual product-specific service UUID can be overridden by SupportDeviceConfig.
    val defaultWriteCharacteristicUuid: UUID = UUID.fromString("0100079A-D102-11E1-9B23-00025B00A5A5")
    val defaultNotifyCharacteristicUuid: UUID = UUID.fromString("0200079A-D102-11E1-9B23-00025B00A5A5")
    val defaultReadCharacteristicUuid: UUID = UUID.fromString("0000079A-D102-11E1-9B23-00025B00A5A5")

    /** Exact 5-byte HeyMelody Packet header from F8.b.sendWrapData; not BLE-fragmented. */
    fun encodePacket(commandId: Int, sequence: Int, payload: ByteArray): ByteArray {
        require(commandId in 0..0xFFFF) { "Command id must fit 16 bits" }
        require(sequence in 0..0xFF) { "Sequence must fit 8 bits" }
        require(payload.size <= 0xFFFF) { "Payload exceeds packet length field" }
        val out = ByteBuffer.allocate(5 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        out.putShort(commandId.toShort())
        out.put(sequence.toByte())
        out.putShort(payload.size.toShort())
        out.put(payload)
        return out.array()
    }


    data class Packet(val commandId: Int, val sequence: Int, val declaredPayloadLength: Int, val payload: ByteArray, val lengthMatches: Boolean)

    /** Parses the source-derived 5-byte packet header; this does not reassemble BLE fragments. */
    fun decodePacket(bytes: ByteArray): Packet? {
        if (bytes.size < 5) return null
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val commandId = buffer.short.toInt() and 0xFFFF
        val sequence = buffer.get().toInt() and 0xFF
        val declaredLength = buffer.short.toInt() and 0xFFFF
        val payload = bytes.copyOfRange(5, bytes.size)
        return Packet(commandId, sequence, declaredLength, payload, declaredLength == payload.size)
    }

    fun toHex(bytes: ByteArray): String = bytes.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    /** Incremental BLE stream decoder: notifications may split or combine frames. */
    class StreamDecoder(private val maxPayloadBytes: Int = 4096) {
        private var pending = ByteArray(0)
        data class Result(val packets: List<Packet>, val bufferedBytes: Int, val discardedBytes: Int)
        fun reset() { pending = ByteArray(0) }
        fun append(chunk: ByteArray): Result {
            if (chunk.isEmpty()) return Result(emptyList(), pending.size, 0)
            pending = pending + chunk
            val packets = mutableListOf<Packet>()
            var offset = 0
            var discarded = 0
            while (pending.size - offset >= 5) {
                val command = (pending[offset].toInt() and 0xFF) or ((pending[offset + 1].toInt() and 0xFF) shl 8)
                val sequence = pending[offset + 2].toInt() and 0xFF
                val length = (pending[offset + 3].toInt() and 0xFF) or ((pending[offset + 4].toInt() and 0xFF) shl 8)
                if (length > maxPayloadBytes) { offset += 1; discarded += 1; continue }
                val frameSize = 5 + length
                if (pending.size - offset < frameSize) break
                val payload = pending.copyOfRange(offset + 5, offset + frameSize)
                packets += Packet(command, sequence, length, payload, true)
                offset += frameSize
            }
            if (offset > 0) pending = pending.copyOfRange(offset, pending.size)
            if (pending.size > maxPayloadBytes + 5) {
                val drop = pending.size - (maxPayloadBytes + 5)
                pending = pending.copyOfRange(drop, pending.size); discarded += drop
            }
            return Result(packets, pending.size, discarded)
        }
    }

    /**
     * Source-derived BassWave set payload. HeadsetCoreService.F0(i10, i11, i12, address)
     * writes exactly three bytes in this order. Meaning/ranges of each field must be
     * taken from BassEngineInfo and the UI call site for the target product; do not guess.
     */
    fun encodeBassEnginePayload(first: Int, second: Int, third: Int): ByteArray {
        require(first in 0..255 && second in 0..255 && third in 0..255) {
            "BassWave fields must fit unsigned bytes"
        }
        return byteArrayOf(first.toByte(), second.toByte(), third.toByte())
    }

    /** Source parser expects three status bytes: min, max, current value. */
    data class BassEngineStatus(val minValue: Int, val maxValue: Int, val currentValue: Int)
    fun decodeBassEngineStatus(payload: ByteArray, offset: Int = 0): BassEngineStatus? {
        if (offset < 0 || payload.size - offset < 3) return null
        val min = payload[offset].toInt() and 0xFF
        val max = payload[offset + 1].toInt() and 0xFF
        val current = payload[offset + 2].toInt() and 0xFF
        if (min > max || current !in min..max) return null
        return BassEngineStatus(min, max, current)
    }

    fun scanFilters(): List<ScanFilter> = listOf(
        ScanFilter.Builder().setManufacturerData(MANUFACTURER_ID_ONE, byteArrayOf()).build(),
        ScanFilter.Builder().setManufacturerData(MANUFACTURER_ID_TWO, byteArrayOf()).build(),
        ScanFilter.Builder().setManufacturerData(MANUFACTURER_ID_THREE, byteArrayOf()).build(),
        ScanFilter.Builder().setServiceUuid(ParcelUuid(advertisementServiceUuid)).build()
    )

    /**
     * Mirrors HeadsetCoreService.M0(String, EqInfo, int) payload construction.
     * This returns the command payload only, NOT the outer transport packet.
     * The caller must supply frequencies/dB values from verified device EqInfo.
     */
    /**
     * Builds the complete inner HeyMelody packet for HeadsetCoreService.M0 / command 1048.
     * Values must come from the target device's EqInfo (especially min/max, eqId, and bands).
     * This does not claim that a GATT write means the earbuds applied the setting.
     */
    fun encodeCustomEqPacket(
        sequence: Int,
        mode: Int,
        minValue: Int,
        maxValue: Int,
        eqId: Int,
        name: String?,
        frequencies: IntArray,
        dbValues: IntArray,
    ): ByteArray {
        val payload = encodeEqPayload(mode, minValue, maxValue, eqId, name, frequencies, dbValues)
        return encodePacket(SET_EQ_COMMAND, sequence, payload)
    }

    fun encodeEqPayload(mode: Int, minValue: Int, maxValue: Int, eqId: Int, name: String?, frequencies: IntArray, dbValues: IntArray): ByteArray {
        require(frequencies.isNotEmpty()) { "EQ frequencies must not be empty" }
        require(frequencies.size == dbValues.size) { "Frequency and dB band counts must match" }
        require(frequencies.size <= 255) { "Too many EQ bands" }
        val nameBytes = (name ?: "").toByteArray(Charsets.UTF_8)
        require(nameBytes.size <= 255) { "EQ name too long" }
        val out = ByteBuffer.allocate(5 + nameBytes.size + 1 + frequencies.size * 3).order(ByteOrder.LITTLE_ENDIAN)
        out.put(mode.toByte()).put(minValue.toByte()).put(maxValue.toByte()).put(eqId.toByte()).put(nameBytes.size.toByte())
        out.put(nameBytes)
        out.put(frequencies.size.toByte())
        for (i in frequencies.indices) {
            require(frequencies[i] in 0..65535) { "Frequency must fit unsigned 16-bit field" }
            out.putShort(frequencies[i].toShort())
            out.put(dbValues[i].toByte())
        }
        return out.array()
    }
}
