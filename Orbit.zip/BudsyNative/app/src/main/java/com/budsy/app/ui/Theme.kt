package com.budsy.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.sharp.*
import androidx.compose.material.icons.twotone.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class ThemeMode(val label: String) {
    AURORA("Aurora Dark"), NEON("Neon Cyber"), SUNSET("Sunset Glass"), PEARL("Pearl Light"), AMOLED("AMOLED Black")
}
enum class IconStyle(val label: String) { FILLED("Filled"), OUTLINED("Outlined"), ROUNDED("Rounded"), SHARP("Sharp"), TWOTONE("Two-tone") }
enum class ChipLook(val label: String) { GRADIENT("Gradient"), GLASS("Glass"), NEON("Neon outline"), SOLID("Solid"), PLAIN("Plain") }
enum class BgStyle(val label: String) { AURORA("Aurora"), PARTICLES("Particles"), WAVES("Waves"), GRID("3D Grid") }

@Immutable
class Palette(
    val dark: Boolean,
    val bgTop: Color, val bgBottom: Color,
    val blobA: Color, val blobB: Color, val blobC: Color,
    val accent: Color, val accent2: Color, val onAccent: Color,
    val text: Color, val muted: Color,
    val glass: Color, val glassEdge: Color,
)

fun paletteOf(m: ThemeMode): Palette = when (m) {
    ThemeMode.AURORA -> Palette(true, Color(0xFF070B1E), Color(0xFF140B30),
        Color(0xFF5B8CFF), Color(0xFF9B5CFF), Color(0xFF22D3EE),
        Color(0xFF6AA8FF), Color(0xFFB388FF), Color.White,
        Color.White, Color(0xFFA9B0C8), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.28f))
    ThemeMode.NEON -> Palette(true, Color(0xFF04060A), Color(0xFF0A0F18),
        Color(0xFF00FFC8), Color(0xFFFF2BD6), Color(0xFF3B82F6),
        Color(0xFF00F5D4), Color(0xFFFF2BD6), Color(0xFF04120F),
        Color(0xFFEFFFFB), Color(0xFF8FB4AE), Color(0xFF00F5D4).copy(alpha = 0.07f), Color(0xFF00F5D4).copy(alpha = 0.35f))
    ThemeMode.SUNSET -> Palette(true, Color(0xFF1F0B2E), Color(0xFF3A0F2B),
        Color(0xFFFF7A59), Color(0xFFFFC145), Color(0xFFE5469B),
        Color(0xFFFF8A5B), Color(0xFFFFC857), Color(0xFF2A0D14),
        Color(0xFFFFF3EA), Color(0xFFD1A9B0), Color.White.copy(alpha = 0.09f), Color(0xFFFFC857).copy(alpha = 0.30f))
    ThemeMode.PEARL -> Palette(false, Color(0xFFF6F8FF), Color(0xFFE6ECFF),
        Color(0xFF9EC5FF), Color(0xFFD6B8FF), Color(0xFFA5F3E5),
        Color(0xFF147CF3), Color(0xFF7C4DFF), Color.White,
        Color(0xFF14172A), Color(0xFF646B85), Color.White.copy(alpha = 0.62f), Color.White.copy(alpha = 0.95f))
    ThemeMode.AMOLED -> Palette(true, Color.Black, Color(0xFF05050A),
        Color(0xFF1D4ED8), Color(0xFF6D28D9), Color(0xFF0E7490),
        Color(0xFF4DA3FF), Color(0xFF8E7CFF), Color.Black,
        Color(0xFFF2F4FF), Color(0xFF8A90A6), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.22f))
}

val LocalPalette = staticCompositionLocalOf { paletteOf(ThemeMode.AURORA) }
val LocalIconStyle = staticCompositionLocalOf { IconStyle.ROUNDED }
val LocalChipLook = staticCompositionLocalOf { ChipLook.GRADIENT }
val LocalMotion = staticCompositionLocalOf { true }
/** Smoothed phone tilt, x/y in -1..1 (sensor driven). Drives parallax + 3D layers. */
val LocalTilt = staticCompositionLocalOf<State<Offset>> { mutableStateOf(Offset.Zero) }

enum class BIcon {
    HEADPHONES, TOUCH, EQ, INFO, HEARING, BATTERY, CHEVRON, ADD, FIND, PALETTE, BLUETOOTH,
    GAME, NOISE_OFF, DND, DEVICES, SEARCH, BOLT, CUBE, SETTINGS, DELETE, TUNE
}

private fun ic(s: IconStyle, f: ImageVector, o: ImageVector, r: ImageVector, sh: ImageVector, t: ImageVector) = when (s) {
    IconStyle.FILLED -> f; IconStyle.OUTLINED -> o; IconStyle.ROUNDED -> r; IconStyle.SHARP -> sh; IconStyle.TWOTONE -> t
}

fun BIcon.vector(s: IconStyle): ImageVector = when (this) {
    BIcon.HEADPHONES -> ic(s, Icons.Filled.Headphones, Icons.Outlined.Headphones, Icons.Rounded.Headphones, Icons.Sharp.Headphones, Icons.TwoTone.Headphones)
    BIcon.TOUCH -> ic(s, Icons.Filled.TouchApp, Icons.Outlined.TouchApp, Icons.Rounded.TouchApp, Icons.Sharp.TouchApp, Icons.TwoTone.TouchApp)
    BIcon.EQ -> ic(s, Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq, Icons.Rounded.GraphicEq, Icons.Sharp.GraphicEq, Icons.TwoTone.GraphicEq)
    BIcon.INFO -> ic(s, Icons.Filled.Info, Icons.Outlined.Info, Icons.Rounded.Info, Icons.Sharp.Info, Icons.TwoTone.Info)
    BIcon.HEARING -> ic(s, Icons.Filled.Hearing, Icons.Outlined.Hearing, Icons.Rounded.Hearing, Icons.Sharp.Hearing, Icons.TwoTone.Hearing)
    BIcon.BATTERY -> ic(s, Icons.Filled.BatteryFull, Icons.Outlined.BatteryFull, Icons.Rounded.BatteryFull, Icons.Sharp.BatteryFull, Icons.TwoTone.BatteryFull)
    BIcon.CHEVRON -> ic(s, Icons.Filled.ChevronRight, Icons.Outlined.ChevronRight, Icons.Rounded.ChevronRight, Icons.Sharp.ChevronRight, Icons.TwoTone.ChevronRight)
    BIcon.ADD -> ic(s, Icons.Filled.Add, Icons.Outlined.Add, Icons.Rounded.Add, Icons.Sharp.Add, Icons.TwoTone.Add)
    BIcon.FIND -> ic(s, Icons.Filled.LocationSearching, Icons.Outlined.LocationSearching, Icons.Rounded.LocationSearching, Icons.Sharp.LocationSearching, Icons.TwoTone.LocationSearching)
    BIcon.PALETTE -> ic(s, Icons.Filled.Palette, Icons.Outlined.Palette, Icons.Rounded.Palette, Icons.Sharp.Palette, Icons.TwoTone.Palette)
    BIcon.BLUETOOTH -> ic(s, Icons.Filled.Bluetooth, Icons.Outlined.Bluetooth, Icons.Rounded.Bluetooth, Icons.Sharp.Bluetooth, Icons.TwoTone.Bluetooth)
    BIcon.GAME -> ic(s, Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports, Icons.Rounded.SportsEsports, Icons.Sharp.SportsEsports, Icons.TwoTone.SportsEsports)
    BIcon.NOISE_OFF -> ic(s, Icons.Filled.NoiseControlOff, Icons.Outlined.NoiseControlOff, Icons.Rounded.NoiseControlOff, Icons.Sharp.NoiseControlOff, Icons.TwoTone.NoiseControlOff)
    BIcon.DND -> ic(s, Icons.Filled.DoNotDisturb, Icons.Outlined.DoNotDisturb, Icons.Rounded.DoNotDisturb, Icons.Sharp.DoNotDisturb, Icons.TwoTone.DoNotDisturb)
    BIcon.DEVICES -> ic(s, Icons.Filled.Devices, Icons.Outlined.Devices, Icons.Rounded.Devices, Icons.Sharp.Devices, Icons.TwoTone.Devices)
    BIcon.SEARCH -> ic(s, Icons.Filled.Search, Icons.Outlined.Search, Icons.Rounded.Search, Icons.Sharp.Search, Icons.TwoTone.Search)
    BIcon.BOLT -> ic(s, Icons.Filled.Bolt, Icons.Outlined.Bolt, Icons.Rounded.Bolt, Icons.Sharp.Bolt, Icons.TwoTone.Bolt)
    BIcon.CUBE -> ic(s, Icons.Filled.ViewInAr, Icons.Outlined.ViewInAr, Icons.Rounded.ViewInAr, Icons.Sharp.ViewInAr, Icons.TwoTone.ViewInAr)
    BIcon.SETTINGS -> ic(s, Icons.Filled.Settings, Icons.Outlined.Settings, Icons.Rounded.Settings, Icons.Sharp.Settings, Icons.TwoTone.Settings)
    BIcon.DELETE -> ic(s, Icons.Filled.Delete, Icons.Outlined.Delete, Icons.Rounded.Delete, Icons.Sharp.Delete, Icons.TwoTone.Delete)
    BIcon.TUNE -> ic(s, Icons.Filled.Tune, Icons.Outlined.Tune, Icons.Rounded.Tune, Icons.Sharp.Tune, Icons.TwoTone.Tune)
}

@Composable
fun BudsyIcon(icon: BIcon, modifier: Modifier = Modifier, tint: Color = LocalPalette.current.text) {
    Icon(icon.vector(LocalIconStyle.current), contentDescription = null, modifier = modifier, tint = tint)
}
