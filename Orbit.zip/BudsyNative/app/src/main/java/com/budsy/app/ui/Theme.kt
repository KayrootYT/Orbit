package com.budsy.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.sharp.*
import androidx.compose.material.icons.twotone.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class ThemeMode(val label: String) { LIGHT("Light"), DARK("Dark"), AMOLED("AMOLED black") }
enum class IconStyle(val label: String) { ROUNDED("Rounded") }
enum class ChipLook(val label: String) { SOLID("Solid") }
enum class BgStyle(val label: String) { SOLID("Solid") }

@Immutable
class Palette(
    val dark: Boolean,
    val bgTop: Color, val bgBottom: Color,
    val blobA: Color, val blobB: Color, val blobC: Color,
    val accent: Color, val accent2: Color, val onAccent: Color,
    val text: Color, val muted: Color,
    val glass: Color, val glassEdge: Color,
)

fun paletteOf(m: ThemeMode): Palette = when (m) {
    ThemeMode.LIGHT -> Palette(false, Color(0xFFF7F7F7), Color(0xFFF7F7F7),
        Color(0xFFE8E8E8), Color(0xFFE8E8E8), Color(0xFFE8E8E8),
        Color(0xFF0B57D0), Color(0xFF0B57D0), Color.White,
        Color(0xFF1B1B1B), Color(0xFF666666), Color.White, Color(0xFFE0E0E0))
    ThemeMode.DARK -> Palette(true, Color(0xFF121212), Color(0xFF121212),
        Color(0xFF202020), Color(0xFF202020), Color(0xFF202020),
        Color(0xFFA8C7FA), Color(0xFFA8C7FA), Color(0xFF062E6F),
        Color(0xFFE6E6E6), Color(0xFFB0B0B0), Color(0xFF1E1E1E), Color(0xFF333333))
    ThemeMode.AMOLED -> Palette(true, Color.Black, Color.Black,
        Color.Black, Color.Black, Color.Black,
        Color(0xFFA8C7FA), Color(0xFFA8C7FA), Color(0xFF062E6F),
        Color(0xFFF5F5F5), Color(0xFFAAAAAA), Color(0xFF080808), Color(0xFF242424))
}

val LocalPalette = staticCompositionLocalOf { paletteOf(ThemeMode.DARK) }
val LocalIconStyle = staticCompositionLocalOf { IconStyle.ROUNDED }
val LocalChipLook = staticCompositionLocalOf { ChipLook.SOLID }
val LocalMotion = staticCompositionLocalOf { false }
val LocalTilt = staticCompositionLocalOf<State<Offset>> { mutableStateOf(Offset.Zero) }

enum class BIcon {
    HEADPHONES, TOUCH, EQ, INFO, HEARING, BATTERY, CHEVRON, ADD, FIND, PALETTE, BLUETOOTH,
    GAME, NOISE_OFF, DND, DEVICES, SEARCH, BOLT, CUBE, SETTINGS, DELETE, TUNE
}

private fun ic(s: IconStyle, f: ImageVector, o: ImageVector, r: ImageVector, sh: ImageVector, t: ImageVector): ImageVector = r

fun BIcon.vector(s: IconStyle): ImageVector = when (this) {
    BIcon.HEADPHONES -> ic(s, Icons.Filled.Headphones, Icons.Outlined.Headphones, Icons.Rounded.Headphones, Icons.Sharp.Headphones, Icons.TwoTone.Headphones)
    BIcon.TOUCH -> ic(s, Icons.Filled.TouchApp, Icons.Outlined.TouchApp, Icons.Rounded.TouchApp, Icons.Sharp.TouchApp, Icons.TwoTone.TouchApp)
    BIcon.EQ -> ic(s, Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq, Icons.Rounded.GraphicEq, Icons.Sharp.GraphicEq, Icons.TwoTone.GraphicEq)
    BIcon.INFO -> ic(s, Icons.Filled.Info, Icons.Outlined.Info, Icons.Rounded.Info, Icons.Sharp.Info, Icons.TwoTone.Info)
    BIcon.HEARING -> ic(s, Icons.Filled.Hearing, Icons.Outlined.Hearing, Icons.Rounded.Hearing, Icons.Sharp.Hearing, Icons.TwoTone.Hearing)
    BIcon.BATTERY -> ic(s, Icons.Filled.BatteryFull, Icons.Outlined.BatteryFull, Icons.Rounded.BatteryFull, Icons.Sharp.BatteryFull, Icons.TwoTone.BatteryFull)
    BIcon.CHEVRON -> ic(s, Icons.Filled.ChevronRight, Icons.Outlined.ChevronRight, Icons.Rounded.ChevronRight, Icons.Sharp.ChevronRight, Icons.TwoTone.ChevronRight)
    BIcon.ADD -> ic(s, Icons.Filled.Add, Icons.Outlined.Add, Icons.Rounded.Add, Icons.Sharp.Add, Icons.TwoTone.Add)
    BIcon.FIND -> ic(s, Icons.Filled.LocationSearching, Icons.Outlined.LocationSearching, Icons.Rounded.LocationSearching, Icons.Sharp.LocationSearching, Icons.TwoTone.LocationSearching)
    BIcon.PALETTE -> ic(s, Icons.Filled.Palette, Icons.Outlined.Palette, Icons.Rounded.Palette, Icons.Sharp.Palette, Icons.TwoTone.Palette)
    BIcon.BLUETOOTH -> ic(s, Icons.Filled.Bluetooth, Icons.Outlined.Bluetooth, Icons.Rounded.Bluetooth, Icons.Sharp.Bluetooth, Icons.TwoTone.Bluetooth)
    BIcon.GAME -> ic(s, Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports, Icons.Rounded.SportsEsports, Icons.Sharp.SportsEsports, Icons.TwoTone.SportsEsports)
    BIcon.NOISE_OFF -> ic(s, Icons.Filled.NoiseControlOff, Icons.Outlined.NoiseControlOff, Icons.Rounded.NoiseControlOff, Icons.Sharp.NoiseControlOff, Icons.TwoTone.NoiseControlOff)
    BIcon.DND -> ic(s, Icons.Filled.DoNotDisturb, Icons.Outlined.DoNotDisturb, Icons.Rounded.DoNotDisturb, Icons.Sharp.DoNotDisturb, Icons.TwoTone.DoNotDisturb)
    BIcon.DEVICES -> ic(s, Icons.Filled.Devices, Icons.Outlined.Devices, Icons.Rounded.Devices, Icons.Sharp.Devices, Icons.TwoTone.Devices)
    BIcon.SEARCH -> ic(s, Icons.Filled.Search, Icons.Outlined.Search, Icons.Rounded.Search, Icons.Sharp.Search, Icons.TwoTone.Search)
    BIcon.BOLT -> ic(s, Icons.Filled.Bolt, Icons.Outlined.Bolt, Icons.Rounded.Bolt, Icons.Sharp.Bolt, Icons.TwoTone.Bolt)
    BIcon.CUBE -> ic(s, Icons.Filled.ViewInAr, Icons.Outlined.ViewInAr, Icons.Rounded.ViewInAr, Icons.Sharp.ViewInAr, Icons.TwoTone.ViewInAr)
    BIcon.SETTINGS -> ic(s, Icons.Filled.Settings, Icons.Outlined.Settings, Icons.Rounded.Settings, Icons.Sharp.Settings, Icons.TwoTone.Settings)
    BIcon.DELETE -> ic(s, Icons.Filled.Delete, Icons.Outlined.Delete, Icons.Rounded.Delete, Icons.Sharp.Delete, Icons.TwoTone.Delete)
    BIcon.TUNE -> ic(s, Icons.Filled.Tune, Icons.Outlined.Tune, Icons.Rounded.Tune, Icons.Sharp.Tune, Icons.TwoTone.Tune)
}

@Composable
fun BudsyIcon(icon: BIcon, modifier: Modifier = Modifier, tint: Color = LocalPalette.current.text) {
    Icon(icon.vector(LocalIconStyle.current), contentDescription = null, modifier = modifier, tint = tint)
}
