package com.budsy.app.protocol

/**
 * Raw AA-framed classic RFCOMM protocol extracted from Budsy_Backend_Protocol_Only.zip.
 * This is NOT the HeyMelody GATT 5-byte packet format and must not be OPOv1-wrapped.
 */
object NordBudsProtocol {
    const val GRP_QUERY = 0x01
    const val GRP_PUSH = 0x02
    const val GRP_SET = 0x04
    const val ANC_OFF = 0
    const val ANC_ON = 1
    const val ANC_TRANSP = 2
    val FEATURE_REQUEST = intArrayOf(7, 0x06, 0x05, 0x0b, 0x11, 0x1b, 0x1d, 0x20)

    data class Frame(val commandLow: Int, val group: Int, val sequence: Int, val payload: IntArray) {
        val commandId: Int get() = ((group and 0x7f) shl 8) or (commandLow and 0xff)
        val commandLowAlias: Int get() = commandLow
        val status: Int get() = payload.firstOrNull() ?: -1
        val isPush: Boolean get() = group == GRP_PUSH
    }
    data class Battery(val slot: Int, val percent: Int, val charging: Boolean)
    data class Wear(val slot: Int, val flags: Int)
    data class Peer(val mac: String, val name: String)
    data class CustomEqProfile(val name: String, val active: Boolean, val bands: List<Pair<Int, Int>>)

    fun hex(v: Int) = (v and 0xff).toString(16).padStart(2, '0')

    fun buildFrame(commandLow: Int, group: Int, sequence: Int, payload: IntArray = intArrayOf()): ByteArray {
        require(commandLow in 0..255 && group in 0..255 && sequence in 0..255)
        require(payload.size <= 0xffff && payload.all { it in 0..255 })
        val length = 7 + payload.size
        return ByteArray(9 + payload.size).also { b ->
            b[0] = 0xAA.toByte(); b[1] = length.toByte(); b[2] = (length ushr 8).toByte(); b[3] = 0
            b[4] = commandLow.toByte(); b[5] = group.toByte(); b[6] = sequence.toByte()
            b[7] = payload.size.toByte(); b[8] = (payload.size ushr 8).toByte()
            payload.forEachIndexed { i, v -> b[9 + i] = v.toByte() }
        }
    }

    class Parser {
        private var buffer = ByteArray(0)
        fun reset() { buffer = ByteArray(0) }
        fun feed(bytes: ByteArray): List<Frame> {
            if (bytes.isNotEmpty()) buffer += bytes
            val out = ArrayList<Frame>()
            while (true) {
                val start = buffer.indexOf(0xAA.toByte())
                if (start < 0) { buffer = ByteArray(0); break }
                if (start > 0) buffer = buffer.copyOfRange(start, buffer.size)
                if (buffer.size < 9) break
                val len = (buffer[1].toInt() and 0xff) or ((buffer[2].toInt() and 0xff) shl 8)
                if (len < 7 || len > 4096) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val total = 2 + len
                if (buffer.size < total) break
                val payloadLen = (buffer[7].toInt() and 0xff) or ((buffer[8].toInt() and 0xff) shl 8)
                if (payloadLen > total - 9 || payloadLen != total - 9) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val payload = IntArray(payloadLen) { buffer[9 + it].toInt() and 0xff }
                out += Frame(buffer[4].toInt() and 0xff, buffer[5].toInt() and 0xff, buffer[6].toInt() and 0xff, payload)
                buffer = buffer.copyOfRange(total, buffer.size)
            }
            if (buffer.size > 8192) buffer = buffer.copyOfRange(buffer.size - 8192, buffer.size)
            return out
        }
    }

    /** Payload: [status, count, (slot, percent|charging-bit)*], slots 1=L, 2=R, 3=case. */
    fun parseBattery(p: IntArray): List<Battery> {
        if (p.size < 2) return emptyList()
        val count = p[1].coerceAtMost(20)
        return (0 until count).mapNotNull { i ->
            val j = 2 + i * 2
            if (j + 1 >= p.size || p[j] !in 1..3) null else {
                val raw = p[j + 1]; val pct = raw and 0x7f
                Battery(p[j] - 1, if (pct <= 100) pct else -1, raw and 0x80 != 0)
            }
        }
    }
    fun parseWear(p: IntArray): List<Wear> {
        if (p.size < 2) return emptyList()
        return (0 until p[1].coerceAtMost(20)).mapNotNull { i ->
            val j = 2 + i * 2
            if (j + 1 < p.size && p[j] in 1..3) Wear(p[j] - 1, p[j + 1]) else null
        }
    }
    fun parseFirmware(p: IntArray): String? = p.drop(2).mapNotNull { it.takeIf { c -> c in 32..126 }?.toChar() }.joinToString("").trim().ifEmpty { null }
    fun parseGestureTable(p: IntArray): Map<Int, Int> {
        if (p.size < 2) return emptyMap()
        val out = linkedMapOf<Int, Int>()
        repeat(p[1].coerceAtMost(64)) { i ->
            val j = 2 + i * 4
            if (j + 3 < p.size) { val side=p[j]; val enabled=p[j+1]; val gid=p[j+2]; val fn=p[j+3]; if (enabled != 0 && side in 1..2) out[side*16+gid]=fn }
        }
        return out
    }
    fun parseFlags(p: IntArray): List<Pair<Int, Int>> {
        if (p.size < 2) return emptyList()
        return (0 until p[1].coerceAtMost(128)).mapNotNull { i -> val j=2+i*2; if (j+1<p.size) p[j] to p[j+1] else null }
    }
    fun parsePeers(p: IntArray): List<Peer> {
        if (p.size < 2) return emptyList()
        val out=ArrayList<Peer>(); var i=2
        repeat(p[1].coerceAtMost(8)) {
            if (i+9>p.size) return@repeat
            val mac=(0..5).joinToString(":") { hex(p[i+it]).uppercase() }
            val nameLen=p[i+9]; if (i+10+nameLen>p.size) return@repeat
            out += Peer(mac,p.slice(i+10 until i+10+nameLen).map { it.toChar() }.joinToString(""))
            i += 10+nameLen
        }
        return out
    }
    fun decodeAnc(mask: Int): Int = when { (mask and 0x0300)!=0 -> ANC_TRANSP; (mask and 0x08F2)!=0 -> ANC_ON; (mask and 0x0008)!=0 -> ANC_OFF; else -> -1 }

    fun buildCustomEqPayload(profile: CustomEqProfile, min: Int, max: Int): IntArray {
        val name = profile.name.toByteArray(Charsets.UTF_8).map { it.toInt() and 0xff }
        require(name.size <= 255 && profile.bands.size <= 32)
        val out=ArrayList<Int>(); out += 1; out += if(profile.active) 1 else 0; out += min and 0xff; out += max and 0xff; out += 0; out += name.size; out.addAll(name); out += profile.bands.size
        profile.bands.forEach { (hz,gain) -> require(hz in 0..65535); out += hz and 0xff; out += (hz ushr 8) and 0xff; out += gain and 0xff }
        return out.toIntArray()
    }
}
