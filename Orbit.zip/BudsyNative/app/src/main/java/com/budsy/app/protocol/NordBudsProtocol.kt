package com.budsy.app.protocol

/**
 * Raw classic-RFCOMM frame format recovered from the supplied Budsy (2).zip.
 * This is distinct from the 5-byte HeyMelody GATT packet format and OPOv1 BLE framing.
 */
object NordBudsProtocol {
    data class Frame(val commandLow: Int, val group: Int, val sequence: Int, val payload: IntArray) {
        val commandId: Int get() = ((group and 0x7f) shl 8) or (commandLow and 0xff)
        val status: Int get() = payload.firstOrNull() ?: -1
        val isPush: Boolean get() = group == 0x02
    }
    data class Battery(val slot: Int, val percent: Int, val charging: Boolean)

    fun buildFrame(commandLow: Int, group: Int, sequence: Int, payload: IntArray = intArrayOf()): ByteArray {
        require(commandLow in 0..255 && group in 0..255 && sequence in 0..255)
        require(payload.size <= 0xffff && payload.all { it in 0..255 })
        val length = 7 + payload.size
        return ByteArray(9 + payload.size).also { b ->
            b[0] = 0xAA.toByte(); b[1] = length.toByte(); b[2] = (length ushr 8).toByte(); b[3] = 0
            b[4] = commandLow.toByte(); b[5] = group.toByte(); b[6] = sequence.toByte()
            b[7] = payload.size.toByte(); b[8] = (payload.size ushr 8).toByte()
            payload.forEachIndexed { i, v -> b[9 + i] = v.toByte() }
        }
    }

    class Parser {
        private var buffer = ByteArray(0)
        fun reset() { buffer = ByteArray(0) }
        fun feed(bytes: ByteArray): List<Frame> {
            if (bytes.isNotEmpty()) buffer += bytes
            val out = ArrayList<Frame>()
            while (true) {
                val start = buffer.indexOf(0xAA.toByte())
                if (start < 0) { buffer = ByteArray(0); break }
                if (start > 0) buffer = buffer.copyOfRange(start, buffer.size)
                if (buffer.size < 9) break
                val len = (buffer[1].toInt() and 0xff) or ((buffer[2].toInt() and 0xff) shl 8)
                if (len < 7 || len > 4096) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val total = 2 + len
                if (buffer.size < total) break
                val payloadLen = (buffer[7].toInt() and 0xff) or ((buffer[8].toInt() and 0xff) shl 8)
                if (payloadLen > total - 9) { buffer = buffer.copyOfRange(1, buffer.size); continue }
                val payload = IntArray(payloadLen) { buffer[9 + it].toInt() and 0xff }
                out += Frame(buffer[4].toInt() and 0xff, buffer[5].toInt() and 0xff, buffer[6].toInt() and 0xff, payload)
                buffer = buffer.copyOfRange(total, buffer.size)
            }
            if (buffer.size > 8192) buffer = buffer.copyOfRange(buffer.size - 8192, buffer.size)
            return out
        }
    }

    /** Payload layout from supplied source: [status, count, (slot, percent|charging-bit)*]. slot 1=L, 2=R, 3=case. */
    fun parseBattery(payload: IntArray): List<Battery> {
        if (payload.size < 2) return emptyList()
        val count = payload[1].coerceAtMost(20)
        val out = ArrayList<Battery>()
        repeat(count) { i ->
            val j = 2 + i * 2
            if (j + 1 < payload.size && payload[j] in 1..3) {
                val raw = payload[j + 1]
                val pct = raw and 0x7f
                out += Battery(payload[j] - 1, if (pct <= 100) pct else -1, raw and 0x80 != 0)
            }
        }
        return out
    }
}
