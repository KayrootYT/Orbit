package com.budsy.app.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.budsy.app.protocol.HeyMelodyProtocol
import com.budsy.app.protocol.OpoV1Wrapper
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Primary HeyMelody control transport over classic Bluetooth RFCOMM.
 * HeyMelody uses a model-specific UUID from SupportDeviceConfig; use the configured UUID
 * when known. The standard SPP UUID below is only a fallback and may not match every model.
 * Commands are wrapped in the same OPOv1 framing observed in the HeyMelody RFCOMM reader.
 */
class BudsyRfcommClient(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onConnectionState: (Boolean) -> Unit,
    private val onPacket: (ByteArray) -> Unit = {}
) {
    companion object {
        val FALLBACK_SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val STANDARD_BASE = "-0000-1000-8000-00805f9b34fb"

        private fun isStandard(uuid: UUID) = uuid.toString().lowercase().endsWith(STANDARD_BASE)
        private fun isAudioUuid(uuid: UUID): Boolean =
            uuid.toString().startsWith("0000110") || uuid.toString().startsWith("0000111")

        /** Prefer advertised vendor service records, then SPP, then other non-audio records. */
        internal fun orderCandidates(advertised: List<UUID>, preferred: UUID? = null): List<UUID> {
            val vendor = advertised.filterNot { isStandard(it) }
            val other = advertised.filter { isStandard(it) && !isAudioUuid(it) && it != FALLBACK_SPP_UUID }
            return (listOfNotNull(preferred) + vendor + FALLBACK_SPP_UUID + other).distinct()
        }
    }

    private val adapter: BluetoothAdapter? by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var connected = false
    @Volatile private var generation = 0

    fun hasRequiredPermissions(): Boolean {
        val required = if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_CONNECT)
            else listOf(Manifest.permission.BLUETOOTH)
        return required.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice, serviceUuid: UUID? = null) {
        if (!hasRequiredPermissions()) { postStatus("Bluetooth Connect permission required for RFCOMM"); return }
        val a = adapter ?: run { postStatus("Bluetooth adapter unavailable"); return }
        if (!a.isEnabled) { postStatus("Turn on Bluetooth first"); return }
        disconnect(false)
        val token = generation
        main.post { if (token == generation) { onConnectionState(false); onStatus("Discovering the earbuds' RFCOMM service UUID…") } }
        executor.execute {
            try {
                try { a.cancelDiscovery() } catch (_: Exception) { }
                // HeyMelody resolves its classic control UUID from SupportDeviceConfig. First inspect
                // the device's SDP records rather than assuming the generic SPP UUID is correct.
                try { device.fetchUuidsWithSdp() } catch (_: Exception) { }
                try { Thread.sleep(500) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                var advertised = readAdvertisedUuids(device)
                var retries = 0
                while (advertised.isEmpty() && retries < 6 && token == generation) {
                    try { Thread.sleep(250) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
                    advertised = readAdvertisedUuids(device)
                    retries++
                }
                val candidates = orderCandidates(advertised, serviceUuid)
                main.post {
                    if (token == generation) onStatus(
                        if (advertised.isEmpty()) "No SDP UUIDs advertised; trying fallback SPP ${FALLBACK_SPP_UUID}"
                        else "RFCOMM candidates: " + candidates.joinToString()
                    )
                }
                for (uuid in candidates) {
                    if (token != generation) return@execute
                    for (insecure in booleanArrayOf(false, true)) {
                        if (token != generation) return@execute
                        var candidate: BluetoothSocket? = null
                        val started = System.currentTimeMillis()
                        try {
                            main.post { if (token == generation) onStatus("Trying ${if (insecure) "insecure" else "secure"} RFCOMM UUID $uuid") }
                            candidate = if (insecure) device.createInsecureRfcommSocketToServiceRecord(uuid)
                                else device.createRfcommSocketToServiceRecord(uuid)
                            candidate.connect()
                            if (token != generation) { candidate.close(); return@execute }
                            val input = candidate.inputStream
                            val out = candidate.outputStream
                            socket = candidate
                            output = out
                            connected = true
                            main.post {
                                if (token == generation) {
                                    onConnectionState(true)
                                    onStatus("RFCOMM socket connected with UUID $uuid; waiting for HeyMelody response.")
                                }
                            }
                            readLoop(candidate, input, token)
                            return@execute
                        } catch (e: Exception) {
                            try { candidate?.close() } catch (_: Exception) { }
                            if (token != generation) return@execute
                            main.post { if (token == generation) onStatus("RFCOMM attempt failed for $uuid (${if (insecure) "insecure" else "secure"}): ${e.message ?: e.javaClass.simpleName}") }
                            // A slow connect commonly means the earbuds are asleep/out of range;
                            // avoid spending minutes trying every advertised record.
                            if (System.currentTimeMillis() - started > 4000) {
                                main.post { if (token == generation) { onConnectionState(false); onStatus("RFCOMM timed out on $uuid. Put both earbuds in the case, reopen them, and retry.") } }
                                return@execute
                            }
                        }
                    }
                }
                if (token == generation) main.post {
                    onConnectionState(false)
                    onStatus("RFCOMM failed for all candidate UUIDs. Check pairing and the model-specific HeyMelody SupportDeviceConfig UUID.")
                }
            } catch (e: Exception) {
                if (token == generation) main.post {
                    onConnectionState(false)
                    onStatus("RFCOMM service discovery failed: ${e.message ?: e.javaClass.simpleName}")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun readAdvertisedUuids(device: BluetoothDevice): List<UUID> =
        try { device.uuids?.map { it.uuid }?.distinct() ?: emptyList() } catch (_: Exception) { emptyList() }

    private fun postStatus(message: String) { main.post { onStatus(message) } }

    private fun readLoop(active: BluetoothSocket, input: InputStream, token: Int) {
        val decoder = OpoV1Wrapper.StreamDecoder()
        val buffer = ByteArray(1024)
        try {
            while (token == generation && active.isConnected) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count == 0) continue
                val result = decoder.append(buffer.copyOf(count))
                result.packets.forEach { frame ->
                    val decoded = HeyMelodyProtocol.StreamDecoder().append(frame).packets
                    decoded.forEach { packet -> main.post { if (token == generation) onPacket(HeyMelodyProtocol.encodePacket(packet.commandId, packet.sequence, packet.payload)) } }
                }
            }
        } catch (e: Exception) {
            if (token == generation) main.post { onStatus("RFCOMM stream ended after socket setup: ${e.message ?: e.javaClass.simpleName}. Check whether this model exposes SPP and whether the UUID matches HeyMelody SupportDeviceConfig.") }
        } finally {
            if (token == generation) {
                connected = false; socket = null; output = null
                try { active.close() } catch (_: Exception) { }
                main.post { if (token == generation) { onConnectionState(false); onStatus("RFCOMM disconnected") } }
            }
        }
    }

    fun writePacket(packet: ByteArray): Boolean {
        if (!connected || output == null) { postStatus("RFCOMM is not connected"); return false }
        val frames = try { OpoV1Wrapper.frame(packet) } catch (e: Exception) {
            postStatus("Could not frame HeyMelody packet: ${e.message}"); return false
        }
        if (frames.isEmpty()) return false
        val token = generation
        executor.execute {
            try {
                val stream = output ?: throw IllegalStateException("RFCOMM output stream unavailable")
                frames.forEach { frame ->
                    if (token != generation) return@execute
                    stream.write(frame)
                }
                stream.flush()
                main.post { if (token == generation) onStatus("Sent ${frames.size} OPOv1 RFCOMM frame(s); waiting for device response") }
            } catch (e: Exception) {
                main.post { if (token == generation) onStatus("RFCOMM write failed: ${e.message ?: e.javaClass.simpleName}") }
                disconnect()
            }
        }
        return true
    }

    fun disconnect(report: Boolean = true) {
        generation++
        connected = false
        val old = socket
        socket = null; output = null
        try { old?.close() } catch (_: Exception) { }
        main.post { onConnectionState(false); if (report) onStatus("RFCOMM disconnected") }
    }

    fun close() { disconnect(false); executor.shutdownNow() }
}
