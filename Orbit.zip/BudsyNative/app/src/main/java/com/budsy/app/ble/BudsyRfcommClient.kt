package com.budsy.app.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.budsy.app.protocol.HeyMelodyProtocol
import com.budsy.app.protocol.OpoV1Wrapper
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Primary HeyMelody control transport over classic Bluetooth RFCOMM.
 * HeyMelody uses a model-specific UUID from SupportDeviceConfig; use the configured UUID
 * when known. The standard SPP UUID below is only a fallback and may not match every model.
 * Commands are wrapped in the same OPOv1 framing observed in the HeyMelody RFCOMM reader.
 */
class BudsyRfcommClient(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onConnectionState: (Boolean) -> Unit,
    private val onPacket: (ByteArray) -> Unit = {}
) {
    companion object {
        val FALLBACK_SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val adapter: BluetoothAdapter? by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var connected = false
    @Volatile private var generation = 0

    fun hasRequiredPermissions(): Boolean {
        val required = if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_CONNECT)
            else listOf(Manifest.permission.BLUETOOTH)
        return required.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice, serviceUuid: UUID = FALLBACK_SPP_UUID) {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth Connect permission required for RFCOMM"); return }
        val a = adapter ?: run { onStatus("Bluetooth adapter unavailable"); return }
        if (!a.isEnabled) { onStatus("Turn on Bluetooth first"); return }
        disconnect(false)
        val token = generation
        onConnectionState(false)
        onStatus("Connecting over RFCOMM…")
        executor.execute {
            var candidate: BluetoothSocket? = null
            try {
                try { a.cancelDiscovery() } catch (_: Exception) { }
                candidate = device.createRfcommSocketToServiceRecord(serviceUuid)
                candidate.connect()
                if (token != generation) { candidate.close(); return@execute }
                socket = candidate
                output = candidate.outputStream
                connected = true
                main.post {
                    if (token == generation) {
                        onConnectionState(true)
                        onStatus("RFCOMM connected. Device command acknowledgement is still separate.")
                    }
                }
                readLoop(candidate, candidate.inputStream, token)
            } catch (e: Exception) {
                try { candidate?.close() } catch (_: Exception) { }
                if (token == generation) {
                    connected = false; socket = null; output = null
                    main.post { onConnectionState(false); onStatus("RFCOMM connection failed: ${e.message ?: e.javaClass.simpleName}. Check pairing and the model-specific HeyMelody service UUID.") }
                }
            }
        }
    }

    private fun readLoop(active: BluetoothSocket, input: InputStream, token: Int) {
        val decoder = OpoV1Wrapper.StreamDecoder()
        val buffer = ByteArray(1024)
        try {
            while (token == generation && active.isConnected) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count == 0) continue
                val result = decoder.append(buffer.copyOf(count))
                result.packets.forEach { frame ->
                    val decoded = HeyMelodyProtocol.StreamDecoder().append(frame).packets
                    decoded.forEach { packet -> main.post { if (token == generation) onPacket(HeyMelodyProtocol.encodePacket(packet.commandId, packet.sequence, packet.payload)) } }
                }
            }
        } catch (e: Exception) {
            if (token == generation) main.post { onStatus("RFCOMM read stopped: ${e.message ?: e.javaClass.simpleName}") }
        } finally {
            if (token == generation) {
                connected = false; socket = null; output = null
                try { active.close() } catch (_: Exception) { }
                main.post { if (token == generation) { onConnectionState(false); onStatus("RFCOMM disconnected") } }
            }
        }
    }

    fun writePacket(packet: ByteArray): Boolean {
        if (!connected || output == null) { onStatus("RFCOMM is not connected"); return false }
        val frames = try { OpoV1Wrapper.frame(packet) } catch (e: Exception) {
            onStatus("Could not frame HeyMelody packet: ${e.message}"); return false
        }
        if (frames.isEmpty()) return false
        val token = generation
        executor.execute {
            try {
                val stream = output ?: throw IllegalStateException("RFCOMM output stream unavailable")
                frames.forEach { frame ->
                    if (token != generation) return@execute
                    stream.write(frame)
                }
                stream.flush()
                main.post { if (token == generation) onStatus("Sent ${frames.size} OPOv1 RFCOMM frame(s); waiting for device response") }
            } catch (e: Exception) {
                main.post { if (token == generation) onStatus("RFCOMM write failed: ${e.message ?: e.javaClass.simpleName}") }
                disconnect()
            }
        }
        return true
    }

    fun disconnect(report: Boolean = true) {
        generation++
        connected = false
        val old = socket
        socket = null; output = null
        try { old?.close() } catch (_: Exception) { }
        onConnectionState(false)
        if (report) onStatus("RFCOMM disconnected")
    }

    fun close() { disconnect(false); executor.shutdownNow() }
}
