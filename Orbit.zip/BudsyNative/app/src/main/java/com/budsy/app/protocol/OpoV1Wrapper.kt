package com.budsy.app.protocol

/**
 * OPOv1 BLE transport framing recovered from HeyMelody's F8.b (TLVDataProcessor)
 * and G8.b (OPOv1Wrapper). The inner HeyMelody packet must be wrapped before GATT writes.
 */
object OpoV1Wrapper {
    // HeyMelody GattDevice product type 102 sets mDeviceMaxFrameSize to 660.
    const val MAX_FRAME_SIZE = 660
    private const val SOF = 0xAA

    fun frame(packet: ByteArray, maxFrameSize: Int = MAX_FRAME_SIZE): List<ByteArray> {
        require(maxFrameSize in 32..660) { "Unsupported OPOv1 frame size" }
        if (packet.isEmpty()) return emptyList()

        // A complete packet has only the flag and reserved bytes; no fragment sequence byte.
        val singleBodyLength = packet.size + 2
        if (1 + varInt(singleBodyLength).size + singleBodyLength <= maxFrameSize) {
            val prefix = varInt(singleBodyLength)
            return listOf(byteArrayOf(SOF.toByte()) + prefix + byteArrayOf(0, 0) + packet)
        }

        val out = mutableListOf<ByteArray>()
        var offset = 0
        var fragmentIndex = 0
        while (offset < packet.size) {
            val remaining = packet.size - offset
            var chunkSize = minOf(remaining, maxFrameSize - 5)
            while (true) {
                val bodyLength = chunkSize + 3 // flag + reserved + FSN + payload
                val prefixSize = varInt(bodyLength).size
                val adjusted = minOf(remaining, maxFrameSize - prefixSize - 4)
                if (adjusted == chunkSize && varInt(chunkSize + 3).size == prefixSize) break
                chunkSize = adjusted
            }
            require(chunkSize > 0) { "Unable to fit OPOv1 fragment in frame" }
            val isLast = offset + chunkSize >= packet.size
            val flag = when {
                fragmentIndex == 0 -> 1 // start
                isLast -> 3             // end
                else -> 2                // middle
            }
            val bodyLength = chunkSize + 3
            val prefix = varInt(bodyLength)
            val frame = ByteArray(1 + prefix.size + bodyLength)
            var pos = 0
            frame[pos++] = SOF.toByte()
            prefix.forEach { frame[pos++] = it }
            frame[pos++] = flag.toByte()
            frame[pos++] = 0 // reserved byte used by OPOv1Wrapper
            frame[pos++] = fragmentIndex.toByte()
            packet.copyInto(frame, pos, offset, offset + chunkSize)
            out += frame
            offset += chunkSize
            fragmentIndex++
        }
        return out
    }

    private fun varInt(value: Int): ByteArray {
        require(value >= 0)
        var n = value
        val out = ArrayList<Byte>(3)
        do {
            var b = n and 0x7F
            n = n ushr 7
            if (n != 0) b = b or 0x80
            out += b.toByte()
        } while (n != 0)
        return out.toByteArray()
    }

    /** Parses notification chunks into complete inner packets; supports split/coalesced BLE notifications. */
    class StreamDecoder(private val maxFrameBytes: Int = 4096) {
        private var pending = ByteArray(0)
        private var fragmented = ByteArray(0)
        private var expectedFragment = 0

        data class Result(val packets: List<ByteArray>, val bufferedBytes: Int, val discardedBytes: Int)
        fun reset() { pending = ByteArray(0); fragmented = ByteArray(0); expectedFragment = 0 }

        fun append(chunk: ByteArray): Result {
            if (chunk.isNotEmpty()) pending += chunk
            val completed = mutableListOf<ByteArray>()
            var offset = 0
            var discarded = 0
            while (offset < pending.size) {
                if ((pending[offset].toInt() and 0xFF) != SOF) { offset++; discarded++; continue }
                val prefix = readVarInt(pending, offset + 1) ?: break
                val (bodyLength, prefixLength) = prefix
                if (bodyLength < 2 || bodyLength > maxFrameBytes) { offset++; discarded++; continue }
                val bodyStart = offset + 1 + prefixLength
                val end = bodyStart + bodyLength
                if (end > pending.size) break
                val flag = pending[bodyStart].toInt() and 0xFF
                // bodyStart + 1 is reserved; fragmented frames carry FSN at bodyStart + 2.
                val payloadStart = bodyStart + if (flag == 0) 2 else 3
                if (payloadStart > end) { offset++; discarded++; continue }
                val payload = pending.copyOfRange(payloadStart, end)
                when (flag) {
                    0 -> completed += payload
                    1 -> { fragmented = payload; expectedFragment = 1 }
                    2 -> if (fragmented.isNotEmpty()) { fragmented += payload; expectedFragment++ }
                    3 -> if (fragmented.isNotEmpty()) { fragmented += payload; completed += fragmented; fragmented = ByteArray(0); expectedFragment = 0 }
                    else -> { fragmented = ByteArray(0); expectedFragment = 0; discarded += bodyLength }
                }
                offset = end
            }
            if (offset > 0) pending = pending.copyOfRange(offset, pending.size)
            if (pending.size > maxFrameBytes) {
                val drop = pending.size - maxFrameBytes
                pending = pending.copyOfRange(drop, pending.size); discarded += drop
            }
            return Result(completed, pending.size, discarded)
        }

        private fun readVarInt(bytes: ByteArray, start: Int): Pair<Int, Int>? {
            var value = 0
            var shift = 0
            var i = start
            while (i < bytes.size && i - start < 4) {
                val b = bytes[i].toInt() and 0xFF
                value = value or ((b and 0x7F) shl shift)
                i++
                if ((b and 0x80) == 0) return value to (i - start)
                shift += 7
            }
            return null
        }
    }
}
