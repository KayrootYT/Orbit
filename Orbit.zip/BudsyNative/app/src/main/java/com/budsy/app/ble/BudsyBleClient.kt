package com.budsy.app.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.budsy.app.protocol.HeyMelodyProtocol
import java.util.UUID

/**
 * BLE foundation: scan (filtered or "show all"), bonded-device list, connect with
 * automatic retry on the common GATT 133 failure, service inventory, notifications.
 * Writes are only sent through [writeVerifiedPacket] with source-verified packets.
 */
class BudsyBleClient(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onDevice: (BluetoothDevice, String, Int) -> Unit,
    private val onServices: (List<GattServiceInfo>) -> Unit,
    private val onConnectionState: (Boolean) -> Unit = {}
) {
    data class GattServiceInfo(val uuid: UUID, val characteristics: List<GattCharacteristicInfo>)
    data class GattCharacteristicInfo(val uuid: UUID, val properties: Int)

    private val adapter: BluetoothAdapter? by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private val main = Handler(Looper.getMainLooper())
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private var lastDevice: BluetoothDevice? = null
    private var retries = 0
    private val subscribedCharacteristics = mutableSetOf<UUID>()
    private val rxDecoder = HeyMelodyProtocol.StreamDecoder()
    private val scanTimeout = Runnable {
        if (scanning) { stopScan(); onStatus("Scan finished") }
    }

    fun hasRequiredPermissions(): Boolean {
        val required = if (Build.VERSION.SDK_INT >= 31) {
            listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return required.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    /** Already-paired devices. Earbuds connected to the phone stop advertising, so they only show up here. */
    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<Pair<BluetoothDevice, String>> {
        if (!hasRequiredPermissions()) return emptyList()
        return try {
            adapter?.bondedDevices.orEmpty().map { it to (it.name ?: it.address) }
        } catch (_: SecurityException) { emptyList() }
    }

    @SuppressLint("MissingPermission")
    fun startScan(showAll: Boolean = false) {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return }
        val a = adapter
        if (a == null) { onStatus("This device has no Bluetooth adapter"); return }
        if (!a.isEnabled) { onStatus("Turn on Bluetooth first"); return }
        val scanner = a.bluetoothLeScanner ?: run { onStatus("BLE scanner unavailable"); return }
        stopScan()
        try {
            // FIX: ScanSettings must never be null when filters are supplied.
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            val filters = if (showAll) null else HeyMelodyProtocol.scanFilters()
            scanner.startScan(filters, settings, scanCallback)
            scanning = true
            onStatus(if (showAll) "Scanning all BLE devices…" else "Scanning for HeyMelody-compatible earbuds…")
            main.removeCallbacks(scanTimeout)
            main.postDelayed(scanTimeout, 12_000L)
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied")
        } catch (e: RuntimeException) {
            onStatus("Could not start BLE scan: ${e.message ?: "unknown error"}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        main.removeCallbacks(scanTimeout)
        if (!scanning) return
        try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) { }
        scanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = try { d.name } catch (_: SecurityException) { null } ?: result.scanRecord?.deviceName ?: "Unknown BLE device"
            main.post { onDevice(d, name, result.rssi) }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            main.post { onStatus("BLE scan failed (code $errorCode)") }
        }
    }

    fun connect(device: BluetoothDevice) {
        retries = 0
        lastDevice = device
        openGatt(device)
    }

    @SuppressLint("MissingPermission")
    private fun openGatt(device: BluetoothDevice) {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return }
        stopScan()
        closeGatt()
        onStatus("Connecting…")
        try {
            gatt = if (Build.VERSION.SDK_INT >= 23)
                device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(context, false, gattCallback)
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied")
        } catch (e: RuntimeException) {
            onStatus("Could not connect: ${e.message ?: "unknown error"}")
        }
    }

    /**
     * Sends a caller-supplied, source-verified protocol packet to the write characteristic.
     * Never pass guessed packets.
     */
    @SuppressLint("MissingPermission")
    fun writeVerifiedPacket(packet: ByteArray, writeCharacteristicUuid: UUID = HeyMelodyProtocol.defaultWriteCharacteristicUuid): Boolean {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return false }
        val activeGatt = gatt ?: run { onStatus("Not connected to a BLE device"); return false }
        val characteristic = activeGatt.services
            .asSequence()
            .flatMap { it.characteristics.asSequence() }
            .firstOrNull { it.uuid == writeCharacteristicUuid }
        if (characteristic == null) {
            onStatus("Write characteristic $writeCharacteristicUuid not found on this device")
            return false
        }
        val props = characteristic.properties
        val canWrite = (props and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
            (props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        if (!canWrite) { onStatus("Characteristic does not advertise write support"); return false }
        return try {
            val writeType = if ((props and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                activeGatt.writeCharacteristic(characteristic, packet, writeType) == BluetoothGatt.GATT_SUCCESS
            } else {
                @Suppress("DEPRECATION")
                run {
                    characteristic.writeType = writeType
                    characteristic.value = packet
                    activeGatt.writeCharacteristic(characteristic)
                }
            }
            onStatus(if (ok) "Packet queued; waiting for device acknowledgement…" else "BLE write request failed")
            ok
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied during write"); false
        } catch (e: RuntimeException) {
            onStatus("BLE write failed: ${e.message ?: "unknown error"}"); false
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        retries = 99 // user-initiated: never auto-retry
        try { gatt?.disconnect() } catch (_: Exception) { }
    }

    fun close() {
        stopScan()
        main.removeCallbacksAndMessages(null)
        closeGatt()
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try { gatt?.disconnect() } catch (_: Exception) { }
        try { gatt?.close() } catch (_: Exception) { }
        gatt = null
        subscribedCharacteristics.clear()
        rxDecoder.reset()
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    onConnectionState(false)
                    try { g.close() } catch (_: Exception) { }
                    if (gatt === g) gatt = null
                    val d = lastDevice
                    if (retries < 2 && d != null) {
                        retries++
                        onStatus("GATT error $status — retrying ($retries/2)…")
                        main.postDelayed({ if (gatt == null) openGatt(d) }, 800L)
                    } else {
                        onStatus("GATT error $status. If it is 133: unpair the buds in Android Bluetooth settings, put them in pairing mode and retry.")
                    }
                    return@post
                }
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        retries = 0
                        onConnectionState(true)
                        onStatus("Connected; discovering GATT services…")
                        try {
                            if (!g.discoverServices()) onStatus("GATT service discovery could not start")
                        } catch (_: SecurityException) { onStatus("Bluetooth permission denied") }
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        onConnectionState(false)
                        onServices(emptyList())
                        try { g.close() } catch (_: Exception) { }
                        if (gatt === g) gatt = null
                        onStatus("Disconnected from earbuds")
                    }
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                main.post { onStatus("GATT discovery failed: $status") }
                return
            }
            val inventory = g.services.map { service ->
                GattServiceInfo(service.uuid, service.characteristics.map { c -> GattCharacteristicInfo(c.uuid, c.properties) })
            }
            main.post {
                onServices(inventory)
                val notify = g.services.asSequence()
                    .flatMap { it.characteristics.asSequence() }
                    .firstOrNull {
                        it.uuid == HeyMelodyProtocol.defaultNotifyCharacteristicUuid &&
                            (it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0
                    }
                if (notify != null) enableNotifications(g, notify)
                else onStatus("Services discovered, but the HeyMelody notify characteristic is missing. These buds probably use Classic Bluetooth (RFCOMM) instead of BLE GATT for control.")
            }
        }

        @SuppressLint("MissingPermission")
        private fun enableNotifications(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            try {
                if (!g.setCharacteristicNotification(c, true)) { onStatus("Could not enable local GATT notifications"); return }
                val cccd = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                if (cccd == null) { onStatus("Notify characteristic has no CCCD descriptor"); return }
                val value = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 &&
                    (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) == 0)
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                val result = if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(cccd, value)
                } else {
                    @Suppress("DEPRECATION")
                    run { cccd.value = value; if (g.writeDescriptor(cccd)) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE }
                }
                if (result == BluetoothGatt.GATT_SUCCESS) {
                    subscribedCharacteristics.add(c.uuid)
                    onStatus("Notifications requested…")
                } else onStatus("Could not write notification descriptor (status $result)")
            } catch (e: SecurityException) {
                onStatus("Bluetooth permission denied while enabling notifications")
            } catch (e: RuntimeException) {
                onStatus("Notification setup failed: ${e.message ?: "unknown error"}")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            main.post { onStatus(if (status == BluetoothGatt.GATT_SUCCESS) "Notifications enabled; waiting for device data" else "Notification descriptor failed: $status") }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            main.post { onStatus(if (status == BluetoothGatt.GATT_SUCCESS) "Device acknowledged the write" else "Write failed (status $status)") }
        }

        @Deprecated("Deprecated by Android API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val value = characteristic.value?.copyOf() ?: return
            handleIncoming(characteristic.uuid, value)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleIncoming(characteristic.uuid, value.copyOf())
        }

        private fun handleIncoming(uuid: UUID, bytes: ByteArray) {
            val decoded = rxDecoder.append(bytes)
            val packetSummary = decoded.packets.joinToString(" | ") { p ->
                "cmd=0x${p.commandId.toString(16).uppercase().padStart(4, '0')} seq=${p.sequence} len=${p.declaredPayloadLength} payload=${HeyMelodyProtocol.toHex(p.payload)}"
            }
            val summary = buildString {
                append("RX [$uuid] ${bytes.size}B ${HeyMelodyProtocol.toHex(bytes)}")
                if (packetSummary.isNotEmpty()) append(" | $packetSummary")
                if (decoded.bufferedBytes > 0) append(" | buffered=${decoded.bufferedBytes}B")
                if (decoded.discardedBytes > 0) append(" | resync discarded=${decoded.discardedBytes}B")
            }
            main.post { onStatus(summary) }
        }
    }
}
