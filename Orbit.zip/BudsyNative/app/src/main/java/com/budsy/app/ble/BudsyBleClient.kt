package com.budsy.app.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.budsy.app.protocol.HeyMelodyProtocol
import java.util.UUID

/**
 * BLE foundation: scan (filtered or "show all"), bonded-device list, connect with
 * automatic retry on the common GATT 133 failure, service inventory, notifications.
 * Writes are only sent through [writeVerifiedPacket] with source-verified packets.
 */
class BudsyBleClient(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onDevice: (BluetoothDevice, String, Int) -> Unit,
    private val onServices: (List<GattServiceInfo>) -> Unit,
    private val onConnectionState: (Boolean) -> Unit = {}
) {
    data class GattServiceInfo(val uuid: UUID, val characteristics: List<GattCharacteristicInfo>)
    data class GattCharacteristicInfo(val uuid: UUID, val properties: Int)

    private val adapter: BluetoothAdapter? by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private val main = Handler(Looper.getMainLooper())
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private var gattReady = false
    private var pendingNotifyUuid: UUID? = null
    private var lastDevice: BluetoothDevice? = null
    private var retries = 0
    private val subscribedCharacteristics = mutableSetOf<UUID>()
    private val outerRxDecoder = com.budsy.app.protocol.OpoV1Wrapper.StreamDecoder()
    private val rxDecoder = HeyMelodyProtocol.StreamDecoder()
    private val writeQueue = ArrayDeque<ByteArray>()
    private var writeInFlight = false
    private var activeWriteUsesResponse = true
    private val scanTimeout = Runnable {
        if (scanning) { stopScan(); onStatus("Scan finished") }
    }

    fun hasRequiredPermissions(): Boolean {
        val required = if (Build.VERSION.SDK_INT >= 31) {
            listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return required.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    /** Already-paired devices. Earbuds connected to the phone stop advertising, so they only show up here. */
    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<Pair<BluetoothDevice, String>> {
        if (!hasRequiredPermissions()) return emptyList()
        return try {
            adapter?.bondedDevices.orEmpty().map { it to (it.name ?: it.address) }
        } catch (_: SecurityException) { emptyList() }
    }

    @SuppressLint("MissingPermission")
    fun startScan(showAll: Boolean = false) {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return }
        val a = adapter
        if (a == null) { onStatus("This device has no Bluetooth adapter"); return }
        if (!a.isEnabled) { onStatus("Turn on Bluetooth first"); return }
        val scanner = a.bluetoothLeScanner ?: run { onStatus("BLE scanner unavailable"); return }
        stopScan()
        try {
            // FIX: ScanSettings must never be null when filters are supplied.
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            val filters = if (showAll) null else HeyMelodyProtocol.scanFilters()
            scanner.startScan(filters, settings, scanCallback)
            scanning = true
            onStatus(if (showAll) "Scanning all BLE devices…" else "Scanning for HeyMelody-compatible earbuds…")
            main.removeCallbacks(scanTimeout)
            main.postDelayed(scanTimeout, 12_000L)
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied")
        } catch (e: RuntimeException) {
            onStatus("Could not start BLE scan: ${e.message ?: "unknown error"}")
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        main.removeCallbacks(scanTimeout)
        if (!scanning) return
        try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) { }
        scanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = try { d.name } catch (_: SecurityException) { null } ?: result.scanRecord?.deviceName ?: "Unknown BLE device"
            main.post { onDevice(d, name, result.rssi) }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            main.post { onStatus("BLE scan failed (code $errorCode)") }
        }
    }

    fun connect(device: BluetoothDevice) {
        retries = 0
        lastDevice = device
        gattReady = false
        onConnectionState(false)
        openGatt(device)
    }

    @SuppressLint("MissingPermission")
    private fun openGatt(device: BluetoothDevice) {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return }
        stopScan()
        closeGatt()
        gattReady = false
        onConnectionState(false)
        onStatus("Connecting…")
        try {
            gatt = if (Build.VERSION.SDK_INT >= 23)
                device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            else device.connectGatt(context, false, gattCallback)
        } catch (e: SecurityException) {
            onStatus("Bluetooth permission denied")
        } catch (e: RuntimeException) {
            onStatus("Could not connect: ${e.message ?: "unknown error"}")
        }
    }

    /** Wraps the inner HeyMelody command in OPOv1 frames and queues each BLE write serially. */
    @SuppressLint("MissingPermission")
    fun writeVerifiedPacket(packet: ByteArray, writeCharacteristicUuid: UUID = HeyMelodyProtocol.defaultWriteCharacteristicUuid): Boolean {
        if (!hasRequiredPermissions()) { onStatus("Bluetooth permission required"); return false }
        if (gatt == null) { onStatus("Not connected to a BLE device"); return false }
        if (!gattReady) { onStatus("BLE link exists, but HeyMelody GATT setup is not ready yet"); return false }
        val frames = try { com.budsy.app.protocol.OpoV1Wrapper.frame(packet) }
            catch (e: Exception) { onStatus("Could not frame HeyMelody packet: ${e.message}"); return false }
        if (frames.isEmpty()) return false
        main.post {
            frames.forEach { writeQueue.addLast(it) }
            onStatus("Queued ${frames.size} OPOv1 BLE frame(s); waiting for transport write completion…")
            pumpWriteQueue(writeCharacteristicUuid)
        }
        return true
    }

    @SuppressLint("MissingPermission")
    private fun pumpWriteQueue(writeCharacteristicUuid: UUID = HeyMelodyProtocol.defaultWriteCharacteristicUuid) {
        if (writeInFlight || writeQueue.isEmpty()) return
        val activeGatt = gatt ?: run { writeQueue.clear(); return }
        if (!gattReady || !hasRequiredPermissions()) return
        val characteristic = activeGatt.services.asSequence().flatMap { it.characteristics.asSequence() }
            .firstOrNull { it.uuid == writeCharacteristicUuid }
        if (characteristic == null) { writeQueue.clear(); onStatus("Write characteristic $writeCharacteristicUuid not found"); return }
        val props = characteristic.properties
        val supportsWrite = (props and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
        val supportsNoResponse = (props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        if (!supportsWrite && !supportsNoResponse) { writeQueue.clear(); onStatus("Write characteristic is not writable"); return }
        // HeyMelody's GattWriteCommand sets BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE (2).
        // Mirror that when available; fall back to acknowledged writes only on devices that require it.
        val useResponse = !supportsNoResponse && supportsWrite
        val bytes = writeQueue.first()
        try {
            val result = if (Build.VERSION.SDK_INT >= 33) {
                activeGatt.writeCharacteristic(characteristic, bytes,
                    if (useResponse) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
            } else {
                @Suppress("DEPRECATION")
                run {
                    characteristic.writeType = if (useResponse) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    characteristic.value = bytes
                    if (activeGatt.writeCharacteristic(characteristic)) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE
                }
            }
            if (result != BluetoothGatt.GATT_SUCCESS) {
                writeQueue.clear(); writeInFlight = false
                onStatus("OPOv1 GATT write request failed (status $result)")
                return
            }
            if (useResponse) {
                writeInFlight = true
                activeWriteUsesResponse = true
            } else {
                writeQueue.removeFirst()
                activeWriteUsesResponse = false
                main.postDelayed({ pumpWriteQueue(writeCharacteristicUuid) }, 35L)
            }
        } catch (e: SecurityException) {
            writeQueue.clear(); writeInFlight = false; onStatus("Bluetooth permission denied during write")
        } catch (e: RuntimeException) {
            writeQueue.clear(); writeInFlight = false; onStatus("BLE write failed: ${e.message ?: "unknown error"}")
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        retries = 99 // user-initiated: never auto-retry
        try { gatt?.disconnect() } catch (_: Exception) { }
    }

    fun close() {
        stopScan()
        main.removeCallbacksAndMessages(null)
        closeGatt()
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        try { gatt?.disconnect() } catch (_: Exception) { }
        try { gatt?.close() } catch (_: Exception) { }
        gatt = null
        gattReady = false
        pendingNotifyUuid = null
        subscribedCharacteristics.clear()
        writeQueue.clear()
        writeInFlight = false
        outerRxDecoder.reset()
        rxDecoder.reset()
        onConnectionState(false)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    onConnectionState(false)
                    try { g.close() } catch (_: Exception) { }
                    if (gatt === g) gatt = null
                    val d = lastDevice
                    if (retries < 2 && d != null) {
                        retries++
                        onStatus("GATT error $status — retrying ($retries/2)…")
                        main.postDelayed({ if (gatt == null) openGatt(d) }, 800L)
                    } else {
                        onStatus("GATT error $status. If it is 133: unpair the buds in Android Bluetooth settings, put them in pairing mode and retry.")
                    }
                    return@post
                }
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        retries = 0
                        gattReady = false
                        onConnectionState(false)
                        onStatus("BLE link established; discovering HeyMelody GATT services…")
                        try {
                            if (!g.discoverServices()) onStatus("GATT service discovery could not start")
                        } catch (_: SecurityException) { onStatus("Bluetooth permission denied") }
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        gattReady = false
                        pendingNotifyUuid = null
                        onConnectionState(false)
                        onServices(emptyList())
                        try { g.close() } catch (_: Exception) { }
                        if (gatt === g) gatt = null
                        onStatus("Disconnected from earbuds")
                    }
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                main.post { onStatus("GATT discovery failed: $status") }
                return
            }
            val inventory = g.services.map { service ->
                GattServiceInfo(service.uuid, service.characteristics.map { c -> GattCharacteristicInfo(c.uuid, c.properties) })
            }
            main.post {
                onServices(inventory)
                // HeyMelody's GattDevice can override its service UUID per supported product.
                // Therefore resolve the exact write/notify characteristic pair from discovered services
                // instead of requiring the default service UUID for every product.
                val service = g.services.firstOrNull { candidate ->
                    candidate.getCharacteristic(HeyMelodyProtocol.defaultWriteCharacteristicUuid) != null &&
                        candidate.getCharacteristic(HeyMelodyProtocol.defaultNotifyCharacteristicUuid) != null
                }
                if (service == null) {
                    gattReady = false
                    onConnectionState(false)
                    val found = inventory.joinToString("; ") { sv ->
                        "${sv.uuid}: ${sv.characteristics.joinToString { it.uuid.toString() }}"
                    }.ifBlank { "none" }
                    onStatus("HeyMelody write/notify characteristic pair not found. This device may use a product-specific UUID or a different transport. Discovered: $found")
                    return@post
                }
                val write = service.getCharacteristic(HeyMelodyProtocol.defaultWriteCharacteristicUuid)
                val writeOk = write != null && (write.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0
                if (!writeOk) {
                    gattReady = false
                    onConnectionState(false)
                    onStatus("HeyMelody write characteristic is missing or not writable")
                    return@post
                }
                val notify = service.getCharacteristic(HeyMelodyProtocol.defaultNotifyCharacteristicUuid)
                val notifyOk = notify != null && (notify.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0
                if (notify != null && notifyOk) enableNotifications(g, notify)
                else {
                    gattReady = false
                    onConnectionState(false)
                    onStatus("HeyMelody notification characteristic is missing or unsupported")
                }
            }
        }

        @SuppressLint("MissingPermission")
        private fun enableNotifications(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            try {
                if (!g.setCharacteristicNotification(c, true)) { onStatus("Could not enable local GATT notifications"); return }
                val cccd = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                if (cccd == null) { onStatus("Notify characteristic has no CCCD descriptor"); return }
                val value = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 &&
                    (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) == 0)
                    BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                pendingNotifyUuid = c.uuid
                val result = if (Build.VERSION.SDK_INT >= 33) {
                    g.writeDescriptor(cccd, value)
                } else {
                    @Suppress("DEPRECATION")
                    run { cccd.value = value; if (g.writeDescriptor(cccd)) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE }
                }
                if (result == BluetoothGatt.GATT_SUCCESS) {
                    onStatus("Notification subscription requested; waiting for descriptor confirmation…")
                } else {
                    pendingNotifyUuid = null
                    gattReady = false
                    onConnectionState(false)
                    onStatus("Could not write notification descriptor (status $result)")
                }
            } catch (e: SecurityException) {
                onStatus("Bluetooth permission denied while enabling notifications")
            } catch (e: RuntimeException) {
                onStatus("Notification setup failed: ${e.message ?: "unknown error"}")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            main.post {
                val expected = pendingNotifyUuid
                val confirmed = status == BluetoothGatt.GATT_SUCCESS &&
                    descriptor.uuid == UUID.fromString("00002902-0000-1000-8000-00805f9b34fb") &&
                    expected != null && descriptor.characteristic.uuid == expected && g === gatt
                if (confirmed) {
                    subscribedCharacteristics.add(expected!!)
                    gattReady = true
                    onConnectionState(true)
                    onStatus("HeyMelody GATT ready: write characteristic verified and notifications enabled")
                } else {
                    gattReady = false
                    onConnectionState(false)
                    onStatus("Notification subscription failed or did not match expected characteristic (status $status)")
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            main.post {
                if (g !== gatt || !activeWriteUsesResponse) return@post
                if (writeQueue.isNotEmpty()) writeQueue.removeFirst()
                writeInFlight = false
                onStatus(if (status == BluetoothGatt.GATT_SUCCESS) "OPOv1 frame write completed; device command acknowledgement is still separate" else "GATT frame write failed (status $status)")
                if (status == BluetoothGatt.GATT_SUCCESS) pumpWriteQueue()
                else writeQueue.clear()
            }
        }

        @Deprecated("Deprecated by Android API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val value = characteristic.value?.copyOf() ?: return
            handleIncoming(characteristic.uuid, value)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleIncoming(characteristic.uuid, value.copyOf())
        }

        private fun handleIncoming(uuid: UUID, bytes: ByteArray) {
            val outer = outerRxDecoder.append(bytes)
            val summaries = mutableListOf<String>()
            outer.packets.forEach { innerBytes ->
                val decoded = rxDecoder.append(innerBytes)
                decoded.packets.forEach { p ->
                    summaries += "cmd=0x${p.commandId.toString(16).uppercase().padStart(4, '0')} seq=${p.sequence} len=${p.declaredPayloadLength} payload=${HeyMelodyProtocol.toHex(p.payload)}"
                }
                if (decoded.bufferedBytes > 0) summaries += "inner-buffered=${decoded.bufferedBytes}B"
            }
            val summary = buildString {
                append("RX [$uuid] ${bytes.size}B ${HeyMelodyProtocol.toHex(bytes)}")
                if (summaries.isNotEmpty()) append(" | ").append(summaries.joinToString(" | "))
                if (outer.bufferedBytes > 0) append(" | outer-buffered=${outer.bufferedBytes}B")
                if (outer.discardedBytes > 0) append(" | outer-resync-discarded=${outer.discardedBytes}B")
            }
            main.post { onStatus(summary) }
        }
    }
}
