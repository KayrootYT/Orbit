package com.budsy.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Stock-style flat background; no animated gradients, particles, or parallax. */
@Composable
fun AnimatedBackground(style: BgStyle, modifier: Modifier = Modifier) {
    val palette = LocalPalette.current
    Canvas(modifier.fillMaxSize()) { drawRect(palette.bgBottom) }
}
