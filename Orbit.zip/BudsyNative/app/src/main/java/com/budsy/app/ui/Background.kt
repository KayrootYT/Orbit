package com.budsy.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Particle(val x: Float, val y: Float, val k: Int, val depth: Float)

/** Full-screen animated background. Layers shift with phone tilt for a parallax / 3D depth feel. */
@Composable
fun AnimatedBackground(style: BgStyle, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tilt = LocalTilt.current
    val inf = rememberInfiniteTransition(label = "bg")
    val phase = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "phase")
    val pulse = inf.animateFloat(0.85f, 1.15f, infiniteRepeatable(tween(5000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val dots = remember { List(64) { Particle(Random.nextFloat(), Random.nextFloat(), 1 + it % 3, 0.4f + Random.nextFloat() * 1.6f) } }

    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val a = phase.value * 2f * PI.toFloat()
        val tx = tilt.value.x
        val ty = tilt.value.y
        drawRect(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
        val blobAlpha = if (p.dark) 0.5f else 0.55f

        fun blob(c: Color, cx: Float, cy: Float, r: Float, depth: Float) {
            val ctr = Offset(cx + tx * depth * 70f, cy + ty * depth * 70f)
            drawCircle(
                brush = Brush.radialGradient(listOf(c.copy(alpha = blobAlpha), Color.Transparent), center = ctr, radius = r),
                radius = r, center = ctr
            )
        }

        when (style) {
            BgStyle.AURORA -> {
                blob(p.blobA, w * (0.25f + 0.2f * sin(a)), h * (0.2f + 0.1f * cos(a)), w * 0.9f * pulse.value, 1f)
                blob(p.blobB, w * (0.8f + 0.15f * cos(a)), h * (0.45f + 0.12f * sin(a)), w * 0.85f, 1.6f)
                blob(p.blobC, w * (0.4f + 0.25f * sin(a + 2f)), h * (0.85f + 0.08f * cos(a + 1f)), w * 1.0f, 0.7f)
            }
            BgStyle.PARTICLES -> {
                blob(p.blobA, w * 0.2f, h * 0.15f, w * 0.8f, 1f)
                blob(p.blobB, w * 0.9f, h * 0.7f, w * 0.9f, 1.5f)
                dots.forEach { d ->
                    val y = (1f - ((d.y + phase.value * d.k) % 1f)) * h
                    val x = d.x * w + sin(a * d.k + d.x * 6f) * 18f + tx * d.depth * 40f
                    val r = 1.5f + d.depth * 2.5f
                    drawCircle(p.accent.copy(alpha = 0.25f + 0.1f * d.depth), r, Offset(x, y))
                    if (d.depth > 1.2f) drawCircle(p.accent2.copy(alpha = 0.10f), r * 4f, Offset(x, y))
                }
            }
            BgStyle.WAVES -> {
                blob(p.blobA, w * 0.8f, h * 0.1f, w * 0.9f, 1f)
                val cols = listOf(p.blobA, p.blobB, p.blobC, p.accent)
                for (i in 0 until 4) {
                    val base = h * (0.55f + i * 0.1f) + ty * (i + 1) * 14f
                    val dir = if (i % 2 == 0) 1 else -1
                    val path = Path().apply {
                        moveTo(0f, h)
                        var x = 0f
                        while (x <= w + 12f) {
                            lineTo(x, base + sin(x / w * 2f * PI.toFloat() * (1 + i % 2) + a * (i + 1) * dir) * (26f + i * 8f))
                            x += 12f
                        }
                        lineTo(w, h)
                        close()
                    }
                    drawPath(path, cols[i].copy(alpha = 0.18f + i * 0.04f))
                }
            }
            BgStyle.GRID -> {
                val hor = h * 0.5f
                blob(p.blobB, w * 0.5f + tx * 30f, hor, w * 0.9f, 0.5f)
                drawCircle(
                    Brush.verticalGradient(listOf(p.accent2.copy(alpha = 0.9f), p.accent.copy(alpha = 0f)), startY = hor - w * 0.3f, endY = hor),
                    w * 0.22f, Offset(w * 0.5f + tx * 20f, hor - w * 0.05f)
                )
                val vx = w * 0.5f + tx * 50f
                for (j in -9..9) {
                    drawLine(p.accent.copy(alpha = 0.28f), Offset(vx + j * 8f, hor), Offset(w * 0.5f + j * w * 0.16f, h), 2f)
                }
                for (i in 0 until 14) {
                    val z = ((i + phase.value) % 14f) / 14f
                    val y = hor + (h - hor) * z * z
                    drawLine(p.accent.copy(alpha = 0.12f + 0.3f * z), Offset(0f, y), Offset(w, y), 1.5f + 2f * z)
                }
            }
        }
    }
}
