package com.budsy.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Press-to-tilt 3D effect + subtle sensor parallax. Observes pointers without consuming them. */
@Composable
fun Modifier.tilt3D(max: Float = 6f): Modifier {
    if (!LocalMotion.current) return this
    val tilt = LocalTilt.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    var target by remember { mutableStateOf(Offset.Zero) }
    val rx by animateFloatAsState(target.y, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow), label = "rx")
    val ry by animateFloatAsState(target.x, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow), label = "ry")
    return this
        .onSizeChanged { size = it }
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val c = awaitPointerEvent(PointerEventPass.Initial).changes.firstOrNull() ?: continue
                    target = if (c.pressed && size.width > 0 && size.height > 0) {
                        val nx = (c.position.x / size.width - 0.5f) * 2f
                        val ny = (c.position.y / size.height - 0.5f) * 2f
                        Offset(-nx * max, ny * max)
                    } else Offset.Zero
                }
            }
        }
        .graphicsLayer {
            rotationX = rx + tilt.value.y * 2.5f
            rotationY = ry + tilt.value.x * 2.5f
            cameraDistance = 16f * density
        }
}

/** Staggered 3D entrance (rise + flip-in). */
@Composable
fun Modifier.enterAnim(index: Int): Modifier {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        prog.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow))
    }
    return this.graphicsLayer {
        val v = prog.value
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * 80f
        rotationX = (1f - v) * 25f
        scaleX = 0.94f + 0.06f * v
        scaleY = 0.94f + 0.06f * v
        cameraDistance = 14f * density
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 26.dp,
    tilt: Boolean = true,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(corner)
    val base = if (tilt) modifier.tilt3D() else modifier
    Column(
        base
            .clip(shape)
            .background(p.glass)
            .border(1.dp, p.glassEdge, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        content = content
    )
}

@Composable
fun Section(title: String, modifier: Modifier = Modifier, tilt: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Column(modifier.fillMaxWidth()) {
        Text(title.uppercase(), color = p.muted, fontSize = 12.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 10.dp, bottom = 8.dp))
        GlassCard(Modifier.fillMaxWidth(), tilt = tilt) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), content = content)
        }
    }
}

@Composable
fun IconChip(icon: BIcon, size: Dp = 38.dp) {
    val p = LocalPalette.current
    val look = LocalChipLook.current
    val shape = RoundedCornerShape(12.dp)
    val mod = Modifier.background(p.accent, shape)
    val tint = p.onAccent
    Box(Modifier.size(size).clip(shape).then(mod), contentAlignment = Alignment.Center) {
        BudsyIcon(icon, Modifier.size(size * 0.55f), tint)
    }
}

@Composable
fun SettingRow(
    title: String, summary: String? = null, icon: BIcon? = null,
    onClick: (() -> Unit)? = null, trailing: (@Composable () -> Unit)? = null
) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick) else Modifier)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { IconChip(icon); Spacer(Modifier.width(12.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (summary != null) Text(summary, color = p.muted, fontSize = 13.sp)
        }
        if (trailing != null) trailing() else if (onClick != null) BudsyIcon(BIcon.CHEVRON, tint = p.muted)
    }
}

@Composable
fun BSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    val x by animateDpAsState(if (checked) 22.dp else 0.dp, spring(dampingRatio = 0.6f), label = "sw")
    val track: Brush = if (checked) Brush.horizontalGradient(listOf(p.accent, p.accent2)) else SolidColor(p.muted.copy(alpha = 0.3f))
    Box(Modifier.size(52.dp, 30.dp).clip(CircleShape).background(track).clickable { onChange(!checked) }.padding(3.dp)) {
        Box(Modifier.offset(x = x).size(24.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun RadioDot(selected: Boolean) {
    val p = LocalPalette.current
    val s by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.5f), label = "dot")
    Box(Modifier.size(24.dp).border(2.dp, if (selected) p.accent else p.muted, CircleShape), contentAlignment = Alignment.Center) {
        Box(Modifier.size(12.dp).graphicsLayer { scaleX = s; scaleY = s }.clip(CircleShape).background(Brush.linearGradient(listOf(p.accent, p.accent2))))
    }
}

@Composable
fun BSlider(value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float> = 0f..1f, steps: Int = 0) {
    val p = LocalPalette.current
    Slider(
        value = value, onValueChange = onChange, valueRange = range, steps = steps,
        colors = SliderDefaults.colors(
            thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.muted.copy(alpha = 0.25f),
            activeTickColor = Color.Transparent, inactiveTickColor = Color.Transparent
        )
    )
}

@Composable
fun PillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: BIcon? = null, enabled: Boolean = true, filled: Boolean = true) {
    val p = LocalPalette.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.5f), label = "btn")
    val shape = RoundedCornerShape(22.dp)
    val bg: Brush = if (filled) Brush.horizontalGradient(listOf(p.accent, p.accent2)) else SolidColor(p.glass)
    val fg = if (filled) p.onAccent else p.text
    Row(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (enabled) 1f else 0.45f }
            .clip(shape).background(bg).border(1.dp, if (filled) Color.Transparent else p.glassEdge, shape)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(vertical = 15.dp, horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { BudsyIcon(icon, Modifier.size(20.dp), fg); Spacer(Modifier.width(8.dp)) }
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun SelectChip(label: String, selected: Boolean, onClick: () -> Unit, leading: (@Composable () -> Unit)? = null) {
    val p = LocalPalette.current
    val sc by animateFloatAsState(if (selected) 1.05f else 1f, spring(dampingRatio = 0.5f), label = "chip")
    val shape = RoundedCornerShape(18.dp)
    val bg: Brush = if (selected) Brush.linearGradient(listOf(p.accent, p.accent2)) else SolidColor(p.glass)
    Row(
        Modifier.graphicsLayer { scaleX = sc; scaleY = sc }.clip(shape).background(bg)
            .border(1.dp, if (selected) Color.Transparent else p.glassEdge, shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) { leading(); Spacer(Modifier.width(8.dp)) }
        Text(label, color = if (selected) p.onAccent else p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BatteryRing(label: String, level: Int?) {
    val p = LocalPalette.current
    val prog by animateFloatAsState((level ?: 0) / 100f, tween(900), label = "bat")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(70.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = Stroke(8.dp.toPx(), cap = StrokeCap.Round)
                val inset = 6.dp.toPx()
                val sz = Size(size.width - inset * 2, size.height - inset * 2)
                drawArc(p.muted.copy(alpha = 0.25f), 135f, 270f, false, Offset(inset, inset), sz, style = stroke)
                if (level != null) drawArc(Brush.linearGradient(listOf(p.accent, p.accent2)), 135f, 270f * prog, false, Offset(inset, inset), sz, style = stroke)
            }
            Text(level?.let { "$it%" } ?: "—", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Text(label, color = p.muted, fontSize = 12.sp)
    }
}

@Composable
fun FloatingNav(items: List<Pair<BIcon, String>>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    GlassCard(modifier, corner = 32.dp, tilt = false) {
        Row(Modifier.padding(6.dp)) {
            items.forEachIndexed { i, (icon, label) ->
                val sel = i == selected
                val scale by animateFloatAsState(if (sel) 1.18f else 1f, spring(dampingRatio = 0.45f), label = "navScale")
                val spin by animateFloatAsState(if (sel) 360f else 0f, tween(550, easing = FastOutSlowInEasing), label = "navSpin")
                val bg: Brush = if (sel) Brush.linearGradient(listOf(p.accent, p.accent2)) else SolidColor(Color.Transparent)
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(bg)
                        .clickable { onSelect(i) }.padding(vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    BudsyIcon(icon, Modifier.size(22.dp).graphicsLayer { scaleX = scale; scaleY = scale; rotationY = spin; cameraDistance = 12f * density },
                        if (sel) p.onAccent else p.muted)
                    Text(label, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = if (sel) p.onAccent else p.muted)
                }
            }
        }
    }
}
