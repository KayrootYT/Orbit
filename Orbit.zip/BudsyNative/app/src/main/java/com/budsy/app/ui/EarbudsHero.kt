package com.budsy.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private val BodyHi = Color(0xFFF3F5FF)
private val BodyLo = Color(0xFF7C86A8)

/** Draggable 3D earbuds + case. Each part is its own layer with a different depth, so tilt/drag gives real parallax. */
@Composable
fun EarbudsHero(connected: Boolean, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val tilt = LocalTilt.current
    val motion = LocalMotion.current
    val inf = rememberInfiniteTransition(label = "hero")
    val idle = inf.animateFloat(-18f, 18f, infiniteRepeatable(tween(5200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "idle")
    val bob = inf.animateFloat(-8f, 8f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val pulse = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "pulse")
    val yaw = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val release = { scope.launch { yaw.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessLow)) }; Unit }

    fun layer(depth: Float, yawMul: Float) = Modifier.graphicsLayer {
        val t = tilt.value
        rotationY = (if (motion) idle.value else 0f).plus(yaw.value) * yawMul
        rotationX = -t.y * 8f * depth
        translationX = t.x * 18f * depth * density
        translationY = (if (motion) bob.value else 0f) * depth * density
        cameraDistance = 18f * density
    }

    Box(
        modifier.fillMaxWidth().height(250.dp).pointerInput(Unit) {
            detectHorizontalDragGestures(
                onDragEnd = { release() }, onDragCancel = { release() },
                onHorizontalDrag = { change, dx -> change.consume(); scope.launch { yaw.snapTo(yaw.value + dx * 0.5f) } }
            )
        },
        contentAlignment = Alignment.Center
    ) {
        // glow + connection ripples
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val glow = if (connected) p.accent else p.muted
            drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.35f), Color.Transparent), center = c, radius = size.width * 0.55f), size.width * 0.55f, c)
            if (connected) for (k in 0..2) {
                val f = (pulse.value + k / 3f) % 1f
                drawCircle(p.accent.copy(alpha = (1f - f) * 0.35f), size.width * (0.2f + 0.35f * f), c, style = Stroke(2.5f))
            }
        }
        Canvas(Modifier.align(Alignment.Center).size(130.dp, 120.dp).then(layer(0.6f, 0.8f))) { drawCase(p, connected, pulse.value) }
        Canvas(Modifier.align(Alignment.CenterStart).size(92.dp, 170.dp).then(layer(1.3f, 1.2f))) { drawBud(p, false, connected, pulse.value) }
        Canvas(Modifier.align(Alignment.CenterEnd).size(92.dp, 170.dp).then(layer(1.3f, 1.2f))) { drawBud(p, true, connected, pulse.value) }
    }
}

private fun DrawScope.drawBud(p: Palette, mirror: Boolean, connected: Boolean, pulse: Float) {
    val w = size.width
    val h = size.height
    val dir = if (mirror) -1f else 1f
    val hi = BodyHi
    val lo = lerp(BodyLo, p.accent, 0.25f)
    val headC = Offset(w * 0.5f, h * 0.30f)
    val headR = w * 0.36f
    drawOval(Color.Black.copy(alpha = 0.22f), Offset(w * 0.2f, h * 0.93f), Size(w * 0.6f, h * 0.05f))
    rotate(14f * dir, headC) {
        drawRoundRect(
            Brush.verticalGradient(listOf(hi, lo), startY = headC.y, endY = h),
            Offset(w * 0.4f, headC.y), Size(w * 0.2f, h * 0.62f), CornerRadius(w * 0.1f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color.White, hi, lo), center = Offset(headC.x - headR * 0.35f, headC.y - headR * 0.4f), radius = headR * 1.7f),
            headR, headC
        )
        val glow = if (connected) 0.5f + 0.5f * pulse else 0.3f
        drawCircle(p.accent.copy(alpha = glow), headR * 0.62f, headC, style = Stroke(3f))
        drawCircle(p.accent2.copy(alpha = 0.8f), headR * 0.12f, Offset(headC.x, headC.y + headR * 0.25f))
        drawRoundRect(Color.White.copy(alpha = 0.35f), Offset(w * 0.43f, headC.y + headR * 1.2f), Size(w * 0.04f, h * 0.3f), CornerRadius(8f))
    }
}

private fun DrawScope.drawCase(p: Palette, connected: Boolean, pulse: Float) {
    val w = size.width
    val h = size.height
    val lo = lerp(BodyLo, p.accent2, 0.2f)
    drawRoundRect(
        Brush.linearGradient(listOf(BodyHi, lo), Offset(0f, 0f), Offset(w, h)),
        Offset(w * 0.08f, h * 0.18f), Size(w * 0.84f, h * 0.7f), CornerRadius(w * 0.28f)
    )
    drawLine(Color.Black.copy(alpha = 0.18f), Offset(w * 0.1f, h * 0.45f), Offset(w * 0.9f, h * 0.45f), 3f)
    drawRoundRect(Color.White.copy(alpha = 0.3f), Offset(w * 0.16f, h * 0.22f), Size(w * 0.3f, h * 0.07f), CornerRadius(20f))
    val led = Offset(w * 0.5f, h * 0.66f)
    val c = if (connected) p.accent else p.muted
    drawCircle(c.copy(alpha = 0.25f * pulse), 16f + pulse * 10f, led)
    drawCircle(c, 6f, led)
}
