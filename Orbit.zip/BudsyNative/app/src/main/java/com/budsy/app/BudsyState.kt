package com.budsy.app

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import androidx.compose.runtime.*
import com.budsy.app.ble.BudsyBleClient
import com.budsy.app.ble.BudsyRfcommClient
import com.budsy.app.protocol.DeviceCommandGateway
import com.budsy.app.protocol.HeyMelodyProtocol
import com.budsy.app.ui.*

enum class Page(val label: String, val icon: BIcon) {
    DEVICE("Device", BIcon.HEADPHONES), CONTROLS("Controls", BIcon.TOUCH), EQ("Sound", BIcon.EQ),
    THEME("Appearance", BIcon.PALETTE), ABOUT("About", BIcon.INFO), FIND("Find", BIcon.FIND), TUTORIAL("Guide", BIcon.INFO)
}

data class ScanItem(val device: BluetoothDevice, val name: String, val rssi: Int)

const val MODEL = "OnePlus Nord Buds 3"
val BAND_NAMES = listOf("60 Hz", "150 Hz", "400 Hz", "1 kHz", "2.4 kHz", "6 kHz", "12 kHz")
/** Illustrative local presets (not read from the earbuds). */
val RECOMMENDED = linkedMapOf(
    "Balanced (Default)" to List(7) { 0f },
    "Clear Vocals" to listOf(-2f, -1f, 0f, 2f, 3f, 1f, 0f),
    "Bass" to listOf(5f, 4f, 2f, 0f, 0f, 0f, 0f),
)

fun gKey(side: String, call: Boolean, g: String) = "$side|${if (call) "call" else "std"}|$g"
fun defaultGesture(call: Boolean, g: String) = if (call) when (g) {
    "Double-tap" -> "Answer/End call"; else -> "Decline call"
} else when (g) {
    "Single-tap" -> "None"; "Double-tap" -> "Previous"; "Triple-tap" -> "Voice Assistant"
    "Touch and hold" -> "Off"; else -> "Volume down"
}
fun gestureOptions(g: String, call: Boolean): List<String> = if (call) when (g) {
    "Double-tap" -> listOf("Answer/End call", "None"); else -> listOf("Decline call", "None")
} else when (g) {
    "Single-tap" -> listOf("None", "Play/Pause")
    "Double-tap" -> listOf("None", "Play/Pause", "Previous", "Next track", "Voice Assistant", "Game mode")
    "Triple-tap" -> listOf("None", "Previous", "Next track", "Voice Assistant", "Game mode")
    "Touch and hold" -> listOf("Off", "Noise cancellation", "Transparency")
    else -> listOf("None", "Volume up", "Volume down")
}

private inline fun <reified T : Enum<T>> loadEnum(s: String?, def: T): T = runCatching { enumValueOf<T>(s ?: "") }.getOrDefault(def)

@Stable
class BudsyState(context: Context) {
    private val prefs = context.getSharedPreferences("budsy_prefs", Context.MODE_PRIVATE)

    // appearance (persisted)
    var themeMode by mutableStateOf(loadEnum(prefs.getString("theme", null), ThemeMode.DARK))
    var iconStyle by mutableStateOf(IconStyle.ROUNDED)
    var chipLook by mutableStateOf(ChipLook.SOLID)
    var bgStyle by mutableStateOf(BgStyle.SOLID)
    var motion by mutableStateOf(false)
    fun persist() {
        prefs.edit().putString("theme", themeMode.name).apply()
    }

    // navigation / connection
    var page by mutableStateOf(Page.DEVICE)
    var connected by mutableStateOf(false)
    var notice by mutableStateOf("Bluetooth not connected")
    var scanResults by mutableStateOf(listOf<ScanItem>())
    var paired by mutableStateOf(listOf<ScanItem>())
    var showAll by mutableStateOf(false)
    var gatt by mutableStateOf("GATT services not discovered")

    // device settings (local UI state unless noted)
    var mode by mutableStateOf("Off")
    var gameMode by mutableStateOf(false)
    var dualConnection by mutableStateOf(false)
    var side by mutableStateOf("Left")
    var gestures by mutableStateOf(mapOf<String, String>())
    var editingGesture by mutableStateOf<Pair<String, Boolean>?>(null)
    fun gesture(call: Boolean, g: String) = gestures[gKey(side, call, g)] ?: defaultGesture(call, g)
    fun setGesture(call: Boolean, g: String, v: String) { gestures = gestures + (gKey(side, call, g) to v) }

    // EQ
    var preset by mutableStateOf("Balanced (Default)")
    var bands by mutableStateOf(List(7) { 0f })
    var bassWave by mutableStateOf(false)
    var bassLevel by mutableFloatStateOf(0.45f)
    var customPresets by mutableStateOf(mapOf("My Custom EQ" to listOf(2f, 1f, 0f, 0f, 1f, 2f, 1f)))
    var presetEditor by mutableStateOf<String?>(null) // null = closed, "" = new, otherwise original name
    var editorName by mutableStateOf("")
    fun selectPreset(name: String) { preset = name; (RECOMMENDED[name] ?: customPresets[name])?.let { bands = it } }

    // find / firmware
    var findOn by mutableStateOf(false)
    var findStatus by mutableStateOf("Ready")
    var firmwareDialog by mutableStateOf(false)

    val ble = BudsyBleClient(
        context = context.applicationContext,
        onStatus = { notice = it },
        onConnectionState = { connected = it },
        onDevice = { d, name, rssi ->
            scanResults = (scanResults.filterNot { it.device.address == d.address } + ScanItem(d, name, rssi)).sortedByDescending { it.rssi }
        },
        onServices = { services ->
            gatt = if (services.isEmpty()) "GATT services not discovered" else services.joinToString("\n") { sv ->
                "${sv.uuid} (${sv.characteristics.size})" + sv.characteristics.joinToString("") { "\n  ${it.uuid} [${propertyLabels(it.properties)}]" }
            }
        }
    )

    // RFCOMM is the preferred control transport. BLE remains available for discovery/debug only.
    val rfcomm = BudsyRfcommClient(
        context = context.applicationContext,
        onStatus = { notice = it },
        onConnectionState = { connected = it },
        onPacket = { packet ->
            val decoded = HeyMelodyProtocol.decodePacket(packet)
            if (decoded != null) notice = "RFCOMM response 0x${decoded.commandId.toString(16).uppercase()} (${decoded.payload.size} payload bytes)"
        }
    )
    private var customEqSequence = 0
    private val gateway = DeviceCommandGateway { rfcomm.writePacket(it) }
    init {
        // Find-mode (cmd 0x0400, payload 1/0) is the one command verified in the supplied source.
        gateway.registerVerifiedCommand(
            MODEL, DeviceCommandGateway.Feature.FIND_MY_BUDS,
            DeviceCommandGateway.FeatureCommand(HeyMelodyProtocol.FIND_MODE_COMMAND, { byteArrayOf(if (findOn) 1 else 0) }, setOf(MODEL), false)
        )
    }

    fun refreshPaired() { paired = ble.bondedDevices().map { ScanItem(it.first, it.second, 0) } }

    fun connectRfcomm(device: BluetoothDevice) { rfcomm.connect(device) }
    fun disconnectControl() { rfcomm.disconnect(); ble.disconnect() }

    /** Sends the source-derived HeyMelody custom EQ command (0x0418) over RFCOMM.
     * Device-specific EqInfo values must be read/verified before calling this method.
     */
    fun sendCustomEq(mode: Int, minValue: Int, maxValue: Int, eqId: Int, name: String?, frequencies: IntArray, dbValues: IntArray): String {
        if (!connected) return "Connect over RFCOMM first."
        return try {
            val sequence = customEqSequence
            val packet = HeyMelodyProtocol.encodeCustomEqPacket(sequence, mode, minValue, maxValue, eqId, name, frequencies, dbValues)
            customEqSequence = (customEqSequence + 1) and 0xFF
            if (rfcomm.writePacket(packet)) "Custom EQ 0x0418 queued over RFCOMM; verify the device response." else "RFCOMM write was not queued."
        } catch (e: Exception) { "Custom EQ payload rejected: ${e.message ?: "invalid EqInfo"}" }
    }

    fun sendFind(on: Boolean) {
        if (!connected) { findStatus = "Connect to the earbuds first (Device tab)."; return }
        findOn = on
        findStatus = when (val r = gateway.execute(MODEL, DeviceCommandGateway.Feature.FIND_MY_BUDS)) {
            is DeviceCommandGateway.Result.Sent -> "Find packet sent (0x0400, ${if (on) "start" else "stop"}). Not yet confirmed on real hardware."
            is DeviceCommandGateway.Result.Unsupported -> r.reason
            is DeviceCommandGateway.Result.Failed -> r.reason
        }
    }
}

fun propertyLabels(p: Int): String = buildList {
    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) add("READ")
    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) add("WRITE")
    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) add("WRITE_NR")
    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) add("NOTIFY")
    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) add("INDICATE")
}.joinToString()
