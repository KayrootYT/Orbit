package com.budsy.app

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import com.budsy.app.ble.BudsyBleClient
import com.budsy.app.ble.BudsyRfcommClient
import com.budsy.app.protocol.NordBudsProtocol
import com.budsy.app.ui.*

enum class Page(val label: String, val icon: BIcon) {
    DEVICE("Device", BIcon.HEADPHONES), CONTROLS("Controls", BIcon.TOUCH), EQ("Sound", BIcon.EQ),
    THEME("Appearance", BIcon.PALETTE), ABOUT("About", BIcon.INFO), FIND("Find", BIcon.FIND), TUTORIAL("Guide", BIcon.INFO)
}

data class ScanItem(val device: BluetoothDevice, val name: String, val rssi: Int)

const val MODEL = "OnePlus Nord Buds 3"
val BAND_NAMES = listOf("60 Hz", "150 Hz", "400 Hz", "1 kHz", "2.4 kHz", "6 kHz", "12 kHz")
/** Illustrative local presets (not read from the earbuds). */
val RECOMMENDED = linkedMapOf(
    "Balanced (Default)" to List(7) { 0f },
    "Clear Vocals" to listOf(-2f, -1f, 0f, 2f, 3f, 1f, 0f),
    "Bass" to listOf(5f, 4f, 2f, 0f, 0f, 0f, 0f),
)

fun gKey(side: String, call: Boolean, g: String) = "$side|${if (call) "call" else "std"}|$g"
fun defaultGesture(call: Boolean, g: String) = if (call) when (g) {
    "Double-tap" -> "Answer/End call"; else -> "Decline call"
} else when (g) {
    "Single-tap" -> "None"; "Double-tap" -> "Previous"; "Triple-tap" -> "Voice Assistant"
    "Touch and hold" -> "Off"; else -> "Volume down"
}
fun gestureOptions(g: String, call: Boolean): List<String> = if (call) when (g) {
    "Double-tap" -> listOf("Answer/End call", "None"); else -> listOf("Decline call", "None")
} else when (g) {
    "Single-tap" -> listOf("None", "Play/Pause")
    "Double-tap" -> listOf("None", "Play/Pause", "Previous", "Next track", "Voice Assistant", "Game mode")
    "Triple-tap" -> listOf("None", "Previous", "Next track", "Voice Assistant", "Game mode")
    "Touch and hold" -> listOf("Off", "Noise cancellation", "Transparency")
    else -> listOf("None", "Volume up", "Volume down")
}

private inline fun <reified T : Enum<T>> loadEnum(s: String?, def: T): T = runCatching { enumValueOf<T>(s ?: "") }.getOrDefault(def)

@Stable
class BudsyState(context: Context) {
    private val prefs = context.getSharedPreferences("budsy_prefs", Context.MODE_PRIVATE)

    // appearance (persisted)
    var themeMode by mutableStateOf(loadEnum(prefs.getString("theme", null), ThemeMode.DARK))
    var iconStyle by mutableStateOf(IconStyle.ROUNDED)
    var chipLook by mutableStateOf(ChipLook.SOLID)
    var bgStyle by mutableStateOf(BgStyle.SOLID)
    var motion by mutableStateOf(false)
    fun persist() {
        prefs.edit().putString("theme", themeMode.name).apply()
    }

    // navigation / connection
    var page by mutableStateOf(Page.DEVICE)
    var connected by mutableStateOf(false) // RFCOMM socket state, not proof of protocol response
    var bleConnected by mutableStateOf(false)
    var deviceResponded by mutableStateOf(false)
    var notice by mutableStateOf("Bluetooth not connected")
    var scanResults by mutableStateOf(listOf<ScanItem>())
    var paired by mutableStateOf(listOf<ScanItem>())
    var showAll by mutableStateOf(false)
    var gatt by mutableStateOf("GATT services not discovered")
    var leftBattery by mutableIntStateOf(-1)
    var rightBattery by mutableIntStateOf(-1)
    var caseBattery by mutableIntStateOf(-1)
    var leftCharging by mutableStateOf(false)
    var rightCharging by mutableStateOf(false)
    var caseCharging by mutableStateOf(false)
    private var rfcommSequence = 0x20
    private val batteryRefreshHandler = Handler(Looper.getMainLooper())
    private val batteryRefreshTask = object : Runnable {
        override fun run() {
            if (connected) {
                requestBattery()
                batteryRefreshHandler.postDelayed(this, 10_000L)
            }
        }
    }

    // device settings (local UI state unless noted)
    var mode by mutableStateOf("Off")
    var gameMode by mutableStateOf(false)
    var dualConnection by mutableStateOf(false)
    var side by mutableStateOf("Left")
    var gestures by mutableStateOf(mapOf<String, String>())
    var editingGesture by mutableStateOf<Pair<String, Boolean>?>(null)
    fun gesture(call: Boolean, g: String) = gestures[gKey(side, call, g)] ?: defaultGesture(call, g)
    fun setGesture(call: Boolean, g: String, v: String) { gestures = gestures + (gKey(side, call, g) to v) }

    // EQ
    var preset by mutableStateOf("Balanced (Default)")
    var bands by mutableStateOf(List(7) { 0f })
    var bassWave by mutableStateOf(false)
    var bassLevel by mutableFloatStateOf(0.45f)
    var customPresets by mutableStateOf(mapOf("My Custom EQ" to listOf(2f, 1f, 0f, 0f, 1f, 2f, 1f)))
    var presetEditor by mutableStateOf<String?>(null) // null = closed, "" = new, otherwise original name
    var editorName by mutableStateOf("")
    fun selectPreset(name: String) { preset = name; (RECOMMENDED[name] ?: customPresets[name])?.let { bands = it } }

    // find / firmware
    var findOn by mutableStateOf(false)
    var findStatus by mutableStateOf("Ready")
    var firmwareDialog by mutableStateOf(false)

    val ble = BudsyBleClient(
        context = context.applicationContext,
        onStatus = { notice = it },
        onConnectionState = { bleConnected = it },
        onDevice = { d, name, rssi ->
            scanResults = (scanResults.filterNot { it.device.address == d.address } + ScanItem(d, name, rssi)).sortedByDescending { it.rssi }
        },
        onServices = { services ->
            gatt = if (services.isEmpty()) "GATT services not discovered" else services.joinToString("\n") { sv ->
                "${sv.uuid} (${sv.characteristics.size})" + sv.characteristics.joinToString("") { "\n  ${it.uuid} [${propertyLabels(it.properties)}]" }
            }
        }
    )

    // RFCOMM is the preferred control transport. BLE remains available for discovery/debug only.
    val rfcomm = BudsyRfcommClient(
        context = context.applicationContext,
        onStatus = { notice = it },
        onConnectionState = { isConnected ->
            connected = isConnected
            deviceResponded = false
            if (isConnected) {
                notice = "RFCOMM connected; requesting battery status…"
                requestBattery()
                batteryRefreshHandler.removeCallbacks(batteryRefreshTask)
                batteryRefreshHandler.postDelayed(batteryRefreshTask, 10_000L)
            } else {
                batteryRefreshHandler.removeCallbacks(batteryRefreshTask)
                leftBattery = -1; rightBattery = -1; caseBattery = -1
                leftCharging = false; rightCharging = false; caseCharging = false
            }
        },
        onPacket = { frame ->
            deviceResponded = true
            val payload = frame.payload
            val command = frame.commandId
            if ((command == 0x0106 && frame.status == 0) || (frame.isPush && frame.commandLow == 0x04 && payload.firstOrNull() == 1)) {
                val readings = NordBudsProtocol.parseBattery(payload)
                readings.forEach { reading ->
                    if (reading.percent in 0..100) when (reading.slot) {
                        0 -> { leftBattery = reading.percent; leftCharging = reading.charging }
                        1 -> { rightBattery = reading.percent; rightCharging = reading.charging }
                        2 -> { caseBattery = reading.percent; caseCharging = reading.charging }
                    }
                }
                notice = if (readings.isEmpty()) "Battery response received but payload was not recognized" else "Battery response received"
            } else {
                notice = "RFCOMM RX cmd 0x${command.toString(16).uppercase()} group 0x${frame.group.toString(16).uppercase()} (${payload.size} bytes)"
            }
        }
    )
    init {
        // Battery and Find use the raw RFCOMM frame protocol from Budsy (2).zip.
        // Other HeyMelody/GATT command mappings are not silently treated as RFCOMM commands.
    }

    /**
     * The 0x0418 payload belongs to a different HeyMelody packet path. The supplied
     * Budsy (2).zip RFCOMM transport uses raw AA frames and documents custom EQ as 0x0422.
     * Refuse to send an incompatible frame rather than silently corrupting the control link.
     */
    fun sendCustomEq(mode: Int, minValue: Int, maxValue: Int, eqId: Int, name: String?, frequencies: IntArray, dbValues: IntArray): String =
        "Custom EQ is disabled until the RFCOMM 0x0422 payload is verified for Nord Buds 3."

    fun sendFind(on: Boolean) {
        if (!connected) { findStatus = "Connect to the earbuds first (Device tab)."; return }
        findOn = on
        // Ported from the supplied Budsy (2).zip source. Target firmware still needs hardware verification.
        val payload = if (on) intArrayOf(2, 1, 2) else intArrayOf(0)
        val sent = sendRawCommand(commandLow = 0x00, group = 0x04, payload = payload)
        findStatus = if (sent) "Find ${if (on) "start" else "stop"} requested; confirm the tone on the earbuds." else "RFCOMM write failed."
    }
}

fun propertyLabels(p: Int): String = buildList {
    if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) add("READ")
    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) add("WRITE")
    if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) add("WRITE_NR")
    if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) add("NOTIFY")
    if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) add("INDICATE")
}.joinToString()
