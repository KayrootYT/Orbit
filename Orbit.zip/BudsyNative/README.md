# Budsy Native Android (stock appearance + HeyMelody BLE transport)

Kotlin + Jetpack Compose. OnePlus Nord Buds 3 / 3 Pro protocol research app.

## What changed
- BLE: fixed `settings is null` scan crash (ScanSettings added), paired-devices list, "show all BLE devices" debug scan,
  auto-retry on GATT 133, proper GATT close on disconnect, write acknowledgement callback, scan-timeout cleanup.
- Find-my-buds now really sends the one source-verified packet (cmd 0x0400, payload 1/0) via DeviceCommandGateway.
- Gesture settings are stored per earbud (Left/Right) and call/non-call gestures no longer overwrite each other.
- Custom EQ presets now store their band values; selecting a preset loads its bands; edit/rename/delete works.
- UI appearance: only Light, Dark and AMOLED black. Removed the custom theme palette picker, icon-style picker, badge-style picker, animated backgrounds and sensor parallax. UI uses flat Android-style surfaces and a restrained system-blue accent.
- Protocol transport: wraps the inner five-byte HeyMelody packet in source-derived OPOv1 (`0xAA`) frames, splits long packets, queues GATT writes sequentially, and reassembles OPOv1 notifications before decoding inner packets.
- Protocol implementation is based on supplied HeyMelody JADX sources; physical-device validation is still required.

## Build
Open `BudsyNative/` in Android Studio (JDK 17, SDK 35), let Gradle sync (it creates the wrapper), run on a physical phone.
Not compiled or tested on hardware in the authoring environment.

See PROTOCOL_STATUS.md for what is / isn't verified against the earbuds.
