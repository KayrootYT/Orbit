# Budsy Native Android (premium UI build)

Kotlin + Jetpack Compose. OnePlus Nord Buds 3 / 3 Pro protocol research app.

## What changed
- BLE: fixed `settings is null` scan crash (ScanSettings added), paired-devices list, "show all BLE devices" debug scan,
  auto-retry on GATT 133, proper GATT close on disconnect, write acknowledgement callback, scan-timeout cleanup.
- Find-my-buds now really sends the one source-verified packet (cmd 0x0400, payload 1/0) via DeviceCommandGateway.
- Gesture settings are stored per earbud (Left/Right) and call/non-call gestures no longer overwrite each other.
- Custom EQ presets now store their band values; selecting a preset loads its bands; edit/rename/delete works.
- UI: 5 themes, 5 icon styles, 5 icon-badge looks, 4 animated backgrounds (Aurora / Particles / Waves / 3D Grid),
  3D draggable earbuds hero, sensor-driven parallax, press-tilt glass cards, staggered 3D entrance, floating nav with spinning icons.
  Choices are saved (SharedPreferences) in Style tab.

## Build
Open `BudsyNative/` in Android Studio (JDK 17, SDK 35), let Gradle sync (it creates the wrapper), run on a physical phone.
Not compiled or tested on hardware in the authoring environment.

See PROTOCOL_STATUS.md for what is / isn't verified against the earbuds.
