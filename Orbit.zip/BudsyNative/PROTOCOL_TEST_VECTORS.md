# BLE stream decoder test vectors

Header: `command LE16 | sequence U8 | payload length LE16 | payload`.

1. Complete frame `18 04 07 03 00 AA BB CC` => command `0x0418`, sequence 7, payload `AA BB CC`.
2. Split frame: chunks `18 04 07 03` then `00 AA BB CC` => one complete packet after second chunk.
3. Two frames in one chunk: `18 04 07 01 00 AA 19 04 08 00 00` => commands `0x0418` and `0x0419`.
4. Declared payload over 4096 bytes is treated as implausible and byte-wise resynchronization is attempted.
5. Closing GATT resets pending bytes so sessions cannot contaminate each other.

## OPOv1 transport vectors

6. Single inner packet `18 04 07 03 00 AA BB CC` wraps as `AA 0A 00 00 18 04 07 03 00 AA BB CC` (SOF, length 10, unfragmented flag 0, reserved 0, inner packet).
7. Outbound frames are split so each complete OPOv1 frame is at most 660 bytes for source-derived product type 102; fragments use flag 1 (start), 2 (middle), 3 (end), and a fragment sequence byte.

These are source-derived framing vectors, not claims that a given command is supported or has been validated on physical Nord Buds hardware.
