# Budsy protocol implementation status

This document distinguishes source findings from device-tested behavior.

## Source findings in supplied `jadx-sources.zip`

- BLE discovery filters: manufacturer IDs `1839 (0x072F)`, `1946 (0x079A)`, and `41992 (0xA408)`, plus advertising service UUID `00009801-0000-1000-8000-00805f9b34fb`. The advertising UUID is not assumed to be the GATT service UUID; HeyMelody source permits a product-specific GATT service UUID.
- Custom EQ set: command `1048 (0x0418)`, payload builder based on `HeadsetCoreService.M0(String, EqInfo, int)`.
- EQ preset: command `1030 (0x0406)`, one-byte `equalizerModeType` from `HeadsetCoreService.N0(...)`.
- Find mode: command `1024 (0x0400)`, payload byte `1`/`0` in `HeadsetCoreService.O0(...)`.
- BassWave set: command `1051 (0x041B)`, `HeadsetCoreService.F0(i10, i11, i12, address)` sends a three-byte payload `[i10, i11, i12]`.
- BassWave response: response command `1288 (0x0508)` is parsed as three values: minimum, maximum, current value. `BassEngineInfo` exposes these fields.
- Multi-connection info response: response command `1287 (0x0507)` appears in the request-command response handler. Dual-connection set operation is routed through `HeadsetCoreService.s0(...)` and command `1065 (0x0429)` per the prior source inspection; exact operation/address payload and model compatibility still require end-to-end validation.
- Game Mode UI entry points: `GameSetViewModel.setGameModeMainEnable(...)` and `setGameSoundEnable(...)`. The exact outbound command mapping is not yet independently verified here, so Budsy intentionally does not send a guessed Game Mode command.

## Important transport limitation

The source-derived five-byte inner packet header is built little-endian. Outbound inner packets are now wrapped with OPOv1 framing (`0xAA`, variable-length frame size, frame flags/reserved byte, fragment sequence when required) based on `F8.b` (`TLVDataProcessor`) and `G8.b` (`OPOv1Wrapper`). Large packets are split into sequential BLE writes; writes with response are preferred and queued one at a time. Incoming notifications pass through an OPOv1 frame/reassembly decoder before the inner HeyMelody packet decoder. The source's product-type-102 frame size of 660 bytes is used as the initial default.

This is a source-derived implementation, not yet validated on physical Nord Buds 3 / Nord Buds 3 Pro. In particular, the target product's actual max frame size, response framing edge cases, command acknowledgement mapping, and feature-specific payloads still require device logs. A queued or completed GATT write is not proof that the earbuds applied a setting.

## Current app status

- Native Kotlin + Jetpack Compose UI, BLE scan/connect/disconnect, service inventory, notifications and receive stream decoder are included. The UI now remains disconnected until the expected HeyMelody write/notify characteristic pair is discovered and the notification descriptor write is confirmed. A successful GATT link alone is not shown as a ready device connection.
- Sound Master EQ, presets, BassWave slider, touch-control UI, Game Mode, Dual Connection and Find My Buds screens are present.
- Several feature controls are UI-only until the complete source path and model-specific packet transport are validated. Manual EQ currently has payload encoding support, but the app does not yet have a complete verified read-modify-write flow for device-specific EQ bands.
- No firmware update is performed. OTA should not be enabled until a trusted firmware image, model/version check, chunk protocol, acknowledgements and recovery path are confirmed.
- The UI appearance controls now expose only Light, Dark and AMOLED black. Custom theme palettes, animated backgrounds, icon-style selection, badge-style selection and parallax motion controls were removed from the user-facing UI.
- No APK build or physical-earbud test is claimed in this package.

## Build

Open `BudsyNative/` in Android Studio with JDK 17 and Android SDK Platform 35 installed. Let Gradle sync, then run `app` on an Android 8.0+ device. Bluetooth scan/connect permissions are requested at runtime. Physical device testing is required before relying on feature controls.


For the detailed EQ field layout and source cross-check, see `PROTOCOL_SOURCE_AUDIT.md`. The new `encodeCustomEqPacket(...)` helper combines the source-derived 0x0418 payload with the inner packet header; callers must supply actual target-device EqInfo values.


## RFCOMM / Custom EQ update
- Preferred control path: RFCOMM, with OPOv1 framing around HeyMelody inner packets.
- Custom EQ command constant: `0x0418` (`1048`).
- Hardware validation remains pending because the exact Nord Buds 3 SupportDeviceConfig RFCOMM UUID and target EqInfo profile values were not present in the supplied source archive.


RFCOMM follow-up: source audit confirms HeyMelody takes the RFCOMM UUID from device-specific `SupportDeviceConfig` and checks SPP support. The archive lacks the Nord Buds 3 runtime whitelist entry, so exact UUID is still unknown. Orbit's RFCOMM diagnostics now distinguish socket connection from stream/read failure and report the attempted UUID. Hardware verification is still required.


## RFCOMM service discovery update (ported from the supplied Budsy (2).zip)

- RFCOMM now requests an SDP UUID refresh (`fetchUuidsWithSdp`) and reads the device-advertised UUID records before trying a hard-coded fallback.
- Candidate order: explicitly supplied UUID (if any), advertised non-standard/vendor UUIDs, standard SPP, then other non-audio standard UUIDs.
- Each candidate is tried with a secure RFCOMM socket first and an insecure socket second.
- A connection attempt that takes over 4 seconds stops the retry round to avoid cycling through records while the earbuds are asleep or out of range.
- This is service-discovery logic ported from `com.nordbuds.studio.buds.Link` in the supplied archive. It does **not** establish that the Nord Buds 3 firmware advertises the correct control UUID; the advertised UUID list and a successful command/response still need on-device verification.
