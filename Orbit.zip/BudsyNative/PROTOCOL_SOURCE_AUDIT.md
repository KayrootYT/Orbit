# HeyMelody protocol source audit (JADX)

This note records only fields confirmed in the supplied `jadx-sources.zip`.

## Custom EQ: `HeadsetCoreService.M0(String, EqInfo, int)`

- Command ID: decimal `1048` / `0x0418`.
- Byte 0: caller argument `i10` cast to byte (mode/selection flag).
- Byte 1: `EqInfo.minValue`.
- Byte 2: `EqInfo.maxValue`.
- Byte 3: `EqInfo.eqId`.
- Byte 4: UTF-8 name length in bytes.
- Next: UTF-8 name bytes.
- Next: number of frequency bands.
- Each band: frequency as 2 bytes little-endian, then dB value as 1 byte.
- Frequency and dB arrays must both be non-empty and have identical lengths. The source rejects mismatched arrays.
- The payload is passed to the source packet wrapper with command `1048`; this app's `encodeCustomEqPacket` creates the five-byte inner header plus that payload, and BLE transport then applies OPOv1 framing.

## Important constraints

Do not invent `EqInfo` values. In particular, `minValue`, `maxValue`, `eqId`, the mode byte, and the device's frequency/gain arrays must come from the target model/firmware's actual EQ information. The seven UI labels are not proof that the device accepts those exact frequencies. This helper encodes data; it does not establish that Nord Buds 3 / Nord Buds 3 Pro accepts it.

## BLE scan source cross-check

`p085f8.b` confirms manufacturer IDs `1839 (0x072F)` and `1946 (0x079A)` with empty manufacturer data, plus advertising service UUID `00009801-0000-1000-8000-00805f9b34fb`. `MelodyBluetoothAdapter` additionally uses manufacturer ID `41992 (0xA408)` with data `[00 00 00 00 00 00 98]` and mask `[00 00 00 00 00 00 FF]` on its filtered RSSI path. These filters are discovery filters, not GATT service UUIDs.

## GATT UUIDs

From `p349y8.i` (`GattDevice`):
- Default service/read UUID: `0000079A-D102-11E1-9B23-00025B00A5A5`
- Write UUID: `0100079A-D102-11E1-9B23-00025B00A5A5`
- Notify UUID: `0200079A-D102-11E1-9B23-00025B00A5A5`
- CCCD UUID: `00002902-0000-1000-8000-00805f9b34fb`
- Device product configuration may override the service UUID.

## Validation status

Source-derived, not hardware-verified. A completed Android GATT write is not a device command acknowledgement. No claim is made here that custom EQ, BLE connection, or every feature has been verified on physical earbuds.


## Preferred transport: RFCOMM

- The HeyMelody source uses `BluetoothDevice.createRfcommSocketToServiceRecord(uuid)` and reads OPOv1-framed bytes from the socket (`A8.c`).
- Its RFCOMM service UUID is supplied by model-specific `SupportDeviceConfig`; it is not universally fixed in the inspected source.
- The app's RFCOMM client currently uses the standard Serial Port Profile UUID only as a fallback. If Nord Buds 3 has a different configured UUID, that UUID must replace the fallback before hardware connection can be considered verified.
- Custom EQ uses command `0x0418` and is encoded using `EqInfo` fields. Sending is exposed through `BudsyState.sendCustomEq(...)`; it deliberately does not invent the target model's min/max, EQ ID, or band frequencies.
- RFCOMM connection/write success is not proof that the earbuds accepted or applied a command.


## RFCOMM service UUID audit (2026-10-22)
- HeyMelody `A8.c` creates its RFCOMM socket with `BluetoothDevice.createRfcommSocketToServiceRecord(aVar.f286d)`.
- The UUID is populated from `SupportDeviceConfig.getUuid()` in `p363z8.b` (and a related device path in `p349y8.i`); it is not a universal hard-coded SPP UUID in the decompiled source.
- `SupportDeviceConfig` contains `uuid` and `isSupportSpp`; the active config is selected using product ID/device name. The supplied source archive does not include the runtime whitelist/config entry for OnePlus Nord Buds 3, so its exact RFCOMM UUID and SPP eligibility remain unverified.
- Orbit now reports socket-connect failures separately from stream/read failures and prints the UUID used. The default SPP UUID remains a fallback only, not a verified Nord Buds 3 UUID.


## RFCOMM service discovery update (ported from the supplied Budsy (2).zip)

- RFCOMM now requests an SDP UUID refresh (`fetchUuidsWithSdp`) and reads the device-advertised UUID records before trying a hard-coded fallback.
- Candidate order: explicitly supplied UUID (if any), advertised non-standard/vendor UUIDs, standard SPP, then other non-audio standard UUIDs.
- Each candidate is tried with a secure RFCOMM socket first and an insecure socket second.
- A connection attempt that takes over 4 seconds stops the retry round to avoid cycling through records while the earbuds are asleep or out of range.
- This is service-discovery logic ported from `com.nordbuds.studio.buds.Link` in the supplied archive. It does **not** establish that the Nord Buds 3 firmware advertises the correct control UUID; the advertised UUID list and a successful command/response still need on-device verification.

## 2026-10-22 RFCOMM + battery integration audit

The supplied `Budsy (2).zip` contains a separate raw RFCOMM protocol (`AA` frame, low command byte, group byte, sequence, payload length, payload). It is **not** the 5-byte HeyMelody GATT inner packet wrapped in OPOv1. Orbit previously incorrectly wrapped RFCOMM writes in OPOv1 and attempted to decode the result as a GATT packet; this has now been replaced in the RFCOMM client with the raw frame parser and writer from the supplied source.

Battery path added from that source: query command `0x0106` (low byte `0x06`, group `0x01`, empty payload); successful response payload `[status=0, count, (slot, percent-with-charging-bit)*]`; slot 1=left, 2=right, 3=case. UI state now stores these values and supplies them to `BatteryRing`. A manual Refresh battery action is available while connected. Push battery payload is also parsed.

The RFCOMM reader and writer now use separate executors. Previously the blocking read loop occupied the single-thread executor, which could prevent queued writes (including the battery query) from ever running. Known HeyMelody GATT service/characteristic UUIDs are excluded from RFCOMM candidates.

Custom EQ `0x0418` is intentionally not sent over this raw RFCOMM path: the supplied `Budsy (2).zip` documents a different raw-frame custom-EQ command (`0x0422`) whose target Nord Buds 3 payload still needs hardware verification. Find-mode is wired using the supplied raw RFCOMM frame (`command low 0x00`, group `0x04`); its effect/stop semantics remain unverified on target hardware.

Build/device verification status: ZIP/source checks only; Android build and physical Nord Buds 3 response remain unverified in this environment.
