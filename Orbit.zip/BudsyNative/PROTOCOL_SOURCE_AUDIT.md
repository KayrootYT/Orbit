# HeyMelody protocol source audit (JADX)

This note records only fields confirmed in the supplied `jadx-sources.zip`.

## Custom EQ: `HeadsetCoreService.M0(String, EqInfo, int)`

- Command ID: decimal `1048` / `0x0418`.
- Byte 0: caller argument `i10` cast to byte (mode/selection flag).
- Byte 1: `EqInfo.minValue`.
- Byte 2: `EqInfo.maxValue`.
- Byte 3: `EqInfo.eqId`.
- Byte 4: UTF-8 name length in bytes.
- Next: UTF-8 name bytes.
- Next: number of frequency bands.
- Each band: frequency as 2 bytes little-endian, then dB value as 1 byte.
- Frequency and dB arrays must both be non-empty and have identical lengths. The source rejects mismatched arrays.
- The payload is passed to the source packet wrapper with command `1048`; this app's `encodeCustomEqPacket` creates the five-byte inner header plus that payload, and BLE transport then applies OPOv1 framing.

## Important constraints

Do not invent `EqInfo` values. In particular, `minValue`, `maxValue`, `eqId`, the mode byte, and the device's frequency/gain arrays must come from the target model/firmware's actual EQ information. The seven UI labels are not proof that the device accepts those exact frequencies. This helper encodes data; it does not establish that Nord Buds 3 / Nord Buds 3 Pro accepts it.

## BLE scan source cross-check

`p085f8.b` confirms manufacturer IDs `1839 (0x072F)` and `1946 (0x079A)` with empty manufacturer data, plus advertising service UUID `00009801-0000-1000-8000-00805f9b34fb`. `MelodyBluetoothAdapter` additionally uses manufacturer ID `41992 (0xA408)` with data `[00 00 00 00 00 00 98]` and mask `[00 00 00 00 00 00 FF]` on its filtered RSSI path. These filters are discovery filters, not GATT service UUIDs.

## GATT UUIDs

From `p349y8.i` (`GattDevice`):
- Default service/read UUID: `0000079A-D102-11E1-9B23-00025B00A5A5`
- Write UUID: `0100079A-D102-11E1-9B23-00025B00A5A5`
- Notify UUID: `0200079A-D102-11E1-9B23-00025B00A5A5`
- CCCD UUID: `00002902-0000-1000-8000-00805f9b34fb`
- Device product configuration may override the service UUID.

## Validation status

Source-derived, not hardware-verified. A completed Android GATT write is not a device command acknowledgement. No claim is made here that custom EQ, BLE connection, or every feature has been verified on physical earbuds.
